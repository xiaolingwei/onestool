#!/bin/bash
#单/多线程实现
#################################################################
# TestCase ID:  setattr-getxattr OP组合
# Description:  单/多线程实现setattr-getxattr 设置扩展属性同时获取扩展属性
# Author:    hys46897
# Revision:    1.0.0

#################################################################
source ./log.sh
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

hostname=`hostname`
# read -p "请输入要跑脚本的目录全路径（eg:/mnt/note3/dir）：" dir
dir=$2

if [ ! -d $dir ];then
	mkdir $dir
else
	echo "$dir exits,no need to create"
fi

# read -p "请输入脚本要循环的次数（只能输入数字）：" count
count=$3

operation(){
  log_info "设置,查询文件hello的扩展属性"
  echo 设置,查询文件hello的扩展属性
  log_info "创建dir1和dir2"
	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat hello"
	stat $dir/dir1/hello
	log_info "设置 hello文件的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
  log_info "设置 hello文件的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello

#  chattr +i $dir/dir1/hello && echo chattr $dir/dir1/hello
  log_info "查询hello文件的扩展属性"
  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello 
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除 hello"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置,查询文件dir1的扩展属性"
  echo 设置,查询文件dir1的扩展属性
  log_info "创建dir1和dir2"
	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir1"
	stat $dir/dir1
	log_info "设置 dir1的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
  log_info "设置 dir1的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1 && echo setxattr security $dir/dir1
  log_info "查询dir1的扩展属性"
  getfattr -d $dir/dir1 && echo getxattr $dir/dir1 
  log_info "stat hello"
  stat $dir/dir1
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置父目录的扩展属性,查询文件hello的扩展属性"
  echo 设置父目录的扩展属性,查询文件hello的扩展属性
  log_info "创建dir1和dir2"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir1"
  stat  $dir/dir1
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "设置 dir1的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
  log_info "设置 hello文件的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  
#  getfattr -d $dir/dir1 && echo getxattr $dir/dir1
  log_info "查询hello的扩展属性"
  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
  log_info "stat dir1"
  stat $dir/dir1
  log_info "stat hello"
  stat $dir/dir1/hello 
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置文件hello的扩展属性,查询其父目录的扩展属性"
  echo 设置文件hello的扩展属性,查询其父目录的扩展属性
  log_info "创建dir1和dir2"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir1"
  stat  $dir/dir1
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "设置 dir1的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
  log_info "设置 hello文件的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  log_info "查询dir1的扩展属性"
  getfattr -d $dir/dir1 && echo getxattr $dir/dir1
#  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
  log_info "stat dir1"
  stat  $dir/dir1
  log_info "stat hello"
  stat $dir/dir1/hello 
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置文件hi的扩展属性,查询文件hello的扩展属性"
  echo 设置文件hi的扩展属性,查询文件hello的扩展属性
  log_info "创建dir1和dir2"
	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat hi"
  stat  $dir/dir2/hi
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "设置 hi文件的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir2/hi && echo setxattr user $dir/dir2/hi
  log_info "设置 hi文件的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  log_info "查询hello的扩展属性"
  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello 
  log_info "stat hi"
  stat $dir/dir2/hi
  log_info "stat hello"
  stat $dir/dir1/hello 
  log_info "删除 hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
 	log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置文件hello1的扩展属性,查询文件hello的扩展属性"
  echo 设置文件hello1的扩展属性,查询文件hello的扩展属性
  log_info "创建dir1"
	mkdir $dir/dir1
  log_info "创建hello和hello1"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir1/hello1
  log_info "stat hell1"
  stat  $dir/dir1/hello1
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "设置 hello1文件的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1/hello1 && echo setxattr user $dir/dir1/hello1
  log_info "设置 hello文件的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  log_info "查询hello的扩展属性"
  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
  log_info "stat hello1"
  stat $dir/dir1/hello1
  log_info "stat hello"
  stat $dir/dir1/hello  
  log_info "删除 hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
 	log_info "删除 hello1"
  rm -rf $dir/dir1/hello1 && echo rm -rf $dir/dir1/hello1
  log_info "删除 dir1"
	rm -rf $dir/dir1

  log_info "设置目录dir1的扩展属性,查询目录dir2的扩展属性"
  echo 设置目录dir1的扩展属性,查询目录dir2的扩展属性
  log_info "创建dir1和dir2"
	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir1"
  stat $dir/dir1
  log_info "stat dir2"
  stat $dir/dir2
  log_info "设置dir1的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
  log_info "设置dir2的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir2 && echo setxattr security $dir/dir2
  log_info "查询dir2的扩展属性"
  getfattr -d $dir/dir2 && echo getxattr $dir/dir2
#  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
  log_info "stat dir1"
  stat $dir/dir1
  log_info "stat dir2"
  stat $dir/dir2 
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置目录dir2的扩展属性,查询文件hello的扩展属性"
  echo 设置目录dir2的扩展属性,查询文件hello的扩展属性
  log_info "创建dir1和dir2"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir2"
  stat  $dir/dir2
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "设置 dir2的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir2 && echo setxattr user $dir/dir2
  log_info "设置 hello文件的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  
#  getfattr -d $dir/dir1 && echo getxattr $dir/dir1
  log_info "查询hello的扩展属性"
  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
  log_info "stat dir2"
  stat $dir/dir2
  log_info "stat hello"
  stat $dir/dir1/hello 
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置文件hello的扩展属性,查询目录dir2的扩展属性"
  echo 设置文件hello的扩展属性,查询目录dir2的扩展属性
  log_info "创建dir1和dir2"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir2"
  stat $dir/dir2
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "设置 dir2的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir2 && echo setxattr user $dir/dir2
  log_info "设置 hello文件的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  log_info "查询dir2的扩展属性"
  getfattr -d $dir/dir2 && echo getxattr $dir/dir2
#  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
  log_info "stat dir2"
  stat  $dir/dir2
  log_info "stat hello"
  stat $dir/dir1/hello 
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2 
}

if [ $# -ne 3 ]; then
        usage
        exit
fi

if [ $1 -eq 1 ]; then
{	
	for i in `seq 1 $count`
	do
        {
	operation
        echo $i
        }
	done
}

elif [ $1 -gt 1 ]; then
{
	# read -p "请输入要并发的线程数（只能输入数字）：" thread
  thread=$1
	[ -e /tmp/fd1 ] || mkfifo /tmp/fd1
        exec 3<>/tmp/fd1
        rm -rf /tmp/fd1
	
	for i in `seq 1 $thread`
	do
        {
	echo >&3
        echo a=$i
	}
	done

        for j in `seq 1 $count`
        do
        read -u3
        {
        operation
        echo $j
        echo >&3
        }&
	done
	wait
	exec 3<&-
	exec 3>&-

}
else
	usage
fi
