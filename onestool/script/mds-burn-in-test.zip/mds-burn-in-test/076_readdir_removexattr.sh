#!/bin/bash
######################################################################################
# TestCase ID:：readdir-removexattr OP组合
# Description:  单/多线程实现readdir目录的同时移除文件/目录的扩展属性
# Author:       liumengyang
# Revision:     1.0.0
######################################################################################
source ./log.sh

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

hostname=`hostname`
# read -p "请输入要跑脚本的目录全路径（eg:/mnt/note3/dir）：" dir
dir=$2
log_info "拷机目录:$dir"

if [ ! -d $dir ];then
	mkdir $dir
else
	log_debug "$dir exits,no need to create"
fi

# read -p "请输入脚本要循环的次数（只能输入数字）：" count
count=$3
log_info "脚本循环次数$count"
operation(){

	log_info "获取目录dir1的子项并移除目录dir1的扩展属性"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
	stat $dir/dir1
 
  	for x in {1..10}
  	do
   		mkdir -p $dir/dir1/directory$x
   		for y in {1..10}
  	 	do
     			touch $dir/dir1/directory$x/file$y.txt
   		done
  	done

  	ls -a $dir/dir1 && echo ls -a $dir/dir1
  	ls -R $dir/dir1 && echo ls -R $dir/dir1
 
  	setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
  	setfattr -n security.selinux -v "label" $dir/dir1 && echo setxattr security $dir/dir1

  	#chattr +i $dir/dir1 && echo chattr $dir/dir1
  
  	getfattr -d $dir/dir1 && echo getxattr $dir/dir1 
  	#lsattr $dir/dir1 && echo lsattr $dir/dir1 

  	#chattr -i $dir/dir1 && echo removechattr $dir/dir1
  	setfattr -x user.myattribute $dir/dir1 && echo removexattr user $dir/dir1
  	setfattr -x security.selinux $dir/dir1 && echo removexattr security $dir/dir1
  
  	stat $dir/dir1
 	teardown
	sleep 2
  	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  	#rm -rf $dir/dir1 
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	#rm -rf $dir/dir2
  
	log_info "获取目录dir1的子项，并移除文件hello的扩展属性"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir1
  	stat $dir/dir1/hello
  
  	for x in {1..10}
  	do
   		mkdir -p $dir/dir1/directory$x
   		for y in {1..10}
   		do
     			touch $dir/dir1/directory$x/file$y.txt
   		done
  	done

  	ls -a $dir/dir1 && echo ls -a $dir/dir1
  	ls -R $dir/dir1 && echo ls -R $dir/dir1
    
  	setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
  
  	getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
  
  	setfattr -x user.myattribute $dir/dir1/hello && echo removexattr user $dir/dir1/hello 
   
  	stat  $dir/dir1
  	stat $dir/dir1/hello 
	teardown
	sleep 2
 	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  
 	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2
 
	log_info "获取目录dir1的子项并移除其子目录dir2的扩展属性"
  	mkdir $dir/dir1 
  	mkdir $dir/dir1/dir2

	echo hello > $dir/dir1/dir2/hello
	echo hi > $dir/dir1/dir2/hi
 
 	 stat  $dir/dir1
 	 stat $dir/dir1/dir2

  	for x in {1..10}
  	do
   		mkdir -p $dir/dir1/directory$x
   		for y in {1..10}
   		do
     			touch $dir/dir1/directory$x/file$y.txt
   		done
  	done

  	ls -a $dir/dir1 && echo ls -a $dir/dir1
  	ls -R $dir/dir1 && echo ls -R $dir/dir1

  	setfattr -n security.selinux -v "label" $dir/dir1/dir2 && echo setxattr security $dir/dir1/dir2
  
  	getfattr -d $dir/dir1/dir2 && echo getxattr $dir/dir1/dir2
  
  	setfattr -x security.selinux $dir/dir1/dir2 && echo removexattr security $dir/dir1/dir2
   
  	stat  $dir/dir1
  	stat $dir/dir1/dir2 
    	teardown
        sleep 2
  	#rm -rf $dir/dir1/dir2/hi && echo rm -rf $dir/dir1/dir2/hi
	#rm -rf $dir/dir1/dir2
 	#rm -rf $dir/dir1/dir2/hello && echo rm -rf $dir/dir1/dir2/hello
	#rm -rf $dir/dir1
 
	log_info "获取目录dir2的子项并移除其父目录dir1的扩展属性"
  	mkdir $dir/dir1
  	mkdir $dir/dir1/dir2

	echo hello > $dir/dir1/dir2/hello
	echo hi > $dir/dir1/dir2/hi
 
 	 stat  $dir/dir1
 	 stat $dir/dir1/dir2

  	for x in {1..10}
  	do
  		mkdir -p $dir/dir1/dir2/directory$x
   		for y in {1..10}
   		do
     			touch $dir/dir1/dir2/directory$x/file$y.txt
   		done
  	done

  	ls -a $dir/dir1/dir2 && echo ls -a $dir/dir1/dir2
  	ls -R $dir/dir1/dir2 && echo ls -R $dir/dir1/dir2

  	setfattr -n security.selinux -v "label" $dir/dir1 && echo setxattr security $dir/dir1
  
  	getfattr -d $dir/dir1 && echo getxattr $dir/dir1
  
  	setfattr -x security.selinux $dir/dir1 && echo removexattr security $dir/dir1
   
  	stat  $dir/dir1
  	stat $dir/dir1/dir2
    	teardown
        sleep 2
  	#rm -rf $dir/dir1/dir2/hi && echo rm -rf $dir/dir1/dir2/hi
	#rm -rf $dir/dir1/dir2
 	#rm -rf $dir/dir1/dir2/hello && echo rm -rf $dir/dir1/dir2/hello
	#rm -rf $dir/dir1

	log_info "获取目录dir1子项并移除目录dir2的扩展属性"
  	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir1
  	stat $dir/dir2

  	for x in {1..10}
  	do
   		mkdir -p $dir/dir1/directory$x
   		for y in {1..10}
   		do
     			touch $dir/dir1/directory$x/file$y.txt
   		done
  	done

  	ls -a $dir/dir1 && echo ls -a $dir/dir1
  	ls -R $dir/dir1 && echo ls -R $dir/dir1

  	setfattr -n security.selinux -v "label" $dir/dir2 && echo setxattr security $dir/dir2
  
  	getfattr -d $dir/dir2 && echo getxattr $dir/dir2
  
  	setfattr -x security.selinux $dir/dir2 && echo removexattr security $dir/dir2
   
  	stat  $dir/dir1
  	stat $dir/dir2 
    	teardown
        sleep 2
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	#rm -rf $dir/dir2
 	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	#rm -rf $dir/dir1
 
	log_info "获取目录dir2的子项，并移除文件hello的扩展属性"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir2
  	stat $dir/dir1/hello
  
  	for x in {1..10}
  	do
   		mkdir -p $dir/dir2/directory$x
   		for y in {1..10}
   		do
     			touch $dir/dir2/directory$x/file$y.txt
   		done
  	done

  	ls -a $dir/dir1 && echo ls -a $dir/dir1
  	ls -R $dir/dir1 && echo ls -R $dir/dir1 
    
  	setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
  
  	getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
  
  	setfattr -x user.myattribute $dir/dir1/hello && echo removexattr user $dir/dir1/hello 
   
  	stat $dir/dir2
  	stat $dir/dir1/hello 
	teardown
        sleep 2
 	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello 
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2

  
}
teardown() {
    # 检查目录是否存在
    if [ -d "${dir}" ]; then
        log_info "开始清空本次循环所产生的目录文件"
        # 递归删除指定目录中的所有文件和子目录
        rm -rf "${dir}"/*
        log_info "删除完成本次循环所产生的目录文件"
    else
        # 目录不存在时输出错误信息
        log_err "Directory does not exist: ${dir}"
    fi
}

if [ $# -ne 3 ]; then
        usage
        exit
fi

if [ $1 -eq 1 ]; then
{	
	for i in `seq 1 $count`
	do
        {
          operation
          log_info "----------第$i次循环----------"
        }
	done
}

elif [ $1 -gt 1 ]; then
{
	# read -p "请输入要并发的线程数（只能输入数字）：" thread
  	thread=$1
	log_info "并发线程数：$thread"
	[ -e /tmp/fd1 ] || mkfifo /tmp/fd1
        exec 3<>/tmp/fd1
        rm -rf /tmp/fd1
	
	for i in `seq 1 $thread`
	do
        {
	echo >&3
        echo a=$i
	}
	done

        for j in `seq 1 $count`
        do
        read -u3
        {
        operation
        echo $j
        echo >&3
        }&
	done
	wait
	exec 3<&-
	exec 3>&-

}
else
	usage
fi
