#!/bin/bash
######################################################################################
# TestCase ID:：link-removexattr OP组合
# Description:  单/多线程实现link文件的同时删除文件/目录的扩展属性
# Author:       liumengyang
# Revision:     1.0.0
######################################################################################
source ./log.sh

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}
#参数校验
validate_parms(){

	#根据输入开始单线程/多线程测试
	#如果输入不正确，则输出usage内容
	if [ $# -ne 3 ];then
			usage
			exit
	fi
	#单线程，则直接执行operation，拷机预设的count次
	if [ $1 -eq 1 ];then
			for i in `seq 1 $count`
			do
					operation
					log_info "--- 第$i次循环 ---"
			done
	#多线程
	elif [ $1 -gt 1 ];then
	{
			# read -p "请输入并发线程数（只能输入数字）：" thread
			thread=$1
			log_info "并发线程数:$thread"
			[ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
					exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
					rm -rf /tmp/fd1 #删除管道文件

			for i in `seq 1 $thread`  #实现多线程并发
			do
			{
					echo >&3 #向文件描述符为3的命名管道中写入空行
					echo a=$i
			}
			done
			#并发进行操作
			for j in `seq 1 $count`
			do
					read -u3
					{
					operation
					echo $j
					echo >&3
					}&
			done
			wait
			exec 3<&-
			exec 3>&-

	}
	else
			usage
	fi
}



operation(){

	log_info "创建文件hello的硬链接并移除文件hello的扩展属性"
 	
	mkdir $dir/dir1 && echo "mkdir $dir/dir1"
	mkdir $dir/dir2 && echo "mkdir $dir/dir2"
	echo hello > $dir/dir1/hello && echo "echo hello > $dir/dir1/hello"
	echo hi > $dir/dir2/hi && echo "echo hi > $dir/dir2/hi"
 
	stat $dir/dir1/hello
 
  	ln $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln -s $dir/dir1/hello
 
  	setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
  	setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello

  	#chattr +i $dir/dir1/hello && echo chattr $dir/dir1/hello
  
  	getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello 
  	#lsattr $dir/dir1/hello && echo lsattr $dir/dir1/hello 

  	#chattr -i $dir/dir1/hello && echo removechattr $dir/dir1/hello
  	setfattr -x user.myattribute $dir/dir1/hello && echo removexattr user $dir/dir1/hello
  	setfattr -x security.selinux $dir/dir1/hello && echo removexattr security $dir/dir1/hello  
  
  	stat $dir/dir1/hello
 	teardown
	sleep 2
 	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello  
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2


	log_info "创建文件hello的硬链接，并移除其父目录扩展属性"
 	mkdir $dir/dir1 && echo "mkdir $dir/dir1"
	mkdir $dir/dir2 && echo "mkdir $dir/dir2"
	echo hello > $dir/dir1/hello && echo "echo hello > $dir/dir1/hello"
	echo hi > $dir/dir2/hi && echo "echo hi > $dir/dir2/hi"
 
  	stat  $dir/dir1
  	stat $dir/dir1/hello
  
  	ln $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln $dir/dir1/hello

  	setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
  	setfattr -n security.selinux -v "label" $dir/dir1 && echo setxattr security $dir/dir1

  	#chattr +i $dir/dir1 && echo chattr $dir/dir1
  
  	getfattr -d $dir/dir1 && echo getxattr $dir/dir1 
  	#lsattr $dir/dir1 && echo lsattr $dir/dir1 

  	#chattr -i $dir/dir1 && echo removechattr $dir/dir1
  	setfattr -x user.myattribute $dir/dir1 && echo removexattr user $dir/dir1
  	setfattr -x security.selinux $dir/dir1 && echo removexattr security $dir/dir1  
  
  	stat  $dir/dir1
  	stat $dir/dir1/hello
       	teardown
        sleep 2

 	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello 
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2 
 
	log_info "创建文件hi的硬链接并移除文件hello的扩展属性"
  	mkdir $dir/dir1 && echo "mkdir $dir/dir1"
	mkdir $dir/dir2 && echo "mkdir $dir/dir2"
	echo hello > $dir/dir1/hello && echo "echo hello > $dir/dir1/hello"
	echo hi > $dir/dir2/hi && echo "echo hi > $dir/dir2/hi"
 
  	stat  $dir/dir2/hi
  	stat $dir/dir1/hello

  	ln $dir/dir2/hi $dir/dir2/hi_$hostname_$i && echo ln $dir/dir2/hi
  
  	#setfattr -n user.myattribute -v "value" $dir/dir2/hi && echo setxattr user $dir/dir2/hi
  	setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  
  	getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello 
  
  	setfattr -x security.selinux $dir/dir1/hello && echo removexattr $dir/dir1/hello 
  
  	stat  $dir/dir2/hi
  	stat $dir/dir1/hello 
 	teardown
        sleep 2
 	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2
  
	log_info "创建文件hello的硬链接，并删除目录dir2扩展属性"
 	mkdir $dir/dir1 && echo "mkdir $dir/dir1"
	mkdir $dir/dir2 && echo "mkdir $dir/dir2"
	echo hello > $dir/dir1/hello && echo "echo hello > $dir/dir1/hello"
	echo hi > $dir/dir2/hi && echo "echo hi > $dir/dir2/hi"
 
  	stat  $dir/dir2
  	stat $dir/dir1/hello
  
  	ln $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln $dir/dir1/hello

  	setfattr -n user.myattribute -v "value" $dir/dir2 && echo setxattr user $dir/dir2
  	setfattr -n security.selinux -v "label" $dir/dir2 && echo setxattr security $dir/dir2

  
  	getfattr -d $dir/dir2 && echo getxattr $dir/dir2
  
  	setfattr -x user.myattribute $dir/dir2 && echo removexattr user $dir/dir2
  	setfattr -x security.selinux $dir/dir2 && echo removexattr security $dir/dir2

  	stat $dir/dir2
  	stat $dir/dir1/hello
       	teardown
        sleep 2
 	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello 
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2 
}
teardown() {
    # 检查目录是否存在
    if [ -d "${dir}" ]; then
        log_info "开始清空本次循环所产生的目录文件"
        # 递归删除指定目录中的所有文件和子目录
        rm -rf "${dir}"/*
        log_info "删除完成本次循环所产生的目录文件"
    else
        # 目录不存在时输出错误信息
        log_err "Directory does not exist: ${dir}"
    fi
}

main(){

	#定义创建的文件名前缀为主机名
	file=`hostname`
	#进入拷机目录，目录不存在则创建，存在则提示已存在
	# read -p "请输入目录路径：" dir
	dir=$2
	log_info "拷机目录:$dir"
	if [ ! -d $dir ]; then
			mkdir $dir
	else
			log_debug "$dir exits,no need to create"
	fi
	#输入脚本循环次数
	# read -p "请输入循环次数：" count
	count=$3
	log_info "脚本循环次数$count"
	validate_parms "$@"
}
main "$@"
