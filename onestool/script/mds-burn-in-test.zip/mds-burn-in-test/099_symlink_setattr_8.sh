#! /bin/bash
#单/多线程实现symlink文件的同时setattr
source ./log.sh

#!/bin/bash
######################################################################################################################
# TestCase ID(单客户端单线程):  T90_P17620 T90_P17621 T90_P17622 T90_P17623 T90_P17624 T90_P17625 T90_P17626 T90_P17628
# TestCase ID(单客户端多线程):  T90_P15175 T90_P15176 T90_P15178 T90_P15179 T90_P15180 T90_P15181 T90_P15182 T90_P15183
# TestCase ID(多客户端单线程):  T90_P16604 T90_P16605 T90_P16606 T90_P16607 T90_P16608 T90_P16609 T90_P16610 T90_P16611
# TestCase ID(多客户端多线程):  T90_P16207 T90_P16208 T90_P16209 T90_P16210 T90_P16211 T90_P16212 T90_P16213 T90_P16214
# Description:  symlink-setattr OP组合
# Author:       songyunfan
# Revision:     1.0.0
######################################################################################################################

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

hostname=`hostname`
# read -p "请输入要跑脚本的目录全路径（eg:/mnt/note3/dir）：" dir
dir=$2
#判断拷机目录是否，目录不存在则创建，存在则提示已存在
if [ ! -d $dir ];then
	mkdir $dir
else
	log_debug "$dir exits,no need to create"
fi
# read -p "请输入脚本要循环的次数（只能输入数字）：" count
count=$3

user_group()
{
	USERNAME=user
	GROUPNAME=group
	# 判断用户/用户组是否存在
	USER_EXISTS=$(id -u $USERNAME)

	if [ -z "$USER_EXISTS" ]; then
		log_warn "用户不存在"
		# 检查是否已经在使用默认命令进行某些操作时显示这个用户已存在信息
		if ! grep -q "^$USERNAME:" /etc/passwd; then
			# 创建新用户，这里可以根据需要自定义新用户的信息和配置等参数
			useradd $USERNAME
			log_info "创建用户 $USERNAME 成功！"
		else
			log_warn "用户已存在！"
		fi
	else
		log_warn "用户已存在！"
	fi

	# 使用grep命令检查用户组是否存在
	if grep -q "^$GROUPNAME:" /etc/group; then
		log_info "用户组 $GROUPNAME 已存在。"
	else
		# 用户组不存在，创建新的用户组
		groupadd $GROUPNAME
		log_info "已创建用户组 $GROUPNAME"
	fi
}

operation(){
	echo 创建文件hello的软链接并设置文件hello的属性	
	log_info "创建目录$dir/dir1"
	mkdir $dir/dir1
	log_info "创建目录$dir/dir2"
	mkdir $dir/dir2
	log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello
	log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
	log_info "查询文件$dir/dir1/hello属性"
	stat $dir/dir1/hello
    log_info "创建文件hello的软链接并写入hello"
    ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln -s $dir/dir1/hello
	log_info "chmod $dir/dir1/hello 权限为777"
	chmod 777 $dir/dir1/hello && echo chmod $dir/dir1/hello
	log_info "更改$dir/dir1/hello的所属用户所属用户组为user:group"
	chown user:group $dir/dir1/hello && echo chown $dir/dir1/hello
	log_info "创建文件$dir/dir1/hello并将访问时间和修改时间设置为指定的时间戳202210311200.00"
    touch -a -t 202210311200.00 $dir/dir1/hello && echo touch -a -t $dir/dir1/hello 
	log_info "查询文件$dir/dir1/hello属性"
    stat $dir/dir1/hello
	log_info "删除文件hello的软链接"
	rm -rf $dir/dir1/hello_$hostname_$i && echo rm -rf $dir/dir1/hello_$hostname_$i
	log_info "删除文件$dir/dir1/hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除文件$dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "删除rm -rf $dir/dir1"
 	rm -rf $dir/dir1
	log_info "删除rm -rf $dir/dir2"
	rm -rf $dir/dir2
	log_info "创建目录dir1的软链接并设置目录dir1的属性"
	log_info "创建目录$dir/dir1"
	mkdir $dir/dir1
	log_info "创建目录$dir/dir2"
	mkdir $dir/dir2
	log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello
	log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
	log_info "查询$dir/dir1属性"
	stat  $dir/dir1
	log_info "查询文件$dir/dir1/hello属性"
	stat $dir/dir1/hello
  
	log_info "创建目录$dir/dir1的软链接"
	ln -s $dir/dir1 $dir/dir1_$hostname_$i && echo ln -s $dir/dir1
	log_info "chmod $dir/dir1 权限为755"
	chmod 755 $dir/dir1 && echo chmod $dir/dir1
	log_info "更改$dir/dir1的所属用户所属用户组为user:group"
	chown user:group $dir/dir1 && echo chown $dir/dir1
	log_info "创建$dir/dir1并将访问时间和修改时间设置为指定的时间戳202210311200.00"
	touch -a -t 202203132100 $dir/dir1 && echo touch -a -t $dir/dir1
	log_info "查询$dir/dir1属性"
	stat  $dir/dir1
	log_info "删除文件$dir/dir1_$hostname_$i"
	rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i
	log_info "删除$dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除$dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "删除rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "删除rm -rf $dir/dir2"
	rm -rf $dir/dir2

	log_info "创建父目录的软链接，设置文件hello属性"
	log_info "创建目录$dir/dir1"
	mkdir $dir/dir1
	log_info "创建目录$dir/dir2"
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
	log_info "查询$dir/dir1属性"
	stat  $dir/dir1
	log_info "查询$dir/dir1/hello属性"
	stat $dir/dir1/hello
	log_info "创建目录$dir/dir1的软链接"
	ln -s $dir/dir1 $dir/dir1_$hostname_$i && echo ln -s $dir/dir1
	log_info "chmod $dir/dir1/hello 权限为777"	
	chmod 777 $dir/dir1/hello && echo chmod $dir/dir1/hello
	log_info "更改$dir/dir1/hello的所属用户所属用户组为user:group"
	chown user:group $dir/dir1/hello && echo chown $dir/dir1/hello
	log_info "创建$dir/dir1/hello并将访问时间和修改时间设置为指定的时间戳202210311200.00"
	touch -a -t 202210311200.00 $dir/dir1/hello && echo touch -a -t $dir/dir1/hello 
    
	log_info "查询$dir/dir1属性"
	stat  $dir/dir1
	log_info "查询$dir/dir1/hello属性"
	stat $dir/dir1/hello 

	log_info "删除文件$dir/dir1_$hostname_$i"
	rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i
	log_info "删除$dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除$dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "删除rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "删除rm -rf $dir/dir2"
	rm -rf $dir/dir2
 
	log_info "创建文件hello的软链接并设置目录dir1的属性"
	log_info "创建目录$dir/dir1"
	mkdir $dir/dir1
	log_info "创建目录$dir/dir2"
	mkdir $dir/dir2
	log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello
	log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
	
	log_info "查询文件$dir/dir1/hello属性"
	stat $dir/dir1/hello
	
	log_info "创建目录$dir/dir1/hello的软链接"
	ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln -s $dir/dir1/hello
	log_info "chmod $dir/dir1 权限为755"
	chmod 755 $dir/dir1 && echo chmod $dir/dir1
	log_info "更改$dir/dir1的所属用户所属用户组为user:group"
	chown user:group $dir/dir1 && echo chown $dir/dir1
	log_info "创建$dir/dir1并将访问时间和修改时间设置为指定的时间戳202210311200.00"
	touch -a -t 202203132100 $dir/dir1 && echo touch -a -t $dir/dir1
	
	log_info "查询文件$dir/dir1/hello属性"
	stat $dir/dir1/hello
	
	log_info "删除文件$dir/dir1_$hostname_$i"
	rm -rf $dir/dir1/hello_$hostname_$i && echo rm -rf $dir/dir1/hello_$hostname_$i
	log_info "删除$dir/dir1/hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除$dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	
	log_info "删除rm -rf $dir/dir1"
 	rm -rf $dir/dir1
	log_info "删除rm -rf $dir/dir2"
	rm -rf $dir/dir2
    
	
	log_info "创建文件hi的软链接，设置文件hello的属性"
 	log_info "创建目录$dir/dir1"
	mkdir $dir/dir1
	log_info "创建目录$dir/dir2"
	mkdir $dir/dir2
	log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello
	log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
	
	log_info "查询$dir/dir2/hi属性"
	stat  $dir/dir2/hi
	log_info "查询$dir/dir1/hello属性"
	stat $dir/dir1/hello
	
	log_info "创建目录$dir/dir2/hi的软链接"
	ln -s $dir/dir2/hi $dir/dir2/hi_$hostname_$i && echo ln -s $dir/dir2/hi
	log_info "chmod $dir/dir2/hi 权限为777"
	chmod 777 $dir/dir2/hi && echo chmod $dir/dir2/hi
	log_info "更改$dir/dir2/hi的所属用户所属用户组为user:group"
	chown user:group $dir/dir2/hi && echo chown $dir/dir2/hi
	log_info "创建$dir/dir2/hi并将访问时间和修改时间设置为指定的时间戳202210311200.00"
	touch -a -t 202210311200.00 $dir/dir2/hi && echo touch -a -t $dir/dir2/hi
     
	log_info "查询$dir/dir2/hi属性" 
	stat  $dir/dir2/hi
	log_info "查询$dir/dir1/hello属性" 
	stat $dir/dir1/hello 
	
	log_info "删除文件$dir/dir2/hi_$hostname_$i"
	rm -rf $dir/dir2/hi_$hostname_$i && echo rm -rf $dir/dir2/hi_$hostname_$i
	log_info "删除$dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除$dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "删除rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "删除rm -rf $dir/dir2"
	rm -rf $dir/dir2
 
	log_info "创建目录dir1的软链接，设置目录dir2属性"
	log_info "创建目录$dir/dir1"
 	mkdir $dir/dir1
	log_info "创建目录$dir/dir2"
	mkdir $dir/dir2
	log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello
	log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
	
	log_info "查询$dir/dir1属性"
	stat  $dir/dir1
	log_info "查询文件$dir/dir2属性"
	stat $dir/dir2
	
	log_info "创建目录$dir/dir1/hello的软链接"
	ln -s $dir/dir1/hello $dir/dir1_$hostname_$i && echo ln -s $dir/dir1
	log_info "chmod $dir/dir2 权限为755"
	chmod 755 $dir/dir2 && echo chmod $dir/dir2
	log_info "更改$dir/dir2的所属用户所属用户组为user:group"
	chown user:group $dir/dir2 && echo chown $dir/dir2
	log_info "创建$dir/dir2并将访问时间和修改时间设置为指定的时间戳202210311200.00"
	touch -a -t 202203132100 $dir/dir2 && echo touch -a -t $dir/dir2
    
	log_info "查询$dir/dir1属性"
	stat  $dir/dir1
	log_info "查询$dir/dir2属性"
	stat $dir/dir2
	
	log_info "删除文件$dir/dir1_$hostname_$i"
	rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i
	log_info "删除$dir/dir1/hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除$dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "删除rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "删除rm -rf $dir/dir2"
	rm -rf $dir/dir2
 
	log_info "创建目录dir2的软链接，设置文件hello属性"
	log_info "创建目录$dir/dir1"
	mkdir $dir/dir1
	log_info "创建目录$dir/dir2"
	mkdir $dir/dir2
	log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello
	log_info "创建文件$dir/dir2/hi并写入hello"
	echo hi > $dir/dir2/hi
 
	log_info "查询$dir/dir2属性"
	stat  $dir/dir2
	log_info "查询$dir/dir1/hello属性"
	stat $dir/dir1/hello
	
	log_info "创建目录$dir/dir2的软链接"
	ln -s $dir/dir2 $dir/dir2_$hostname_$i && echo ln -s $dir/dir2  
	log_info "chmod $dir/dir1/hello 权限为777"
	chmod 777 $dir/dir1/hello && echo chmod $dir/dir1/hello
	log_info "更改$dir/dir2的所属用户所属用户组为user:group"
	chown user:group $dir/dir1/hello && echo chown $dir/dir1/hello
	log_info "创建$dir/dir1/hello并将访问时间和修改时间设置为指定的时间戳202210311200.00"
	touch -a -t 202210311200.00 $dir/dir1/hello && echo touch -a -t $dir/dir1/hello 
    
	log_info "查询$dir/dir2属性"
	stat  $dir/dir2
	log_info "查询$dir/dir1/hello属性"
	stat $dir/dir1/hello 
	
	log_info "删除文件$dir/dir2_$hostname_$i"
	rm -rf $dir/dir2_$hostname_$i && echo rm -rf $dir/dir2_$hostname_$i
	log_info "删除$dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除$dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "删除rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "删除rm -rf $dir/dir2"
	rm -rf $dir/dir2
 
	log_info "创建文件hello的软链接并设置目录dir2的属性"
	log_info "创建目录$dir/dir1"
	mkdir $dir/dir1
	log_info "创建目录$dir/dir2"
	mkdir $dir/dir2
	log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello
	log_info "创建文件$dir/dir2/hi并写入hello"
	echo hi > $dir/dir2/hi
	
	log_info "查询$dir/dir1/hello属性"
	stat $dir/dir1/hello
	log_info "创建目录$dir/dir1/hello的软链接"
	ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln -s $dir/dir1/hello
	log_info "chmod $dir/dir2 权限为755"
	chmod 755 $dir/dir2 && echo chmod $dir/dir2
	log_info "更改$dir/dir2的所属用户所属用户组为user:group"
	chown user:group $dir/dir2 && echo chown $dir/dir2
	log_info "创建$dir/dir2并将访问时间和修改时间设置为指定的时间戳202210311200.00"
	touch -a -t 202203132100 $dir/dir2 && echo touch -a -t $dir/dir2
	
	log_info "查询文件$dir/dir1/hello属性"
	stat $dir/dir1/hello
	sleep 3
	log_info "删除文件$dir/dir1/hello_$hostname_$i"
	rm -rf $dir/dir1/hello_$hostname_$i && echo rm -rf $dir/dir1/hello_$hostname_$i
	log_info "删除$dir/dir1/hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除$dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	
	log_info "删除rm -rf $dir/dir1"
 	rm -rf $dir/dir1
	log_info "删除rm -rf $dir/dir2"
	rm -rf $dir/dir2
	echo 删除用户用户组
        userdel user
        groupdel group
}

if [ $# -ne 3 ]; then
        usage
        exit
fi

if [ $1 -eq 1 ]; then
{	
	for i in `seq 1 $count`
	do
        {
	operation
        echo $i
        }
	done
}

elif [ $1 -gt 1 ]; then
{
	# read -p "请输入要并发的线程数（只能输入数字）：" thread
  thread=$1
	[ -e /tmp/fd1 ] || mkfifo /tmp/fd1
        exec 3<>/tmp/fd1
        rm -rf /tmp/fd1
	
	for i in `seq 1 $thread`
	do
        {
	echo >&3
        echo a=$i
	}
	done

        for j in `seq 1 $count`
        do
        read -u3
        {
        operation
        echo $j
        echo >&3
        }&
	done
	wait
	exec 3<&-
	exec 3>&-

}
else
	usage
fi
