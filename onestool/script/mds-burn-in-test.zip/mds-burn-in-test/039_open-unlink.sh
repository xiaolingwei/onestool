#! /bin/bash
#单/多线程实现open文件/目录的同时unlink
#######################################################################################################################
# TestCase ID(单客户端单线程):  T90_P17237 T90_P17528 T90_P17529 T90_P17530 T90_P17531 T90_P17532 T90_P17533 T90_P17534
# TestCase ID(单客户端多线程):  T90_P14979 T90_P14980 T90_P14981 T90_P14982 T90_P14983 T90_P14984 T90_P14985 T90_P14986
# TestCase ID(多客户端单线程):  T90_P16481 T90_P16482 T90_P16483 T90_P16484 T90_P15657 T90_P15656 T90_P15655 T90_P15654
# TestCase ID(多客户端多线程):  T90_P16014 T90_P16015 T90_P16016 T90_P16017 T90_P16018 T90_P16019 T90_P16020 T90_P16021

# Description:  open-unlink OP组合
# Author:       liumengyang
# Revision:     1.0.0
#######################################################################################################################

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

#定义创建的文件名前缀为主机名
file=`hostname`
#进入拷机目录，目录不存在则创建，存在则提示已存在
# read -p "请输入目录路径：" dir
dir=$2
log_info "拷机目录:$dir"
if [ ! -d $dir ]; then
        mkdir $dir
else
        log_debug "$dir exits,no need to create"
fi
#输入脚本循环次数
# read -p "请输入循环次数：" count
count=$3
log_info "脚本循环次数$count"
back_data(){

        log_info "dir下创建两个备用目录,目录下预埋文件"
        mkdir $dir/dir1 && echo "mkdir $dir/dir1"
        mkdir $dir/dir2 && echo "mkdir $dir/dir2"
        for ((n=1; n<=5;n++))
        do
                touch "$dir/dir1/file${n}.txt" && echo "touch $dir/dir1/file${n}.txt"
                echo "this is the content of $dir/dir1/file${n}.txt" > "$dir/dir1/file${n}.txt"
                mkdir "$dir/dir1/testdir${n}" && echo "mkdir $dir/dir1/testdir${n}"
                echo "this is a file in testdir${n}" > $dir/dir1/testdir${n}/testfile${n}.txt
        done
        for ((m=1; m<=5;m++))
        do
                touch "$dir/dir2/file${m}.txt" && echo "touch $dir/dir2/file${m}.txt"
                echo "this is the content of $dir/dir2/file${m}.txt" > "$dir/dir2/file${m}.txt"
                mkdir "$dir/dir2/testdir${m}" && echo "mkdir $dir/dir2/testdir${m}"
                echo "this is a file in testdir${m}" > $dir/dir2/testdir${m}/testfile${m}.txt
        done
}
operation(){
        log_info "打开目录的同时删除同一目录"
        cd $dir/dir1/testdir1 && rm -rf $dir/dir1/testdir1
        log_info "打开目录后删除其他目录"
        cd $dir/dir2/testdir1 && rm -rf $dir/dir2/testdir2
        log_info "打开文件后删除同级目录"
        echo 11 >> $dir/dir1/file1.txt && rm -rf $dir/dir1/testdir2
        log_info "打开文件后删除父目录"
        echo 11 >> $dir/dir2/testdir3/testfile3.txt && rm -rf $dir/dir2/testdir3
        log_info "打开文件后删除非父目录"
        echo 11 >> $dir/dir1/testdir4/testfile4.txt && rm -rf $dir/dir1/testdir5
        log_info "打开目录后删除目录下的子目录"
        cd $dir/dir2 && rm -rf $dir/dir2/testdir4
        log_info "打开文件后删除同一文件"
        echo 11 >> $dir/dir1/file1.txt && rm -f $dir/dir1/file1.txt
        log_info "打开文件后删除同一目录下文件"
        echo 11 >> $dir/dir2/file1.txt && rm -f $dir/dir2/file2.txt
        log_info "打开文件后删除其他目录下文件"
        echo 11 >> $dir/dir2/file1.txt && rm -f $dir/dir1/file2.txt
        log_info "打开目录后删除目录下文件"
        cd $dir/dir1 && rm -f $dir/dir1/file3.txt
        log_info "打开目录后删除其他目录下文件"
        cd $dir/dir1 && rm -f $dir/dir2/file1.txt

        log_info "查看目录列表"
        echo "$dir/dir1目录的内容：" && ls -l $dir/dir1
        echo "$dir/dir2目录的内容：" && ls -l $dir/dir2

}
teardown() {
    # 检查目录是否存在
    if [ -d "${dir}" ]; then
        log_info "开始清空本次循环所产生的目录文件"
        # 递归删除指定目录中的所有文件和子目录
        rm -rf "${dir}"/*
        log_info "删除完成本次循环所产生的目录文件"
    else
        # 目录不存在时输出错误信息
        log_err "Directory does not exist: ${dir}"
    fi
}

#根据输入开始单线程/多线程测试
#如果输入不正确，则输出usage内容
if [ $# -ne 3 ];then
        usage
        exit
fi
#单线程，则直接执行operation，拷机预设的count次
if [ $1 -eq 1 ];then
        for i in `seq 1 $count`
        do
                back_data
                operation
		sleep 3
                teardown
                log_info "--- 第$i次循环 ---"
        done
#多线程
elif [ $1 -gt 1 ];then
{
        #back_data
        # read -p "请输入并发线程数（只能输入数字）：" thread
        thread=$1
	log_info "并发线程数:$thread"
        [ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
                exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
                rm -rf /tmp/fd1 #删除管道文件

        for i in `seq 1 $thread`  #实现多线程并发
        do
        {
                echo >&3 #向文件描述符为3的命名管道中写入空行
                echo a=$i
        }
        done
        #并发进行操作
        for j in `seq 1 $count`
        do
                read -u3
                {
        	back_data
                operation
		sleep 3
		teardown
                echo $j
                echo >&3
                }&
        done
        wait
        exec 3<&-
        exec 3>&-

}
else
        usage
fi
