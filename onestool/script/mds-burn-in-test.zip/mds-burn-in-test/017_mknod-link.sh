#! /bin/bash
#单/多线程实现mknod文件的同时link创建硬链接
#################################################################
# TestCase ID:  
# Description:  makenod-link OP组合
# Author:       zhuxiaohong
# Revision:     1.0.0
#################################################################
source ./log.sh
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

#定义创建的文件名前缀为主机名
file=`hostname`
#进入拷机目录，目录不存在则创建，存在则提示已存在
# read -p "请输入目录路径：" dir
dir=$2

if [ ! -d $dir ]; then
        mkdir $dir
else
        log_info "$dir exits,no need to create"
fi
#输入脚本循环次数
# read -p "请输入循环次数：" count
count=$3

operation(){
		#dir下创建两个备用目录,目录下预埋文件
		log_info "$dir下创建两个备用目录,目录下预埋文件"
        mkdir $dir/dir1 && log_debug "mkdir $dir/dir1"
        mkdir $dir/dir2 && log_debug "mkdir $dir/dir2"
        touch $dir/dir1/test.txt && echo "hello " > $dir/dir1/test.txt && log_debug "touch $dir/dir1/test.txt && echo hello  > $dir/dir1/test.txt"
		touch $dir/dir2/test.txt && echo "word " > $dir/dir2/test.txt  && log_debug "touch $dir/dir2/test.txt && echo word > $dir/dir2/test.txt"
		
        #创建文件后link同一文件
		log_info "创建文件后link同一文件"
        mknod $dir/${file}-$i.txt c $i $i && log_debug "mknod $dir/${file}-$i.txt c $i $i" 
		ln $dir/${file}-$i.txt $dir/${file}-$i-1.txt && log_debug "ln $dir/${file}-$i.txt $dir/${file}-$i-1.txt"
        #创建文件后link同一目录下文件
		log_info "创建文件后link同一目录下文件"
        mknod $dir/dir1/${file}-$i.txt c $((i+10)) $((i+10)) && log_debug "mknod $dir/dir1/${file}-$i.txt c $((i+10)) $((i+10))"
		ln $dir/dir1/test.txt $dir/dir1/test-i.txt && log_debug "ln $dir/dir1/test.txt $dir/dir1/test-i.txt"
        #创建文件后link其他目录下文件
		log_info "创建文件后link其他目录下文件"
        mknod $dir/dir1/${file}-$i-1.txt c $((i+20)) $((i+20)) && log_debug "mknod $dir/dir1/${file}-$i-1.txt c $((i+20)) $((i+20))"
		ln $dir/dir2/test.txt $dir/dir2/test-i.txt && log_debug "ln $dir/dir2/test.txt $dir/dir2/test-i.txt"

        #查看目录列表
		log_info "$dir目录的内容：" && ls -l $dir
        log_info "$dir/dir1目录的内容：" && ls -l $dir/dir1
        log_info "$dir/dir2目录的内容：" && ls -l $dir/dir2

        #清空本次循环所产生目录
		log_info "清空本次循环所产生目录"
        rm -rf $dir/*

}
#根据输入开始单线程/多线程测试
#如果输入不正确，则输出usage内容
if [ $# -ne 3 ];then
        usage
        exit
fi
#单线程，则直接执行operation，拷机预设的count次
if [ $1 -eq 1 ];then
        for i in `seq 1 $count`
        do
				log_info "--- 第$i次循环 ---"
                operation
        done
#多线程
elif [ $1 -gt 1 ];then
{
        #back_data
        # read -p "请输入并发线程数（只能输入数字）：" thread
        thread=$1
        [ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
                exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
                rm -rf /tmp/fd1 #删除管道文件

        for i in `seq 1 $thread`  #实现多线程并发
        do
        {
                echo >&3 #向文件描述符为3的命名管道中写入空行
                echo a=$i
        }
        done
        #并发进行open-rename操作
        for j in `seq 1 $count`
        do
				log_info "--- $thread多线程第$j次循环 ---"
                read -u3
                {
                        operation
                        echo $j
                        echo >&3
                }&
        done
        wait
        exec 3<&-
        exec 3>&-

}
else
        usage
fi
