#! /bin/bash
#单/多线程实现mkdir文件的同时setattr
#################################################################
# TestCase ID:  mkdir-setattr OP组合
# Description:  单/多线程实现mkdir创建一个目录后setattr属性
# Author:    hys46897
# Revision:    1.0.0

#################################################################
source ./log.sh
#脚本用法
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}
#参数校验
validate_parms(){

	#根据输入开始单线程/多线程测试
	#如果输入不正确，则输出usage内容
	if [ $# -ne 3 ];then
			usage
			exit
	fi
	#单线程，则直接执行operation，拷机预设的count次
	if [ $1 -eq 1 ];then
			for i in `seq 1 $count`
			do
					back_data
					operation
					echo "--- 第$i次循环 ---"
			done
	#多线程
	elif [ $1 -gt 1 ];then
	{
			back_data
			# read -p "请输入并发线程数（只能输入数字）：" thread
			thread=$1
			[ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
					exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
					rm -rf /tmp/fd1 #删除管道文件

			for i in `seq 1 $thread`  #实现多线程并发
			do
			{
					echo >&3 #向文件描述符为3的命名管道中写入空行
					echo a=$i
			}
			done
			#并发进行操作
			for j in `seq 1 $count`
			do
					read -u3
					{
					operation
					echo $j
					echo >&3
					}&
			done
			wait
			exec 3<&-
			exec 3>&-

	}
	else
			usage
	fi
}

back_data(){
		#dir下创建备用目录,目录下预埋文件
		log_info "创建$dir/dir1目录"
		mkdir $dir/dir1
		log_info "创建$dir/dir1/dir_test,并创建file.txt写入hello"
		mkdir $dir/dir1/dir_test && echo "hello" > $dir/dir1/dir_test/file.txt
		log_info "创建$dir/dir1/test.txt文件"
		touch $dir/dir1/test.txt
		mkdir $dir/dir2
		mkdir $dir/dir2
		log_info "创建$dir/dir2/dir_test,并创建file.txt写入hello"
		mkdir $dir/dir2/dir_test && echo "hello" > $dir/dir2/dir_test/file.txt
		log_info "创建$dir/dir2/test.txt文件"
		touch $dir/dir2/test.txt
}
operation(){
       
         
		#创建目录的同时setattr同级文件
		log_info "创建$dir/dir1/testdir1"
    mkdir $dir/dir1/testdir1
    log_info "创建$dir/dir1/testdir1/file1.txt,并写入hello"
    echo "hello" > $dir/dir1/testdir1/file1.txt && echo "mkdir $dir/dir1/testdir1"
    log_info "设置$dir/dir1/test.txt chmod 777"
		chmod 777 $dir/dir1/test.txt
    #创建目录后setattr其他目录下文件
    log_info "$dir/dir1/testdir1-1"
    mkdir $dir/dir1/testdir1-1
    log_info "创建$dir/dir1/testdir1-1/file1.txt并写入hello"
    echo "hello" > $dir/dir1/testdir1-1/file1.txt && echo "mkdir $dir/dir1/testdir1-1"
    log_info "设置$dir/dir2/test.txt chmod 777"
		chmod 777 $dir/dir2/test.txt
		#创建目录的同时setattr父目录
		log_info "创建$dir/dir2/dir_test/testdir1"
    mkdir $dir/dir2/dir_test/testdir1
    log_info "创建$dir/dir2/dir_test/testdir1/file1.txt,并写入hello"
    echo "hello" > $dir/dir2/dir_test/testdir1/file1.txt && echo "mkdir $dir/dir1/dir_test/testdir1"
    log_info "设置$dir/dir2/dir_test chmod 777"
		chmod 777 $dir/dir2/dir_test
        #创建目录后setattr同级目录
    mkdir $dir/dir1/testdir1-2
    log_info "创建$dir/dir1/testdir1-2/file1.txt,并写入hello"
    echo "hello" > $dir/dir1/testdir1-2/file1.txt && echo "mkdir $dir/dir1/testdir1-2"
    log_info "设置$dir/dir1/dir_test chmod 777"
		chmod 777 $dir/dir1/dir_test
        #创建目录后setattr其他目录
    log_info "创建$dir/dir2/testdir1"
    mkdir $dir/dir2/testdir1
    log_info "$dir/dir2/testdir1/file1.txt并写入hello"
    echo "hello" > $dir/dir2/testdir1/file1.txt && echo "mkdir $dir/dir2/testdir1"
    log_info "设置$dir/dir1 chmod 777"
		chmod 777 $dir/dir1
		#创建目录后setattr同一目录
		log_info "创建$dir/dir2/testdir1-1 "
		mkdir $dir/dir2/testdir1-1
		log_info "创建$dir/dir2/testdir1-1/file1.txt,并写入hello"
		echo "hello" > $dir/dir2/testdir1-1/file1.txt && echo "mkdir $dir/dir2/testdir1-1"
		log_info "设置$dir/dir2/testdir1-1 chmod 777"
		chmod 777 $dir/dir2/testdir1-1
        
		
        #查看目录列表
    echo "$dir目录下内容：" && ls -l $dir
		for ((k=1; k<=2; k++))
		do
			echo "$dir/dir$k目录下内容：" && ls -l $dir/dir$k
		done

        #清空本次循环所产生目录
        rm -rf $dir/*

}

main(){

	#定义创建的文件名前缀为主机名
	file=`hostname`
	#进入拷机目录，目录不存在则创建，存在则提示已存在
	read -p "请输入目录路径：" dir/
	dir=$2

	if [ ! -d $dir ]; then
			mkdir $dir
	else
			echo "$dir exits,no need to create"
	fi
	#输入脚本循环次数
	# read -p "请输入循环次数：" count
	count=$3
	validate_parms "$@"
}
main "$@"