#!/bin/bash
#!/bin/bash
######################################################################################
# TestCase ID:：readdir-rename OP组合
# Description:  单/多线程实现readdir目录的同时重命名文件/目录
# Author:       liumengyang
# Revision:     1.0.0
######################################################################################
source ./log.sh

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

#参数校验
validate_parms(){

	#根据输入开始单线程/多线程测试
	#如果输入不正确，则输出usage内容
	if [ $# -ne 3 ];then
			usage
			exit
	fi
	#单线程，则直接执行operation，拷机预设的count次
	if [ $1 -eq 1 ];then
			for i in `seq 1 $count`
			do
					operation
					log_info "------ 第$i次循环 -------"
			done
	#多线程
	elif [ $1 -gt 1 ];then
	{
			# read -p "请输入并发线程数（只能输入数字）：" thread
			thread=$1
			log_info "并发线程数：$thread"
			[ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
					exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
					rm -rf /tmp/fd1 #删除管道文件

			for i in `seq 1 $thread`  #实现多线程并发
			do
			{
					echo >&3 #向文件描述符为3的命名管道中写入空行
					echo a=$i
			}
			done
			#并发进行操作
			for j in `seq 1 $count`
			do
					read -u3
					{
					operation
					log_info "----------第$j次循环----------"
					echo >&3
					}&
			done
			wait
			exec 3<&-
			exec 3>&-

	}
	else
			usage
	fi
}

operation(){
 
	log_info "重命名目录dir1并获取目录dir1子项"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir1
 
  	mv $dir/dir1 $dir/dir1_$hostname && echo mv $dir/dir1
	mv $dir/dir1_$hostname $dir/dir1 && echo mv $dir/dir1_$hostname
  
  	for x in {1..10}
  	do
   		mkdir -p $dir/dir1/directory$x
   		for y in {1..10}
   		do
     			touch $dir/dir1/directory$x/file$y.txt
   		done
  	done    

  	ls -a $dir/dir1 && echo ls -a $dir/dir1
  	ls -R $dir/dir1 && echo ls -R $dir/dir1
  
  	stat  $dir/dir1
 	teardown
	sleep 2
  	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello  
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi  
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2
    
	log_info "重命名文件hello,获取其父目录子项"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir1
  	stat $dir/dir1/hello

  	for x in {1..10}
  	do
   		mkdir -p $dir/dir1/directory$x
   		for y in {1..10}
   		do
     			touch $dir/dir1/directory$x/file$y.txt
   		done
  	done  
  
  	ls -a $dir/dir1 && echo ls -a $dir/dir1
  	ls -R $dir/dir1 && echo ls -R $dir/dir1 
  
  	mv $dir/dir1/hello $dir/dir2/hello_$hostname && echo mv $dir/dir1/hello
	mv $dir/dir2/hello_$hostname $dir/dir1/hello && echo mv $dir/dir2/hello_$hostname
   
  	stat  $dir/dir1
  	stat $dir/dir1/hello 
	teardown
        sleep 2
  	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello  
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi  
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2
     
	log_info "获取目录dir1子项，重命名目录dir2"
 	mkdir $dir/dir1
	mkdir $dir/dir2  
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir1
  	stat $dir/dir2

  	for x in {1..10}
  	do
   		mkdir -p $dir/dir1/directory$x
   		for y in {1..10}
   		do
     			touch $dir/dir1/directory$x/file$y.txt
   		done
  	done  

  	ls -a $dir/dir1 && echo ls -a $dir/dir1
  	ls -R $dir/dir1 && echo ls -R $dir/dir1 

  	mv $dir/dir2 $dir/dir2_$hostname && echo mv $dir/dir2
	mv $dir/dir2_$hostname $dir/dir2 && echo mv $dir/dir2_$hostname  
 
  	stat  $dir/dir1
  	stat $dir/dir2 
  	teardown
        sleep 2
 	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
 	#rm -rf $dir/dir1  
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	#rm -rf $dir/dir2
 
	log_info "获取目录dir2子项，重命名文件hello"
 	mkdir $dir/dir1
	mkdir $dir/dir2 
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir2
  	stat $dir/dir1/hello
  
  	for x in {1..10}
  	do
   		mkdir -p $dir/dir2/directory$x
   		for y in {1..10}
   		do
     			touch $dir/dir2/directory$x/file$y.txt
   		done
  	done  
  
  	ls -a $dir/dir2 && echo ls -a $dir/dir2
  	ls -R $dir/dir2 && echo ls -R $dir/dir2 
  
  	mv $dir/dir1/hello $dir/dir2/hello_$hostname && echo mv $dir/dir1/hello
	mv $dir/dir2/hello_$hostname $dir/dir1/hello && echo mv $dir/dir2/hello_$hostname
   
  	stat  $dir/dir2
  	stat $dir/dir1/hello 
 	
	teardown
	sleep 2
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  	#rm -rf $dir/dir2 
  	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	#rm -rf $dir/dir1

}
teardown() {
    # 检查目录是否存在
    if [ -d "${dir}" ]; then
        log_info "开始清空本次循环所产生的目录文件"
        # 递归删除指定目录中的所有文件和子目录
        rm -rf "${dir}"/*
        log_info "删除完成本次循环所产生的目录文件"
    else
        # 目录不存在时输出错误信息
        log_err "Directory does not exist: ${dir}"
    fi
}

main(){

	#定义创建的文件名前缀为主机名
	file=`hostname`
	#进入拷机目录，目录不存在则创建，存在则提示已存在
	# read -p "请输入目录路径：" dir
	dir=$2
	log_info "拷机目录:$dir"
	if [ ! -d $dir ]; then
			mkdir $dir
	else
			log_debug "$dir exits,no need to create"
	fi
	#输入脚本循环次数
	# read -p "请输入循环次数：" count
	count=$3
	log_info "脚本循环次数$count"
	validate_parms "$@"
}
main "$@"
