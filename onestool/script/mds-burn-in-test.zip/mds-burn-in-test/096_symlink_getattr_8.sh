#!/bin/bash
#################################################################
# TestCase ID:  symlink-getattr OP组合
# Description:  对文件目录创建符号链接并查看属性
# Author:       y33111
# Revision:     1.0.0
#################################################################
source ./log.sh

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

thread=$1
log_info "并发线程数:$thread"

dir=$2
log_info "拷机目录:$dir"

count=$3
log_info "脚本循环次数$count"

#定义创建的文件名前缀为主机名
file=`hostname`

#判断拷机目录是否，目录不存在则创建，存在则提示已存在
if [ ! -d $dir ]; then
    mkdir $dir
else
    log_debug "$dir exits,no need to create"
fi


operation(){

  log_info "创建文件hello的软链接并查询文件hello属性"
  log_info "创建目录$dir/dir1"
	mkdir $dir/dir1

  log_info "创建目录$dir/dir2"
	mkdir $dir/dir2

  log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello

  log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
 
  log_info "查询文件$dir/dir1/hello属性"
	stat $dir/dir1/hello
  
  log_info "创建$dir/dir1/hello文件的符号连接$dir/dir1/hello_$hostname_$i"
  ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln -s $dir/dir1/hello
  
  log_info "查询文件$dir/dir1/hello属性"
  stat $dir/dir1/hello

  log_info "删除$dir/dir1/hello_$hostname_$i"
  rm -rf $dir/dir1/hello_$hostname_$i && echo rm -rf $dir/dir1/hello_$hostname_$i

  log_info "删除$dir/dir1/hello"
  rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello  

  log_info "删除rf $dir/dir2/hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi  

  log_info "删除rm -rf $dir/dir1"
	rm -rf $dir/dir1

  log_info "删除rm -rf $dir/dir2"
	rm -rf $dir/dir2
  
  log_info "创建目录dir1的软链接并查询目录dir1属性"
  log_info "创建目录$dir/dir1"
	mkdir $dir/dir1

  log_info "创建目录$dir/dir2"
	mkdir $dir/dir2

  log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello

  log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
 
  log_info "查询目录$dir/dir1属性"
  stat  $dir/dir1

  log_info "创建$dir/dir1的符号连接$dir/dir1_$hostname_$i"
  ln -s $dir/dir1 $dir/dir1_$hostname_$i && echo ln -s $dir/dir1
    
  log_info "创建目录$dir/dir1"
  stat  $dir/dir1
 
  log_info "删除$dir/dir1_$hostname_$i"
  rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i

  log_info "删除$dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello

  log_info "删除$dir/dir2/hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

  log_info "删除$dir/dir1"
  rm -rf $dir/dir1

  log_info "删除$dir/dir1"
	rm -rf $dir/dir2
    
  log_info "创建父目录的软链接，查询文件hello属性"
  log_info "创建目录$dir/dir1"
	mkdir $dir/dir1

  log_info "创建目录$dir/dir2"
	mkdir $dir/dir2

  log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello

  log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
 
  log_info "查询目录$dir/dir1属性"
  stat  $dir/dir1

  log_info "查询目录$dir/dir1/hello属性"
  stat $dir/dir1/hello
  
  log_info "创建$dir/dir1的符号连接$dir/dir1_$hostname_$i"
  ln -s $dir/dir1 $dir/dir1_$hostname_$i && echo ln -s $dir/dir1
   
  log_info "查询目录$dir/dir1属性"
  stat  $dir/dir1

  log_info "查询目录$dir/dir1/hello属性"
  stat $dir/dir1/hello 
  
  log_info "删除$dir/dir1_$hostname_$i"
  rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i  

  log_info "删除$dir/dir1/hello"
  rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello

  log_info "删除$dir/dir2/hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

  log_info "删除$dir/dir1"
  rm -rf $dir/dir1

  log_info "删除$dir/dir2"
	rm -rf $dir/dir2
 
  log_info "创建文件hello的软链接并查询目录dir1的属性"	
  log_info "创建目录$dir/dir1"
	mkdir $dir/dir1

  log_info "创建目录$dir/dir2"
	mkdir $dir/dir2

  log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello

  log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
 
	log_info "查询$dir/dir1/hello属性"
  stat $dir/dir1/hello
  
  log_info "创建$dir/dir1/hello的符号连接$dir/dir1/hello_$hostname_$i"
  ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln -s $dir/dir1/hello
  
  log_info "查询目录$dir/dir1的属性"
  stat $dir/dir1

  log_info "删除$dir/dir1/hello_$hostname_$i"
  rm -rf $dir/dir1/hello_$hostname_$i && echo rm -rf $dir/dir1/hello_$hostname_$i

  log_info "删除$dir/dir1/hello"
  rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello  

  log_info "删除$dir/dir2/hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi  

  log_info "删除$dir/dir1"
	rm -rf $dir/dir1

  log_info "删除$dir/dir2"
	rm -rf $dir/dir2
      
  log_info "创建文件hi的软链接，查询文件hello属性"
  log_info "创建目录$dir/dir1"
 	mkdir $dir/dir1

  log_info "创建目录$dir/dir2"
	mkdir $dir/dir2

  log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello

  log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
 
  log_info "查询$dir/dir2/hi属性"
  stat  $dir/dir2/hi

  log_info "查询$dir/dir1/hello属性"
  stat $dir/dir1/hello
  
  log_info "创建$dir/dir2/hi的符号连接$dir/dir2/hi_$hostname_$i"
  ln -s $dir/dir2/hi $dir/dir2/hi_$hostname_$i && echo ln -s $dir/dir2/hi
  
  log_info "查询$dir/dir2/hi的属性"
  stat  $dir/dir2/hi

  log_info "查询$dir/dir1/hello的属性"
  stat $dir/dir1/hello 
  
  log_info "删除$dir/dir2/hi_$hostname_$i"
  rm -rf $dir/dir2/hi_$hostname_$i && echo rm -rf $dir/dir2/hi_$hostname_$i

  log_info "删除$dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello

  log_info "删除$dir/dir2/hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

  log_info "删除$dir/dir1"
  rm -rf $dir/dir1

  log_info "删除$dir/dir2"
	rm -rf $dir/dir2
 
  log_info "创建目录dir1的软链接，查询目录dir2属性"
  log_info "创建目录$dir/dir1"
 	mkdir $dir/dir1

  log_info "创建目录$dir/dir2"
	mkdir $dir/dir2  

  log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello

  log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
 
  log_info "查询$dir/dir1属性"
  stat  $dir/dir1

  log_info "查询$dir/dir2属性"
  stat $dir/dir2
  
  log_info "创建$dir/dir1的符号连接$dir/dir1_$hostname_$i"
  ln -s $dir/dir1 $dir/dir1_$hostname_$i && echo ln -s $dir/dir1
 
  log_info "查询$dir/dir1的属性"
  stat  $dir/dir1

  log_info "查询$dir/dir2的属性"
  stat $dir/dir2 
  
  log_info "删除$dir/dir1_$hostname_$i"
  rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i

  log_info "删除$dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello

  log_info "删除$dir/dir2/hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

  log_info "删除$dir/dir1"
  rm -rf $dir/dir1

  log_info "删除$dir/dir2"
	rm -rf $dir/dir2
 
  log_info "创建目录dir2的软链接，查询文件hello属性"
  log_info "创建目录$dir/dir1"
 	mkdir $dir/dir1

  log_info "创建目录$dir/dir2"
	mkdir $dir/dir2 

  log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello

  log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
  
  log_info "查询$dir/dir1的属性"
  stat  $dir/dir1

  log_info "查询$dir/dir1/hello的属性"
  stat $dir/dir1/hello
  
  log_info "创建$dir/dir2的符号连接$dir/dir2_$hostname_$i "
  ln -s $dir/dir2 $dir/dir2_$hostname_$i && echo ln -s $dir/dir2
   
  log_info "查询$dir/dir2的属性"
  stat  $dir/dir2

  log_info "查询$dir/dir1/hello的属性"
  stat $dir/dir1/hello 

  log_info "删除$dir/dir1_$hostname_$i"
  rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i  

  log_info "删除$dir/dir1/hello"
  rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello

  log_info "删除$dir/dir2/hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

  log_info "删除$dir/dir1"
  rm -rf $dir/dir1

  log_info "删除$dir/dir2"
	rm -rf $dir/dir2
 
  log_info "创建文件hello的软链接并查询目录dir2的属性"	
  log_info "创建目录$dir/dir1"
	mkdir $dir/dir1

  log_info "创建目录$dir/dir2"
	mkdir $dir/dir2

  log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello

  log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
 
	log_info "查询$dir/dir1/hello的属性"
  stat $dir/dir1/hello
  
  log_info "创建$dir/dir1/hello的符号连接$dir/dir1/hello_$hostname_$i"
  ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln -s $dir/dir1/hello
  
  log_info "查询$dir/dir2的属性"
  stat $dir/dir2

  log_info "删除$dir/dir1/hello_$hostname_$i"
  rm -rf $dir/dir1/hello_$hostname_$i && echo rm -rf $dir/dir1/hello_$hostname_$i

  log_info "删除$dir/dir1/hello"
  rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello  

  log_info "删除$dir/dir2/hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi  

  log_info "删除$dir/dir1"
	rm -rf $dir/dir1

  log_info "删除$dir/dir2"
	rm -rf $dir/dir2 
}

if [ $# -ne 3 ]; then
        usage
        exit
fi

if [ $1 -eq 1 ]; then
{	
	for i in `seq 1 $count`
	do
        {
	operation
        echo $i
        }
	done
}

elif [ $1 -gt 1 ]; then
{

	[ -e /tmp/fd1 ] || mkfifo /tmp/fd1
        exec 3<>/tmp/fd1
        rm -rf /tmp/fd1
	
	for i in `seq 1 $thread`
	do
        {
	echo >&3
        echo a=$i
	}
	done

        for j in `seq 1 $count`
        do
        read -u3
        {
        operation
        echo $j
        echo >&3
        }&
	done
	wait
	exec 3<&-
	exec 3>&-

}
else
	usage
fi
