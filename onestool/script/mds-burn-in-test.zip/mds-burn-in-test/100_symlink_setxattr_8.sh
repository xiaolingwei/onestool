#! /bin/bash
#单/多线程实现symlink文件的同时setxattr
source ./log.sh

#!/bin/bash
######################################################################################################################
# TestCase ID(单客户端单线程):  T90_P17627 T90_P17629 T90_P17630 T90_P17631 T90_P17632 T90_P17633 T90_P17634 T90_P17635
# TestCase ID(单客户端多线程):  T90_P15184 T90_P15185 T90_P15186 T90_P15187 T90_P15188 T90_P15190 T90_P15191 T90_P15192
# TestCase ID(多客户端单线程):  T90_P16612 T90_P16728 T90_P16729 T90_P16730 T90_P16731 T90_P16732 T90_P16733 T90_P16734
# TestCase ID(多客户端多线程):  T90_P16215 T90_P16216 T90_P16217 T90_P16218 T90_P16219 T90_P16220 T90_P16221 T90_P16222
# Description:  symlink-setattr OP组合
# Author:       songyunfan
# Revision:     1.0.0
######################################################################################################################

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

hostname=`hostname`
# read -p "请输入要跑脚本的目录全路径（eg:/mnt/note3/dir）：" dir
dir=$2

if [ ! -d $dir ];then
	mkdir $dir
else
	echo "$dir exits,no need to create"
fi

# read -p "请输入脚本要循环的次数（只能输入数字）：" count
count=$3

user_group()
{
	USERNAME=user
	GROUPNAME=group
	# 判断用户/用户组是否存在
	USER_EXISTS=$(id -u $USERNAME)

	if [ -z "$USER_EXISTS" ]; then
		log_warn "用户不存在"
		# 检查是否已经在使用默认命令进行某些操作时显示这个用户已存在信息
		if ! grep -q "^$USERNAME:" /etc/passwd; then
			# 创建新用户，这里可以根据需要自定义新用户的信息和配置等参数
			useradd $USERNAME
			log_info "创建用户 $USERNAME 成功！"
		else
			log_warn "用户已存在！"
		fi
	else
		log_warn "用户已存在！"
	fi

	# 使用grep命令检查用户组是否存在
	if grep -q "^$GROUPNAME:" /etc/group; then
		log_info "用户组 $GROUPNAME 已存在。"
	else
		# 用户组不存在，创建新的用户组
		groupadd $GROUPNAME
		log_info "已创建用户组 $GROUPNAME"
	fi
}

operation(){
	log_info "创建文件hello的软链接并设置文件hello的扩展属性"
 	log_info "创建目录$dir/dir1"
	mkdir $dir/dir1
	log_info "创建目录$dir/dir2"
	mkdir $dir/dir2
	log_info "创建文件$dir/dir1/hello并写入hello"
	echo hello > $dir/dir1/hello
	log_info "创建文件$dir/dir2/hi并写入hi"
	echo hi > $dir/dir2/hi
	log_info "查询文件$dir/dir1/hello属性"
	stat $dir/dir1/hello
	log_info "创建文件hello的软链接并写入hello"
	ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln -s $dir/dir1/hello
	log_info "setfattr -n user.myattribute -v \"value\" $dir/dir1/hello"
	setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
	log_info "setfattr -n security.selinux -v \"label\" $dir/dir1/hello"
	setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
	log_info "chattr +i $dir/dir1/hello"
	chattr +i $dir/dir1/hello && echo chattr $dir/dir1/hello
	log_info "getfattr -d $dir/dir1/hello"
	getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
	log_info "lsattr $dir/dir1/hello"
	lsattr $dir/dir1/hello && echo lsattr $dir/dir1/hello 
	log_info "chattr -i $dir/dir1/hello"
	chattr -i $dir/dir1/hello && echo removechattr $dir/dir1/hello
	log_info "查询文件$dir/dir1/hello属性"
	stat $dir/dir1/hello
	log_info "rm -rf $dir/dir1/hello_$hostname_$i"
	rm -rf $dir/dir1/hello_$hostname_$i && echo rm -rf $dir/dir1/hello_$hostname_$i
	log_info "rm -rf $dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "rm -rf $dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "rm -rf $dir/dir2"
	rm -rf $dir/dir2
	log_info "创建目录dir1的软链接并设置目录dir1的扩展属性"
	log_info "mkdir $dir/dir1"
	mkdir $dir/dir1
	log_info "mkdir $dir/dir2"
	mkdir $dir/dir2
	log_info "echo hello > $dir/dir1/hello"
	echo hello > $dir/dir1/hello
	log_info "echo hi > $dir/dir2/hi"
	echo hi > $dir/dir2/hi
	log_info "stat $dir/dir1"
	stat $dir/dir1
	log_info "ln -s $dir/dir1 $dir/dir1_$hostname_$i"
	ln -s $dir/dir1 $dir/dir1_$hostname_$i && echo ln -s $dir/dir1
	log_info "setfattr -n user.myattribute -v \"value\" $dir/dir1"
	setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
	log_info "setfattr -n security.selinux -v \"label\" $dir/dir1"
	setfattr -n security.selinux -v "label" $dir/dir1 && echo setxattr security $dir/dir1
	log_info "chattr +i $dir/dir1"
	chattr +i $dir/dir1 && echo chattr $dir/dir1
	log_info "getfattr -d $dir/dir1"
	getfattr -d $dir/dir1 && echo getxattr $dir/dir1
	log_info "lsattr $dir/dir1"
	lsattr $dir/dir1 && echo lsattr $dir/dir1 
	log_info "stat $dir/dir1"
	stat $dir/dir1
	log_info "chattr -i $dir/dir1"
	chattr -i $dir/dir1 && echo removechattr $dir/dir1 
	log_info "rm -rf $dir/dir1_$hostname_$i"
	rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i
	log_info "rm -rf $dir/dir1/hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "rm -rf $dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "rm -rf $dir/dir2"
	rm -rf $dir/dir2
	log_info "创建父目录的软链接，并给文件hello设置扩展属性"
	log_info "mkdir $dir/dir1"
 	mkdir $dir/dir1
	log_info "mkdir $dir/dir2"
	mkdir $dir/dir2
	log_info "echo hello > $dir/dir1/hello"
	echo hello > $dir/dir1/hello
	log_info "echo hi > $dir/dir2/hi"
	echo hi > $dir/dir2/hi
	log_info "stat  $dir/dir1"
	stat  $dir/dir1
	log_info "stat $dir/dir1/hello"
	stat $dir/dir1/hello
	log_info "ln -s $dir/dir1 $dir/dir1_$hostname_$i"
	ln -s $dir/dir1 $dir/dir1_$hostname_$i && echo ln -s $dir/dir1
    log_info "setfattr -n user.myattribute -v \"value\" $dir/dir1/hello"
	setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
	log_info "getfattr -d $dir/dir1/hello"
	getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
	log_info "stat  $dir/dir1"
	stat  $dir/dir1
	log_info "stat $dir/dir1/hello"
	stat $dir/dir1/hello
	log_info "rm -rf $dir/dir1_$hostname_$i"
	rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i 
	log_info "rm -rf $dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "rm -rf $dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "rm -rf $dir/dir2"
	rm -rf $dir/dir2
	
	log_info "创建文件hello的软链接，并给其父目录设置扩展属性"
	log_info "mkdir $dir/dir1"
 	mkdir $dir/dir1
	log_info "mkdir $dir/dir2"
	mkdir $dir/dir2
	log_info "echo hello > $dir/dir1/hello"
	echo hello > $dir/dir1/hello
	log_info "echo hi > $dir/dir2/hi"
	echo hi > $dir/dir2/hi
	log_info "stat  $dir/dir1"
	stat  $dir/dir1
	log_info "stat $dir/dir1/hello"
	stat $dir/dir1/hello
	log_info "ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i"
	ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln -s $dir/dir1/hello
	log_info "setfattr -n user.myattribute -v \"value\" $dir/dir1"
	setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
	log_info "setfattr -n security.selinux -v \"label\" $dir/dir1"
	setfattr -n security.selinux -v "label" $dir/dir1 && echo setxattr security $dir/dir1
	log_info "chattr +i $dir/dir1"
	chattr +i $dir/dir1 && echo chattr $dir/dir1
	log_info "getfattr -d $dir/dir1"
	getfattr -d $dir/dir1 && echo getxattr $dir/dir1
	log_info "lsattr $dir/dir1"
	lsattr $dir/dir1 && echo lsattr $dir/dir1 
	log_info "chattr -i $dir/dir1"
	chattr -i $dir/dir1 && echo removechattr $dir/dir1 
	log_info "stat  $dir/dir1"
	stat  $dir/dir1
	log_info "stat $dir/dir1/hello"
	stat $dir/dir1/hello
	log_info "rm -rf $dir/dir1/hello_$hostname_$i"
	rm -rf $dir/dir1/hello_$hostname_$i && echo rm -rf $dir/dir1/hello_$hostname_$i
	log_info "rm -rf $dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "rm -rf $dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "rm -rf $dir/dir2"
	rm -rf $dir/dir2 
	log_info "创建文件hi的软链接并设置文件hello的扩展属性"
	log_info "mkdir $dir/dir1"
	mkdir $dir/dir1
	log_info "mkdir $dir/dir2"
	mkdir $dir/dir2
	log_info "echo hello > $dir/dir1/hello"
	echo hello > $dir/dir1/hello
	log_info "echo hi > $dir/dir2/hi"
	echo hi > $dir/dir2/hi
	log_info "stat  $dir/dir2/hi"
	stat  $dir/dir2/hi
	log_info "stat $dir/dir1/hello"
	stat $dir/dir1/hello
	log_info "ln -s $dir/dir2/hio $dir/dir2/hi_$hostname_$i"
	ln -s $dir/dir2/hio $dir/dir2/hi_$hostname_$i && echo ln -s $dir/dir2/hi
#  setfattr -n user.myattribute -v "value" $dir/dir2/hi && echo setxattr user $dir/dir2/hi
	log_info "setfattr -n security.selinux -v \"label\" $dir/dir1/hello"
	setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
	log_info "getfattr -d $dir/dir1/hello"
	getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello 
	log_info "stat  $dir/dir2/hi"
	stat  $dir/dir2/hi
	log_info "stat $dir/dir1/hello"
	stat $dir/dir1/hello
	log_info "rm -rf $dir/dir2/hi_$hostname_$i"
	rm -rf $dir/dir2/hi_$hostname_$i && echo rm -rf $dir/dir2/hi_$hostname_$i  
	log_info "rm -rf $dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "rm -rf $dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "rm -rf $dir/dir2"
	rm -rf $dir/dir2
	log_info "创建目录dir1的软链接并设置目录dir2的扩展属性"
	log_info "mkdir $dir/dir1"
	mkdir $dir/dir1
	log_info "mkdir $dir/dir2"
	mkdir $dir/dir2
	log_info "echo hello > $dir/dir1/hello"
	echo hello > $dir/dir1/hello
	log_info "echo hi > $dir/dir2/hi"
	echo hi > $dir/dir2/hi
	log_info "stat  $dir/dir1"
	stat  $dir/dir1
	log_info "stat $dir/dir2"
	stat $dir/dir2
	log_info "ln -s $dir/dir1 $dir/dir1_$hostname_$i"
	ln -s $dir/dir1 $dir/dir1_$hostname_$i && echo ln -s $dir/dir1 
#  setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
	log_info "setfattr -n security.selinux -v \"label\" $dir/dir2"
	setfattr -n security.selinux -v "label" $dir/dir2 && echo setxattr security $dir/dir2
  
#  getfattr -d $dir/dir1 && echo getxattr $dir/dir1
	log_info "getfattr -d $dir/dir2"
	getfattr -d $dir/dir2 && echo getxattr $dir/dir2
	log_info "stat  $dir/dir1"
	stat  $dir/dir1
	log_info "stat $dir/dir2"
	stat $dir/dir2
	log_info "rm -rf $dir/dir1_$hostname_$i"
	rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i
	log_info "rm -rf $dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "rm -rf $dir/dir2"
	rm -rf $dir/dir2
	log_info "rm -rf $dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "创建目录dir2的软链接，并给文件hello设置扩展属性"
 	log_info "mkdir $dir/dir1"
	mkdir $dir/dir1
	log_info "mkdir $dir/dir2"
	mkdir $dir/dir2
	log_info "echo hello > $dir/dir1/hello"
	echo hello > $dir/dir1/hello
	log_info "echo hi > $dir/dir2/hi"
	echo hi > $dir/dir2/hi
	log_info "stat  $dir/dir2"
	stat  $dir/dir2
	log_info "stat $dir/dir1/hello"
	stat $dir/dir1/hello
	log_info "ln -s $dir/dir2 $dir/dir2_$hostname_$i"
	ln -s $dir/dir2 $dir/dir2_$hostname_$i && echo ln -s $dir/dir12
    log_info "setfattr -n user.myattribute -v \"value\" $dir/dir1/hello"
	setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
	log_info "getfattr -d $dir/dir1/hello"
	getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
	log_info "stat  $dir/dir2"
	stat  $dir/dir2
	log_info "stat $dir/dir1/hello"
	stat $dir/dir1/hello 
	log_info "rm -rf $dir/dir2_$hostname_$i"
	rm -rf $dir/dir2_$hostname_$i && echo rm -rf $dir/dir2_$hostname_$i
	log_info "rm -rf $dir/dir1/hello"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "rm -rf $dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "rm -rf $dir/dir2"
	rm -rf $dir/dir2
	log_info "创建文件hello的软链接，并给目录dir2设置扩展属性"
	log_info "mkdir $dir/dir1"
 	mkdir $dir/dir1
	log_info "mkdir $dir/dir2"
	mkdir $dir/dir2
	log_info "echo hello > $dir/dir1/hello"
	echo hello > $dir/dir1/hello
	log_info "echo hi > $dir/dir2/hi"
	echo hi > $dir/dir2/hi
	log_info "stat  $dir/dir2"
	stat  $dir/dir2
	log_info "stat $dir/dir1/hello"
	stat $dir/dir1/hello
	log_info "ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i"
	ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln -s $dir/dir1/hello
	log_info "setfattr -n user.myattribute -v \"value\" $dir/dir2"
	setfattr -n user.myattribute -v "value" $dir/dir2 && echo setxattr user $dir/dir2
	log_info "setfattr -n security.selinux -v \"label\" $dir/dir2"
	setfattr -n security.selinux -v "label" $dir/dir2 && echo setxattr security $dir/dir2
	log_info "getfattr -d $dir/dir2"
	getfattr -d $dir/dir2 && echo getxattr $dir/dir2
	log_info "stat $dir/dir2"
	stat $dir/dir2
	log_info "stat $dir/dir1/hello"
	stat $dir/dir1/hello
	log_info "rm -rf $dir/dir1/hello_$hostname_$i"
	rm -rf $dir/dir1/hello_$hostname_$i && echo rm -rf $dir/dir1/hello_$hostname_$i        
 	log_info "rm -rf $dir/dir1/hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "rm -rf $dir/dir2/hi"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	log_info "rm -rf $dir/dir1"
	rm -rf $dir/dir1
	log_info "rm -rf $dir/dir2"
	rm -rf $dir/dir2 
 
  
}

if [ $# -ne 3 ]; then
        usage
        exit
fi

if [ $1 -eq 1 ]; then
{	
	for i in `seq 1 $count`
	do
        {
	operation
        echo $i
        }
	done
}

elif [ $1 -gt 1 ]; then
{
	# read -p "请输入要并发的线程数（只能输入数字）：" thread
  thread=$1
	[ -e /tmp/fd1 ] || mkfifo /tmp/fd1
        exec 3<>/tmp/fd1
        rm -rf /tmp/fd1
	
	for i in `seq 1 $thread`
	do
        {
	echo >&3
        echo a=$i
	}
	done

        for j in `seq 1 $count`
        do
        read -u3
        {
        operation
        echo $j
        echo >&3
        }&
	done
	wait
	exec 3<&-
	exec 3>&-

}
else
	usage
fi
