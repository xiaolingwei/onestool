#!/bin/bash

# 创建所需的根目录
mkdir -p /mnt/fpns01
mkdir -p /mnt/fpns02

# 用于生成随机目录名称的函数
generate_random_name() {
  local random_name=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1)
  echo $random_name
}

# 在 /mnt/fpns01 下创建10个子目录
for i in {1..10}; do
  dirname=$(generate_random_name)
  mkdir -p /mnt/fpns01/$dirname
  
  # 在每个子目录里创建10个子目录
  for j in {1..10}; do
    subdirname=$(generate_random_name)
    mkdir -p /mnt/fpns01/$dirname/$subdirname
  done

  # 在每个子目录里创建1000个大小随机的文件
  for k in {1..1000}; do
    filename=$(generate_random_name).txt
    filesize=$(( RANDOM % 200 + 10 ))  # 生成10KB到200MB之间的随机数，单位为KB
    dd if=/dev/urandom of=/mnt/fpns01/$dirname/$filename bs=1024 count=$filesize 2>/dev/null
  done
done

# 将 /mnt/fpns01 下的10个子目录移动到 /mnt/fpns02
for dir in /mnt/fpns01/*; do
  if [ -d "$dir" ]; then
    mv $dir /mnt/fpns02/
  fi
done

echo "脚本执行完毕！"
