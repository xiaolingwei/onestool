#!/bin/bash
#单/多线程实现
#################################################################
# TestCase ID:  setattr-unlink OP组合
# Description:  单/多线程实现setattr,删除
# Author:    hys46897
# Revision:    1.0.0

#################################################################
source ./log.sh
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

hostname=`hostname`
# read -p "请输入要跑脚本的目录全路径（eg:/mnt/note3/dir）：" dir
dir=$2

if [ ! -d $dir ];then
	mkdir $dir
else
	echo "$dir exits,no need to create"
fi

# read -p "请输入脚本要循环的次数（只能输入数字）：" count
count=$3

operation(){
  log_info "创建dir1和dir2"
  echo 设置文件hello的属性及删除其扩展属性
	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat hello"
	stat $dir/dir1/hello
  log_info "给hello文件设置777权限"
	chmod 777 $dir/dir1/hello && echo chmod $dir/dir1/hello
	log_info "给hello文件设置所创建用户与组的权限"
	chown user:group $dir/dir1/hello && echo chown $dir/dir1/hello
	log_info "设置hello文件的atime时间为02210311200.00"
  touch -a -t 202210311200.00 $dir/dir1/hello && echo touch -a -t $dir/dir1/hello
  log_info "设置 hello文件的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
  log_info "设置 hello文件的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  log_info "使用 chattr 命令给hello设置属性"
  chattr +i $dir/dir1/hello && echo chattr $dir/dir1/hello
  
 # getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello 
 # lsattr $dir/dir1/hello && echo lsattr $dir/dir1/hello 
  log_info "使用 chattr 命令移除hello属性"
  chattr -i $dir/dir1/hello && echo removechattr $dir/dir1/hello
  log_info "使用 setfattr 命令移除hello属性user.myattribute"
  setfattr -x user.myattribute $dir/dir1/hello && echo removexattr user $dir/dir1/hello
  log_info "使用 setfattr 命令移除hello属性security.selinux"
  setfattr -x security.selinux $dir/dir1/hello && echo removexattr security $dir/dir1/hello 
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "删除 hello"
  rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
  rm -rf $dir/dir1
  log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置目录dir1的属性及删除其扩展属性"
  echo 设置目录dir1的属性及删除其扩展属性
  log_info "创建dir1和dir2"
	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir1"
	stat $dir/dir1
  log_info "给dir1设置777权限"
	chmod 777 $dir/dir1 && echo chmod $dir/dir1
	log_info "给dir1设置所创建用户与组的权限"
	chown user:group $dir/dir1 && echo chown $dir/dir1
	log_info "设置dir1的atime时间为02210311200.00"
  touch -a -t 202210311200.00 $dir/dir1 && echo touch -a -t $dir/dir1
  log_info "使用 setfattr 命令设置dir1属性value"
  setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
  log_info "使用 setfattr 命令设置dir1属性label"
  setfattr -n security.selinux -v "label" $dir/dir1 && echo setxattr security $dir/dir1
  log_info "使用 chattr 命令给dir1设置属性"
  chattr +i $dir/dir1 && echo chattr $dir/dir1
  
 # getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello 
 # lsattr $dir/dir1/hello && echo lsattr $dir/dir1/hello 
  log_info "使用 chattr 命令移除dir1属性"
  chattr -i $dir/dir1 && echo removechattr $dir/dir1
  log_info "使用 setfattr 命令移除dir1属性user.myattribute"
  setfattr -x user.myattribute $dir/dir1 && echo removexattr user $dir/dir1
  log_info "使用 setfattr 命令移除dir1属性security.selinux"
  setfattr -x security.selinux $dir/dir1 && echo removexattr security $dir/dir1
  log_info "stat dir1"
  stat $dir/dir1
  log_info "删除 hello"
  rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
  rm -rf $dir/dir1
  log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置父目录的属性,删除文件hello的扩展属性"
  echo 设置父目录的属性,删除文件hello的扩展属性
  log_info "创建dir1和dir2"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir1"
  stat  $dir/dir1
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "给dir1设置755权限"
  chmod 755 $dir/dir1 && echo chmod $dir/dir1
  log_info "给dir1设置所创建用户与组的权限"
  chown user:group $dir/dir1 && echo chown $dir/dir1
  log_info "设置dir1的atime时间为02210311200.00"
  touch -a -t 202203132100 $dir/dir1 && echo touch -a -t $dir/dir1
  log_info "设置hello的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
  log_info "设置hello的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  log_info "使用 chattr 命令给hello设置属性"
  chattr +i $dir/dir1/hello && echo chattr $dir/dir1/hello
  
#  getfattr -d $dir/dir1 && echo getxattr $dir/dir1
#  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
  log_info "使用 chattr 命令移除hello属性"
  chattr -i $dir/dir1/hello && echo removechattr $dir/dir1/hello
  log_info "使用 setfattr 命令移除hello属性user.myattribute"
  setfattr -x user.myattribute $dir/dir1/hello && echo removexattr user $dir/dir1/hello
  log_info "使用 setfattr 命令移除hello属性security.selinux"
  setfattr -x security.selinux $dir/dir1/hello && echo removexattr security $dir/dir1/hello 
  log_info "stat dir1"
  stat  $dir/dir1
  log_info "stat dir1/hello"
  stat $dir/dir1/hello 
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置文件hello的属性,删除其父目录的扩展属性"
  echo 设置文件hello的属性,删除其父目录的扩展属性
  log_info "创建dir1和dir2"
	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir1"
  stat $dir/dir1
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "给hello文件设置777权限"
	chmod 777 $dir/dir1/hello && echo chmod $dir/dir1/hello
	log_info "给hello文件设置所创建用户与组的权限"
	chown user:group $dir/dir1/hello && echo chown $dir/dir1/hello
	log_info "设置hello文件的atime时间为02210311200.00"
  touch -a -t 202210311200.00 $dir/dir1/hello && echo touch -a -t $dir/dir1/hello
  log_info "设置 dir1的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
  log_info "设置 dir1的扩展属性 value"
  setfattr -n security.selinux -v "label" $dir/dir1 && echo setxattr security $dir/dir1
  log_info "使用 chattr 命令给dir1设置属性"
  chattr +i $dir/dir1 && echo chattr $dir/dir1
  log_info "使用 chattr 命令移除dir1属性"
  chattr -i $dir/dir1 && echo removechattr $dir/dir1
  log_info "使用 setfattr 命令移除dir1属性user.myattribute"
  setfattr -x user.myattribute $dir/dir1 && echo removexattr user $dir/dir1
  log_info "使用 setfattr 命令移除dir1属性security.selinux"
  setfattr -x security.selinux $dir/dir1 && echo removexattr security $dir/dir1
  log_info "stat dir1"
  stat $dir/dir1
  log_info "stat hello"
  stat $dir/dir1/hello  
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置文件hi的属性,删除文件hello的扩展属性"
  echo 设置文件hi的属性,删除文件hello的扩展属性
  log_info "创建dir1和dir2"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat hi"
  stat  $dir/dir2/hi
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "给hi文件设置777权限"
	chmod 777 $dir/dir2/hi && echo chmod $dir/dir2/hi
	log_info "给hi文件设置所创建用户与组的权限"
	chown user:group $dir/dir2/hi && echo chown $dir/dir2/hi
	log_info "设置hi文件的atime时间为02210311200.00"
  touch -a -t 202210311200.00 $dir/dir2/hi && echo touch -a -t $dir/dir2/hi
  log_info "设置 hi文件的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
  log_info "设置 hello文件的扩展属性 value"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  log_info "使用 chattr 命令给hello设置属性"
  chattr +i $dir/dir1/hello && echo chattr $dir/dir1/hello
  
#  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello 
#  lsattr $dir/dir1/hello && echo lsattr $dir/dir1/hello 
  
#  getfattr -d $dir/dir1/hi && echo getxattr $dir/dir1/hi
  log_info "使用 chattr 命令移除hello属性"
  chattr -i $dir/dir1/hello && echo removechattr $dir/dir1/hello
  log_info "使用 setfattr 命令移除hello属性user.myattribute"
  setfattr -x user.myattribute $dir/dir1/hello && echo removexattr user $dir/dir1/hello
  og_info "使用 setfattr 命令移除hello属性security.selinux"
  setfattr -x security.selinux $dir/dir1/hello && echo removexattr security $dir/dir1/hello 
  log_info "stat hi"
  stat $dir/dir2/hi
  log_info "stat hello"
  stat $dir/dir1/hello 
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置文件hello1的属性,删除文件hello的扩展属性"
  echo 设置文件hello1的属性,删除文件hello的扩展属性
  log_info "创建dir1"
 	mkdir $dir/dir1
  log_info "创建hello和hello1"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir1/hello1
  log_info "stat hello和hello1"
  stat $dir/dir1/hello1
  stat $dir/dir1/hello
  log_info "给hello1文件设置777权限"
	chmod 777 $dir/dir1/hello1 && echo chmod $dir/dir1/hello1
	log_info "给hello文件设置所创建用户与组的权限"
	chown user:group $dir/dir1/hello1 && echo chown $dir/dir1/hello1
	log_info "设置hello文件的atime时间为02210311200.00"
  touch -a -t 202210311200.00 $dir/dir1/hello1 && echo touch -a -t $dir/dir1/hello1
  log_info "设置 hello文件的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
  log_info "设置 hello文件的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  log_info "使用 chattr 命令给hello设置属性"
  chattr +i $dir/dir1/hello && echo chattr $dir/dir1/hello
  
#  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello 
#  lsattr $dir/dir1/hello && echo lsattr $dir/dir1/hello 
  
#  getfattr -d $dir/dir1/hi && echo getxattr $dir/dir1/hi
  log_info "使用 chattr 命令移除hello属性"
  chattr -i $dir/dir1/hello && echo removechattr $dir/dir1/hello
  log_info "使用 setfattr 命令移除hello属性user.myattribute"
  setfattr -x user.myattribute $dir/dir1/hello && echo removexattr user $dir/dir1/hello
  log_info "使用 setfattr 命令移除hello属性security.selinux"
  setfattr -x security.selinux $dir/dir1/hello && echo removexattr security $dir/dir1/hello 
  log_info "stat hello1"
  stat $dir/dir1/hello1
  log_info "stat hello"
  stat $dir/dir1/hello 
  log_info "删除 hello1 和hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  rm -rf $dir/dir1/hello1 && echo rm -rf $dir/dir1/hello1
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "设置目录dir1的属性,删除目录dir2的扩展属性"
  echo 设置目录dir1的属性,删除目录dir2的扩展属性
  log_info "创建dir1和dir2"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir1"
	stat $dir/dir1
	log_info "stat dir2"
  stat $dir/dir2
  log_info "给dir1设置777权限"
	chmod 777 $dir/dir1 && echo chmod $dir/dir1
	log_info "给dir1设置所创建用户与组的权限"
	chown user:group $dir/dir1 && echo chown $dir/dir1
	log_info "设置dir1的atime时间为02210311200.00"
  touch -a -t 202210311200.00 $dir/dir1 && echo touch -a -t $dir/dir1
  log_info "设置 dir2的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir2 && echo setxattr user $dir/dir2
  log_info "设置 dir2的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir2 && echo setxattr security $dir/dir2
  log_info "使用 chattr 命令给dir2设置属性"
  chattr +i $dir/dir2 && echo chattr $dir/dir2
  
 # getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello 
 # lsattr $dir/dir1/hello && echo lsattr $dir/dir1/hello 
  log_info "使用 chattr 命令移除dir2属性"
  chattr -i $dir/dir2 && echo removechattr $dir/dir2
  log_info "使用 setfattr 命令移除dir2属性user.myattribute"
  setfattr -x user.myattribute $dir/dir2 && echo removexattr user $dir/dir2
  log_info "使用 setfattr 命令移除dir2属性security.selinux"
  setfattr -x security.selinux $dir/dir2 && echo removexattr security $dir/dir2 
  log_info "stat dir1"
  stat $dir/dir1
  log_info "stat dir2"
  stat $dir/dir2
  log_info "删除 hello"
  rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
  rm -rf $dir/dir1
  log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置目录dir2的属性,删除文件hello的扩展属性"
  echo 设置目录dir2的属性,删除文件hello的扩展属性
  log_info "创建dir1和dir2"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir2"
  stat  $dir/dir2
  log_info "stat hello"
  stat $dir/dir1/hello
  log_info "给dir2设置755权限"
  chmod 755 $dir/dir2 && echo chmod $dir/dir2
  log_info "给dir2设置所创建用户与组的权限"
  chown user:group $dir/dir2 && echo chown $dir/dir2
  log_info "设置dir2的atime时间为02210311200.00"
  touch -a -t 202203132100 $dir/dir2 && echo touch -a -t $dir/dir2
  log_info "设置 hello文件的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
  log_info "设置 hello文件的扩展属性 label"
  setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
  log_info "使用 chattr 命令给hello设置属性"
  chattr +i $dir/dir1/hello && echo chattr $dir/dir1/hello
  log_info "使用 chattr 命令移除hello属性"
  chattr -i $dir/dir1/hello && echo removechattr $dir/dir1/hello
  log_info "使用 setfattr 命令移除hello属性user.myattribute"
  setfattr -x user.myattribute $dir/dir1/hello && echo removexattr user $dir/dir1/hello
  log_info "使用 setfattr 命令移除hello属性security.selinux"
  setfattr -x security.selinux $dir/dir1/hello && echo removexattr security $dir/dir1/hello 
  
#  getfattr -d $dir/dir1 && echo getxattr $dir/dir1
#  getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
  
  log_info "stat dir2"
  stat  $dir/dir2
  log_info "stat hello"
  stat $dir/dir1/hello 
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
  log_info "设置文件hello的属性,删除目录dir2的扩展属性"
  echo 设置文件hello的属性,删除目录dir2的扩展属性
  log_info "创建dir1和dir2"
	mkdir $dir/dir1
	mkdir $dir/dir2
	log_info "创建hello和hi"
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
  log_info "stat dir2"
  stat  $dir/dir2
  log_info "stat hello"
  stat $dir/dir1/hello
   log_info "给hello文件设置777权限"
	chmod 777 $dir/dir1/hello && echo chmod $dir/dir1/hello
	log_info "给hello文件设置所创建用户与组的权限"
	chown user:group $dir/dir1/hello && echo chown $dir/dir1/hello
	log_info "设置hello文件的atime时间为02210311200.00"
  touch -a -t 202210311200.00 $dir/dir1/hello && echo touch -a -t $dir/dir1/hello
  log_info "设置 dir2的扩展属性 value"
  setfattr -n user.myattribute -v "value" $dir/dir2 && echo setxattr user $dir/dir2
  log_info "设置 dir2的扩展属性 value"
  setfattr -n security.selinux -v "label" $dir/dir2 && echo setxattr security $dir/dir2
  log_info "使用 chattr 命令给dir2设置属性"
  chattr +i $dir/dir2 && echo chattr $dir/dir2
  log_info "使用 chattr 命令移除dir2属性"
  chattr -i $dir/dir2 && echo removechattr $dir/dir2
  log_info "使用 setfattr 命令移除dir2属性user.myattribute"
  setfattr -x user.myattribute $dir/dir2 && echo removexattr user $dir/dir2
  log_info "使用 setfattr 命令移除dir2属性security.selinux"
  setfattr -x security.selinux $dir/dir2 && echo removexattr security $dir/dir2 
  log_info "stat dir2"
  stat $dir/dir2
  log_info "stat hello"
  stat $dir/dir1/hello  
  log_info "删除 hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  log_info "删除 hi"
  rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  log_info "删除 dir1"
	rm -rf $dir/dir1
	log_info "删除 dir2"
	rm -rf $dir/dir2
}

if [ $# -ne 3 ]; then
        usage
        exit
fi

if [ $1 -eq 1 ]; then
{	
	for i in `seq 1 $count`
	do
        {
	operation
        echo $i
        }
	done
}

elif [ $1 -gt 1 ]; then
{
	# read -p "请输入要并发的线程数（只能输入数字）：" thread
  thread=$1
	[ -e /tmp/fd1 ] || mkfifo /tmp/fd1
        exec 3<>/tmp/fd1
        rm -rf /tmp/fd1
	
	for i in `seq 1 $thread`
	do
        {
	echo >&3
        echo a=$i
	}
	done

        for j in `seq 1 $count`
        do
        read -u3
        {
        operation
        echo $j
        echo >&3
        }&
	done
	wait
	exec 3<&-
	exec 3>&-

}
else
	usage
fi
