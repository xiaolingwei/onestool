#! /bin/bash
#单/多线程实现open文件/目录的同时removexattr
source ./log.sh

#!/bin/bash
###################################################################################################################################################################
# TestCase ID(单客户端单线程):  T90_P17249 T90_P17250 T90_P17251 T90_P17252 T90_P17253 T90_P17254 T90_P17255 T90_P17256 T90_P17257 T90_P17258 T90_P17260 T90_P17261
# TestCase ID(单客户端多线程):  T90_P15011 T90_P15012 T90_P15013 T90_P15014 T90_P15015 T90_P15016 T90_P15017 T90_P15020
# TestCase ID(多客户端单线程):  T90_P16485 T90_P16486 T90_P16487 T90_P16488 T90_P6489 T90_P16490 T90_P16491 T90_P16492
# TestCase ID(多客户端多线程):  T90_P16046 T90_P16047 T90_P16048 T90_P16049 T90_P16050 T90_P16051 T90_P16052 T90_P16053
# Description:  open-removexattr OP组合
# Author:       songyunfan
# Revision:     1.0.0
###################################################################################################################################################################

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

#定义创建的文件名前缀为主机名
#file=`hostname`
#进入拷机目录，目录不存在则创建，存在则提示已存在
# read -p "请输入目录路径：" dir
dir=$2

if [ ! -d $dir ]; then
        mkdir $dir
else
        echo "$dir exits,no need to create"
fi
#输入脚本循环次数
# read -p "请输入循环次数：" count
count=$3
back_data(){

        #dir下创建两个备用目录,目录下预埋文件
        mkdir $dir/dir1
        mkdir $dir/dir2
        for ((n=1; n<=5;n++))
        do
                touch "$dir/dir1/file${n}.txt"
                setfattr -n user.myattribute -v "file${n}'s value in dir1" $dir/dir1/file${n}.txt
                echo "this is the content of $dir/dir1/file${n}.txt" > "$dir/dir1/file${n}.txt"
                mkdir "$dir/dir1/testdir${n}"
                setfattr -n user.myattribute -v "testdir${n}'s value in dir1" $dir/dir1/testdir${n}
                echo "this is a file in testdir${n}" > $dir/dir1/testdir${n}/testfile${n}.txt
        done
        for ((m=1; m<=5;m++))
        do
                touch "$dir/dir2/file${m}.txt"
                setfattr -n user.myattribute -v "file${m}'s value in dir2" $dir/dir2/file${m}.txt
                echo "this is the content of $dir/dir2/file${m}.txt" > "$dir/dir2/file${m}.txt"
                mkdir "$dir/dir2/testdir${m}"
                setfattr -n user.myattribute -v "testdir${m}'s value in dir2" $dir/dir2/testdir${m}
                echo "this is a file in testdir${m}" > $dir/dir2/testdir${m}/testfile${m}.txt
        done
#       echo "---文件及文件扩展属性预埋结果---"
#       for ((i=1; i<=5; i++))
#       do
#               getfattr -d $dir/dir1/file${i}.txt
#               getfattr -d $dir/dir1/testdir${i}
#               getfattr -d $dir/dir2/file${i}.txt
#               getfattr -d $dir/dir2/testdir${i}
#       done
        chattr +i $dir/dir2/file3.txt && echo chattr +i $dir/dir2/file3.txt
#       echo "对加锁文件操作" && echo "11" > $dir/dir2/file3.txt
}

operation(){

        #打开目录的同时removexattr同一目录
		log_info "打开目录的同时removexattr同一目录"
        cd $dir/dir1/testdir1 && setfattr -x user.myattribute $dir/dir1/testdir1 && echo `getfattr -d $dir/dir1/testdir1` && log_debug "cd $dir/dir1/testdir1"
        #打开目录后removexattr其他目录
		log_info "打开目录后removexattr其他目录"
        cd $dir/dir2/testdir1 && setfattr -x user.myattribute $dir/dir2/testdir2 && echo `getfattr -d $dir/dir2/testdir2` && log_debug "cd $dir/dir2/testdir1"
        #打开文件后removexattr同级目录
		log_info "打开文件后removexattr同级目录"
        echo 11 > $dir/dir1/file1.txt && setfattr -x user.myattribute $dir/dir1/testdir2 && echo `getfattr -d $dir/dir1/testdir2` && log_debug "echo 11 > $dir/dir1/file1.txt"
        #打开文件后removexattr父目录
		log_info "打开文件后removexattr父目录"
        echo 11 > $dir/dir2/testdir2/testfile2.txt && setfattr -x user.myattribute $dir/dir2/testdir1 && echo `getfattr -d $dir/dir2/testdir1` && log_debug "echo 11 > $dir/dir2/testdir2/testfile2.txt"
        #打开文件后removexattr非父目录
		log_info "打开文件后removexattr非父目录"
        echo 11 > $dir/dir1/testdir3/testfile3.txt && setfattr -x user.myattribute $dir/dir1/testdir4 && echo `getfattr -d $dir/dir1/testdir4` && log_debug "echo 11 > $dir/dir1/testdir3/testfile3.txt"
        #打开目录后removexattr目录下的子目录
		log_info "打开目录后removexattr目录下的子目录"
        cd $dir/dir2 && setfattr -x user.myattribute $dir/dir2/testdir4 && echo `getfattr -d $dir/dir2/testdir4` && log_debug "cd $dir/dir2"
        #打开文件后removexattr同一文件
		log_info "打开文件后removexattr同一文件"
        echo 11 > $dir/dir1/file1.txt && setfattr -x user.myattribute $dir/dir1/file1.txt && `getfattr -d $dir/dir1/file1.txt` && log_debug "echo 11 > $dir/dir1/file1.txt"
        #打开文件后removexattr同一目录下文件
		log_info "打开文件后removexattr同一目录下文件"
        echo 11 > $dir/dir2/file1.txt && setfattr -x user.myattribute $dir/dir2/file2.txt && `getfattr -d $dir/dir2/file2.txt` && log_debug "echo 11 > $dir/dir2/file1.txt"
        #打开文件后removexattr其他目录下文件
		log_info "打开文件后removexattr其他目录下文件"
        echo 11 >> $dir/dir2/file1.txt && setfattr -x user.myattribute $dir/dir1/file2.txt && `getfattr -d $dir/dir1/file2.txt` && log_debug "echo 11 >> $dir/dir2/file1.txt"
        #打开目录后removexattr目录下文件
		log_info "打开目录后removexattr目录下文件"
        cd $dir/dir1 && setfattr -x user.myattribute $dir/dir1/file3.txt && `getfattr -d $dir/dir1/file3.txt` && log_debug "cd $dir/dir1"
        #打开目录后removexattr其他目录下文件
		log_info "打开目录后removexattr其他目录下文件"
        cd $dir/dir1 && setfattr -x user.myattribute $dir/dir2/file1.txt && `getfattr -d $dir/dir2/file1.txt` && log_debug "cd $dir/dir1"
        #打开目录后chattr给文件解锁
		log_info "打开目录后chattr给文件解锁"
        cd $dir/dir2 && chattr -i $dir/dir2/file3.txt && log_debug "cd $dir/dir2"

        #查看目录列表
        #echo "$dir/dir1目录的内容：" && ls -l $dir/dir1
        #echo "$dir/dir2目录的内容：" && ls -l $dir/dir2
        echo "---一次循环后文件/目录的扩展属性展示---"

        for ((i=1; i<=5; i++))
        do
                echo -n "$dir/dir1/file${i}.txt的扩展属性：" && getfattr -d $dir/dir1/file${i}.txt
                echo
                echo -n "$dir/dir2/file${i}.txt的扩展属性：" && getfattr -d $dir/dir2/file${i}.txt
                echo
                echo -n "$dir/dir1/testdir${i}的扩展属性：" && getfattr -d $dir/dir1/testdir${i}
                echo
                echo -n "$dir/dir2/testdir${i}的扩展属性：" && getfattr -d $dir/dir2/testdir${i}
                echo
        done

        echo "echo对解锁文件操作" && echo "11" >> $dir/dir2/file3.txt
        #清空本次循环所产生目录
        #chattr -i $dir/dir2/file3.txt
        #rm -rf $dir/*

}

teardown() {

    # 检查目录是否存在
    if [ -d "${dir}" ]; then
        log_info "开始清空本次循环所产生的目录文件"
        # 递归删除指定目录中的所有文件和子目录
		rm -rf $dir/*
        #rm -rf $dir/dir1
		#rm -rf $dir/dir2
        log_info "删除完成本次循环所产生的目录文件"
    else
        # 目录不存在时输出错误信息
        log_err "Directory does not exist: $dir"
    fi


        #清空本次循环所产生目录
		chattr -i $dir/dir2/file3.txt
        rm -rf $dir/*

}

#根据输入开始单线程/多线程测试
#如果输入不正确，则输出usage内容
if [ $# -ne 3 ];then
        usage
        exit
fi
#单线程，则直接执行operation，拷机预设的count次
if [ $1 -eq 1 ];then
        for k in `seq 1 $count`
        do
                back_data
                operation
				teardown
                echo "--- 第$k次循环 ---"
        done
#多线程
elif [ $1 -gt 1 ];then
{
        #back_data
        # read -p "请输入并发线程数（只能输入数字）：" thread
        thread=$1
        [ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
                exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
                rm -rf /tmp/fd1 #删除管道文件

        for i in `seq 1 $thread`  #实现多线程并发
        do
        {
                echo >&3 #向文件描述符为3的命名管道中写入空行
                echo a=$i
        }
        done
        #并发进行操作
        for j in `seq 1 $count`
        do
                read -u3
                {
				back_data
                operation
				teardown
                echo $j
                echo >&3
                }&
        done
        wait
        exec 3<&-
        exec 3>&-

}
else
        usage
fi
