#! /bin/bash
#单/多线程实现mkdir文件的同时removexattr

######################################################################################
# TestCase ID(单客户端单线程):  T90_P17446 T90_P17445 T90_P17447 T90_P17448 T90_P17449
# TestCase ID(单客户端多线程):  T90_P15369 T90_P15370 T90_P15371 T90_P15372 T90_P15373
# TestCase ID(多客户端单线程):  T90_P15892 T90_P15893 T90_P15894 T90_P15895 T90_P15896
# TestCase ID(多客户端多线程):  T90_P16399 T90_P16401 T90_P16402 T90_P16403 T90_P16404

# Description:  mkdir-removexattr OP组合
# Author:       liumengyang
# Revision:     1.0.0
######################################################################################
source ./log.sh

#脚本用法
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

#参数校验
validate_parms(){

	#根据输入开始单线程/多线程测试
	#如果输入不正确，则输出usage内容
	if [ $# -ne 3 ];then
		usage
		exit
	fi
	#单线程，则直接执行operation，拷机预设的count次
	if [ $1 -eq 1 ];then
		for i in `seq 1 $count`
		do
			back_data
			operation
			sleep 3
			teardown
			log_info "--- 第$i次循环 ---"
		done
	#多线程
	elif [ $1 -gt 1 ];then
	{
		#back_data
		# read -p "请输入并发线程数（只能输入数字）：" thread
		thread=$1
		log_info "并发线程数:$thread"
		[ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
			exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
			rm -rf /tmp/fd1 #删除管道文件

		for i in `seq 1 $thread`  #实现多线程并发
		do
		{
			echo >&3 #向文件描述符为3的命名管道中写入空行
			echo a=$i
		}
		done
		#并发进行操作
		for j in `seq 1 $count`
		do
			read -u3
			{
				back_data
				operation
				sleep 3
				teardown
				echo $j
				echo >&3
			}&
		done
		wait
		exec 3<&-
		exec 3>&-

	}
	else
		usage
	fi
}

back_data(){
	log_info "dir下创建备用目录,目录下预埋文件"
	for ((k=1; k<=5; k++))
	do
		mkdir $dir/dir$k
		setfattr -n user.myattribute -v "dir$k" $dir/dir$k && echo setxattr user $dir/dir$k
		mkdir $dir/dir$k/dir_test && echo "hello" > $dir/dir$k/dir_test/file.txt
		setfattr -n user.myattribute -v "dir_test's value in dir$k" $dir/dir$k/dir_test && echo setxattr user $dir/dir$k/dir_test
		touch $dir/dir$k/test.txt
		setfattr -n user.myattribute -v "test.txt's value in dir$k" $dir/dir$k/test.txt && echo setxattr user $dir/dir$k/test.txt
	done
}
operation(){
       
         
	log_info "创建目录的同时removexattr同级文件"
        mkdir $dir/dir1/testdir1 && echo "hello" > $dir/dir1/testdir1/file1.txt && echo "mkdir $dir/dir1/testdir1"
	setfattr -x user.myattribute $dir/dir1/test.txt
        log_info "创建目录后removexattr其他目录下文件"
        mkdir $dir/dir1/testdir1-1 && echo "hello" > $dir/dir1/testdir1-1/file1.txt && echo "mkdir $dir/dir1/testdir1-1" 
	setfattr -x user.myattribute $dir/dir2/test.txt
	log_info "创建目录的同时removexattr父目录"
        mkdir $dir/dir3/dir_test/testdir1 && echo "hello" > $dir/dir3/dir_test/testdir1/file1.txt && echo "mkdir $dir/dir3/dir_test/testdir1"
	setfattr -x user.myattribute $dir/dir3/dir_test
        log_info "创建目录后removexattr同级目录"
        mkdir $dir/dir4/testdir1 && echo "hello" > $dir/dir4/testdir1/file1.txt && echo "mkdir $dir/dir4/testdir1"
	setfattr -x user.myattribute $dir/dir4/dir_test
        log_info "创建目录后removexattr其他目录"
        mkdir $dir/dir2/testdir1 && echo "hello" > $dir/dir2/testdir1/file1.txt && echo "mkdir $dir/dir2/testdir1" 
	setfattr -x user.myattribute $dir/dir5/dir_test
	log_info "创建目录后removexattr同一目录"
	mkdir $dir/dir5/testdir1 && echo "hello" > $dir/dir5/testdir1/file1.txt && echo "mkdir $dir/dir5/testdir1" 
	setfattr -x user.myattribute $dir/dir5/testdir1
        
		
        log_info "查看目录列表"
        
	for ((k=1; k<=5; k++))
	do
		echo "$dir/dir$k目录下内容：" && ls -l $dir/dir$k
	done
	log_info "查看扩展属性"
	for ((k=1; k<=5; k++))
	do
		getfattr -d $dir/dir$k
		getfattr -d $dir/dir$k/dir_test
		#getfattr -d $dir/dir$k/dir_test/file.txt
		getfattr -d $dir/dir$k/test.txt
	done
	getfattr -d $dir/dir5/testdir1
}
teardown() {
    # 检查目录是否存在
    if [ -d "${dir}" ]; then
        log_info "开始清空本次循环所产生的目录文件"
        # 递归删除指定目录中的所有文件和子目录
        rm -rf "${dir}"/*
        log_info "删除完成本次循环所产生的目录文件"
    else
        # 目录不存在时输出错误信息
        log_err "Directory does not exist: ${dir}"
    fi
}


main(){

	#定义创建的文件名前缀为主机名
	file=`hostname`
	#进入拷机目录，目录不存在则创建，存在则提示已存在
	# read -p "请输入目录路径：" dir
	dir=$2
	log_info "拷机目录:$dir"
	if [ ! -d $dir ]; then
			mkdir $dir
	else
			log_debug "$dir exits,no need to create"
	fi
	#输入脚本循环次数
	# read -p "请输入循环次数：" count
	count=$3
	log_info "脚本循环次数$count"
	validate_parms "$@"
}
main "$@"
