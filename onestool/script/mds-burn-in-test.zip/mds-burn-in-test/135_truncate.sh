#!/bin/bash


usage() {
	echo "
usage: ${0} 0|1
       脚本接受一个参数0或者1
       0表示单线程
       1表示多线程"
      
}

hostname=`hostname`
read -p "请输入要跑脚本的目录全路径（eg:/mnt/note3/dir）：" dir

if [ ! -d $dir ];then
	mkdir $dir
else
	echo "$dir exits,no need to create"
fi

read -p "请输入脚本要循环的次数（只能输入数字）：" count

operation(){
	
	mkdir $dir/dir1
        mkdir $dir/dir2
	dd if=/dev/zero of=$dir/dir1/64k bs=64k count=1
	dd if=/dev/zero of=$dir/dir2/1M bs=1M count=1
        truncate -s 1G $dir/dir1/64k
        truncate -s 1024 $dir/dir2/1M
        truncate -s 1M $dir/dir1/64k
        truncate -s 1G $dir/dir2/1M
	mv $dir/dir1/64k $dir/dir2/64k-${hostname}_h$i && echo mv $dir/dir1/64k
	rm -rf $dir/dir1/64k && echo rm -rf $dir/dir1/64k
        mv $dir/dir2/1M $dir/dir2/1M-${hostname}_h$i && echo mv $dir/dir2/1M
	mv $dir/dir1 $dir/dir2/dir1_s
	rm -rf $dir/dir1 && echo rm -rf $dir/dir1
	mv $dir/dir2/dir1_s $dir/dir1
	rm -rf $dir/dir1 
        rm -rf $dir/dir2 

}

if [ $# -ne 1 ]; then
        usage
        exit
fi

if [ $1 -eq 0 ]; then
{	
	for i in `seq 1 $count`
	do
        {
	operation
        echo $i
        }
	done
}

elif [ $1 -eq 1 ]; then
{
	read -p "请输入要并发的线程数（只能输入数字）：" thread
	[ -e /tmp/fd1 ] || mkfifo /tmp/fd1
        exec 3<>/tmp/fd1
        rm -rf /tmp/fd1
	
	for i in `seq 1 $thread`
	do
        {
	echo >&3
        echo a=$i
	}
	done

        for j in `seq 1 $count`
        do
        read -u3
        {
        operation
        echo $j
        echo >&3
        }&
	done
	wait
	exec 3<&-
	exec 3>&-

}
else
	usage
fi
