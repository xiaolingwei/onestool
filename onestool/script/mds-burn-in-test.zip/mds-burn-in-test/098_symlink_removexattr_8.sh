#!/bin/bash
#################################################################
# TestCase ID:  
# Description:  symlink-removexattr OP组合
# Author:       zhuxiaohong
# Revision:     1.0.0
#################################################################
source ./log.sh
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

#定义创建的文件名前缀为主机名
hostname=`hostname`
#进入拷机目录，目录不存在则创建，存在则提示已存在
# read -p "请输入目录路径：" dir
dir=$2

if [ ! -d $dir ]; then
        mkdir $dir
else
        log_info "$dir exits,no need to create"
fi
#输入脚本循环次数
# read -p "请输入循环次数：" count
count=$3

operation(){

		# 创建文件hello的软链接并移除文件hello的扩展属性
		log_info "创建文件hello的软链接并移除文件hello的扩展属性"
		mkdir $dir/dir1 && log_info "mkdir $dir/dir1"
		mkdir $dir/dir2 && log_info "mkdir $dir/dir2"
		echo hello > $dir/dir1/hello && log_info "echo hello > $dir/dir1/hello"
		echo hi > $dir/dir2/hi && log_info "echo hi > $dir/dir2/hi"
		setfattr -n user.myattribute -v "value" $dir/dir1/hello && log_debug "setxattr user $dir/dir1/hello"
		setfattr -n security.selinux -v "label" $dir/dir1/hello && log_debug "setxattr security $dir/dir1/hello"
		ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && log_debug "ln -s $dir/dir1/hello"
		setfattr -x user.myattribute $dir/dir1/hello && log_debug "removexattr user $dir/dir1/hello" 
		setfattr -x security.selinux $dir/dir1/hello && log_debug "removexattr security $dir/dir1/hello"
		getfattr -d $dir/dir1/hello && log_debug "getxattr $dir/dir1/hello"
		stat $dir/dir1/hello && log_debug "stat $dir/dir1/hello"
		rm -rf $dir/dir2 && log_info "rm -rf $dir/dir2"

		# 创建目录dir1的软链接并移除目录dir1的扩展属性
		log_info "创建目录dir1的软链接并移除目录dir1的扩展属性"
		mkdir $dir/dir1 && log_info "mkdir $dir/dir1"
		mkdir $dir/dir2 && log_info "mkdir $dir/dir2"
		echo hello > $dir/dir1/hello && log_info "echo hello > $dir/dir1/hello"
		echo hi > $dir/dir2/hi && log_info "echo hi > $dir/dir2/hi"
		setfattr -n user.myattribute -v "value" $dir/dir1 && log_debug "setxattr user $dir/dir1"
		setfattr -n security.selinux -v "label" $dir/dir1 && log_debug "setxattr security $dir/dir1" 
		ln -s $dir/dir1 $dir/dir1_$hostname_$i && log_debug "ln -s $dir/dir1"
		setfattr -x user.myattribute $dir/dir1 && log_debug "removexattr user $dir/dir1"
		setfattr -x security.selinux $dir/dir1 && log_debug "removexattr security $dir/dir1"
		getfattr -d $dir/dir1 && log_debug "getxattr $dir/dir1"
		stat $dir/dir1 && log_info "stat $dir/dir1"
		rm -rf $dir/dir2 && log_info "rm -rf $dir/dir2"
  
		# 创建父目录的软链接，并移除文件hello的扩展属性
		log_info "创建父目录的软链接，并移除文件hello的扩展属性"
		mkdir $dir/dir1 && log_info "mkdir $dir/dir1"
		mkdir $dir/dir2 && log_info "mkdir $dir/dir2"
		echo hello > $dir/dir1/hello && log_info "echo hello > $dir/dir1/hello"
		echo hi > $dir/dir2/hi  && log_info "echo hi > $dir/dir2/hi"
		setfattr -n user.myattribute -v "value" $dir/dir1/hello && log_debug "setxattr user $dir/dir1/hello"
		ln -s $dir/dir1 $dir/dir1_$hostname_$i && log_debug "ln -s $dir/dir1"	
		setfattr -x user $dir/dir1/hello && log_debug "removexattr $dir/dir1/hello"
		getfattr -d $dir/dir1/hello && log_debug "getxattr $dir/dir1/hello"
		stat $dir/dir1 && log_info "stat $dir/dir1"
		stat $dir/dir1/hello && log_info "stat $dir/dir1/hello"
		rm -rf $dir/* && log_info "rm -rf $dir/*"
 
		# 创建文件hello的软链接，并移除其父目录扩展属性
		log_info "创建文件hello的软链接，并移除其父目录扩展属性"
		mkdir $dir/dir1 && log_info "mkdir $dir/dir1"
		mkdir $dir/dir2 && log_info "mkdir $dir/dir2"
		echo hello > $dir/dir1/hello && log_info "echo hello > $dir/dir1/hello"
		echo hi > $dir/dir2/hi && log_info "echo hi > $dir/dir2/hi"
		setfattr -n user.myattribute -v "value" $dir/dir1 && log_debug "setxattr user $dir/dir1"
		setfattr -n security.selinux -v "label" $dir/dir1 && log_debug "setxattr security $dir/dir1"
		ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && log_debug "ln -s $dir/dir1/hello"
		
		setfattr -x user.myattribute $dir/dir1 && log_debug "removexattr user $dir/dir1"
		setfattr -x security.selinux $dir/dir1 && log_debug "removexattr security $dir/dir1"
		getfattr -d $dir/dir1 && log_debug "getxattr $dir/dir1"
		stat $dir/dir1 && log_info "stat $dir/dir1"
		stat $dir/dir1/hello && log_info "stat $dir/dir1/hello"
		rm -rf $dir/* && log_info "rm -rf $dir/*"
 
		# 创建文件hi的软链接并移除文件hello的扩展属性
		log_info "创建文件hi的软链接并移除文件hello的扩展属性"
		mkdir $dir/dir1 && log_info "mkdir $dir/dir1"
		mkdir $dir/dir2 && log_info "mkdir $dir/dir2"
		echo hello > $dir/dir1/hello && log_info "echo hello > $dir/dir1/hello"
		echo hi > $dir/dir2/hi && log_info "echo hi > $dir/dir2/hi"
		setfattr -n security.selinux -v "label" $dir/dir1/hello && log_debug "setxattr security $dir/dir1/hello"
		ln -s $dir/dir2/hio $dir/dir2/hi_$hostname_$i && log_debug "ln -s $dir/dir2/hi"
		setfattr -x security.selinux $dir/dir1/hello && log_debug "removexattr $dir/dir1/hello" 
		getfattr -d $dir/dir1/hello && log_debug "getxattr $dir/dir1/hello"
		stat $dir/dir2/hi && log_info "stat $dir/dir2/hi"
		stat $dir/dir1/hello && log_info "stat $dir/dir1/hello"
		rm -rf $dir/* && log_info "rm -rf $dir/*"
  
		# 创建目录dir1的软链接并移除目录dir2的扩展属性
		log_info "创建目录dir1的软链接并移除目录dir2的扩展属性"
		mkdir $dir/dir1 && log_info "mkdir $dir/dir1"
		mkdir $dir/dir2 && log_info "mkdir $dir/dir2"
		echo hello > $dir/dir1/hello && log_info "echo hello > $dir/dir1/hello"
		echo hi > $dir/dir2/hi && log_info "echo hi > $dir/dir2/hi"
		setfattr -n security.selinux -v "label" $dir/dir2 && log_debug "setxattr security $dir/dir2"
		ln -s $dir/dir1 $dir/dir1_$hostname_$i && log_debug "ln -s $dir/dir1"
		setfattr -x security.selinux $dir/dir2 && log_debug "removexattr $dir/dir2"
		getfattr -d $dir/dir2 && log_debug "getxattr $dir/dir2"
		stat $dir/dir1 && log_info "stat $dir/dir1"
		stat $dir/dir2 && log_info "stat $dir/dir2 "
		rm -rf $dir/* && log_info "rm -rf $dir/*"
 
		# 创建目录dir2的软链接，并删除文件hello的扩展属性
		log_info "创建目录dir2的软链接，并删除文件hello的扩展属性"
		mkdir $dir/dir1 && log_info "mkdir $dir/dir1"
		mkdir $dir/dir2	&& log_info "mkdir $dir/dir2"
		echo hello > $dir/dir1/hello && log_info "echo hello > $dir/dir1/hello"
		echo hi > $dir/dir2/hi && log_info "echo hi > $dir/dir2/hi"
		setfattr -n user.myattribute -v "value" $dir/dir1/hello && log_debug "setxattr user $dir/dir1/hello"
		ln -s $dir/dir2 $dir/dir2_$hostname_$i && log_debug "ln -s $dir/dir2"
		setfattr -x user.myattribute $dir/dir1/hello && echo removexattr $dir/dir1/hello 
		getfattr -d $dir/dir1/hello && log_debug "getxattr $dir/dir1/hello"
		stat $dir/dir2 && log_info "stat $dir/dir2"
		stat $dir/dir1/hello && log_info "stat $dir/dir1/hello"
		rm -rf $dir/* && log_info "rm -rf $dir/* "
 
		# 创建文件hello的软链接，并删除目录dir2扩展属性
		log_info "创建文件hello的软链接，并删除目录dir2扩展属性"
		mkdir $dir/dir1 && log_info "mkdir $dir/dir1"
		mkdir $dir/dir2 && log_info "mkdir $dir/dir2"
		echo hello > $dir/dir1/hello && log_info "echo hello > $dir/dir1/hello"
		echo hi > $dir/dir2/hi && log_info "echo hi > $dir/dir2/hi"
		setfattr -n user.myattribute -v "value" $dir/dir2 && log_debug "setxattr user $dir/dir2"
		setfattr -n security.selinux -v "label" $dir/dir2 && log_debug "setxattr security $dir/dir2"
		ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && log_debug "ln -s $dir/dir1/hello"
		setfattr -x user.myattribute $dir/dir2 && log_debug "removexattr user $dir/dir2"
		setfattr -x security.selinux $dir/dir2 && log_debug "removexattr security $dir/dir2"
		getfattr -d $dir/dir2 && log_debug "getxattr $dir/dir2"
		stat $dir/dir2 && log_info "stat $dir/dir2"
		stat $dir/dir1/hello && log_info "stat $dir/dir1/hello"
		rm -rf $dir/* && log_info "rm -rf $dir/*"
 
  
}

#根据输入开始单线程/多线程测试
#如果输入不正确，则输出usage内容
if [ $# -ne 3 ];then
        usage
        exit
fi
#单线程，则直接执行operation，拷机预设的count次
if [ $1 -eq 1 ];then
        for i in `seq 1 $count`
        do
                log_info "--- 第$i次循环 ---"
                operation
        done
#多线程
elif [ $1 -gt 1 ];then
{
        
        # read -p "请输入并发线程数（只能输入数字）：" thread
        thread=$1
        [ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
                exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
                rm -rf /tmp/fd1 #删除管道文件

        for i in `seq 1 $thread`  #实现多线程并发
        do
        {
                echo >&3 #向文件描述符为3的命名管道中写入空行
                echo a=$i
        }
        done
        #并发进行open-rename操作
        for j in `seq 1 $count`
        do
				log_info "--- $thread多线程第$j次循环 ---"
                read -u3
                {
                operation
                echo $j
                echo >&3
                }&
        done
        wait
        exec 3<&-
        exec 3>&-

}
else
        usage
fi