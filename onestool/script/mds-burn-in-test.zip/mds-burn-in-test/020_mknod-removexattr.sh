#! /bin/bash
#单/多线程实现mknod文件的同时removexattr
#################################################################
# TestCase ID:  
# Description:  makenod-removexattr OP组合
# Author:       zhuxiaohong
# Revision:     1.0.0
#################################################################
source ./log.sh
#脚本用法
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}
#定义创建的文件名前缀为主机名
file=`hostname`
#进入拷机目录，目录不存在则创建，存在则提示已存在
# read -p "请输入目录路径：" dir
dir=$2

if [ ! -d $dir ]; then
        mkdir $dir
else
        log_info "$dir exits,no need to create"
fi
#输入脚本循环次数
# read -p "请输入循环次数：" count
count=$3

operation(){
		#dir下创建两个备用目录,目录下预埋文件
		log_info "预埋数据：创建两个备用目录,目录下预埋文件"
        mkdir $dir/dir1 && log_info "mkdir $dir/dir1"
        mkdir $dir/dir2 && log_info "mkdir $dir/dir2"
        for ((n=1; n<=5;n++))
        do
                touch $dir/dir1/file${n}.txt && log_info "touch $dir/dir1/file${n}.txt"
                echo "this is the content of $dir/dir1/file${n}.txt" > $dir/dir1/file${n}.txt && log_info "this is the content of $dir/dir1/file${n}.txt > $dir/dir1/file${n}.txt"
                mkdir $dir/dir1/testdir${n} && log_info "mkdir $dir/dir1/testdir${n}"
				setfattr -n user.myattribute -v "testdir${n}'s value in dir1" $dir/dir1/testdir${n} && log_info "setfattr -n user.myattribute -v testdir${n} value in dir1 $dir/dir1/testdir${n}"
                echo "this is a file in testdir${n}" > $dir/dir1/testdir${n}/testfile${n}.txt && log_info "this is a file in testdir${n} > $dir/dir1/testdir${n}/testfile${n}.txt"
				setfattr -n user.myattribute -v "testfile${n}.txt's value in dir1/testdir${n}" $dir/dir1/testdir${n}/testfile${n}.txt && log_info "setfattr -n user.myattribute -v testfile${n}.txt value in dir1/testdir${n} $dir/dir1/testdir${n}/testfile${n}.txt"
        done
        for ((m=1; m<=5;m++))
        do
                touch $dir/dir2/file${m}.txt && log_info "touch $dir/dir2/file${m}.txt"
                echo "this is the content of $dir/dir2/file${m}.txt" > $dir/dir2/file${m}.txt && log_info "this is the content of $dir/dir2/file${m}.txt > $dir/dir2/file${m}.txt "
                mkdir $dir/dir2/testdir${m} && log_info "mkdir $dir/dir2/testdir${m}"
				setfattr -n user.myattribute -v "testdir${m}'s value in dir2" $dir/dir2/testdir${m} && log_info "setfattr -n user.myattribute -v testdir${m} value in dir2 $dir/dir2/testdir${m}"
                echo "this is a file in testdir${m}" > $dir/dir2/testdir${m}/testfile${m}.txt && log_info "this is a file in testdir${m} > $dir/dir2/testdir${m}/testfile${m}.txt"
				setfattr -n user.myattribute -v "testfile${m}.txt's value in dir2/testdir${m}" $dir/dir2/testdir${m}/testfile${m}.txt && log_info "setfattr -n user.myattribute -v testfile${m}.txt value in dir2/testdir${m} $dir/dir2/testdir${m}/testfile${m}.txt"
        done
		#设置扩展属性
		#setfattr -n user.myattribute -v "testdir1's value in dir1" $dir/dir1/testdir1
		# -n user.myattribute -v "testdir1's value in dir2" $dir/dir2/testdir1
		#setfattr -n user.myattribute -v "testdir2's value in dir1" $dir/dir1/testdir2
		#setfattr -n user.myattribute -v "${file}-$i.txt's value in dir1/testdir2" $dir/dir1/testdir2/${file}-$i.txt
		#setfattr -n user.myattribute -v "testfile2.txt's value in dir2/testdir2" $dir/dir2/testdir2/testfile2.txt
		#setfattr -n user.myattribute -v "testfile4.txt's value in dir1/testdir4" $dir/dir1/testdir4/testfile4.txt
		#检查设置结果
		#echo `getfattr -d $dir/dir1/testdir1`
        #echo `getfattr -d $dir/dir2/testdir1`
        #echo `getfattr -d $dir/dir1/testdir2`
        #echo `getfattr -d $dir/dir1/testdir2/${file}-$i.txt`
        #echo `getfattr -d $dir/dir2/testdir2/testfile2.txt`
        #echo `getfattr -d $dir/dir1/testdir4/testfile4.txt`
		
		for ((i=1; i<=5; i++))
		do
			getfattr -d $dir/dir1/testdir${i} && log_info "getfattr -d $dir/dir1/testdir${i}"
			getfattr -d $dir/dir1/testdir${i}/testfile${i}.txt && log_info "getfattr -d $dir/dir1/testdir${i}/testfile${i}.txt"
			getfattr -d $dir/dir2/testdir${i} && log_info "getfattr -d $dir/dir2/testdir${i}"
			getfattr -d $dir/dir2/testdir${i}/testfile${i}.txt && log_info "getfattr -d $dir/dir2/testdir${i}/testfile${i}.txt"
			
		done
		
		log_info "开始测试"
        #创建文件后removexattr同级目录
		log_info "创建文件后removexattr同级目录"
        mknod $dir/dir1/${file}-$i.txt c $i $i && log_debug "mknod $dir/dir1/${file}-$i.txt c $i $i"
		setfattr -x user.myattribute $dir/dir1/testdir1 && log_debug "setfattr -x user.myattribute $dir/dir1/testdir1"
        #创建文件后removexattr父目录
		log_info "创建文件后removexattr父目录"
        mknod $dir/dir2/testdir1/${file}-$i.txt c $((i+10)) $((i+10)) && log_debug "mknod $dir/dir2/testdir1/${file}-$i.txt c $((i+10)) $((i+10))"
		setfattr -x user.myattribute $dir/dir2/testdir1 && log_debug "setfattr -x user.myattribute $dir/dir2/testdir1"
        #创建文件后removexattr非父目录
		log_info "创建文件后removexattr非父目录"
        mknod $dir/dir1/testdir1/${file}-$i.txt c $((i+20)) $((i+20)) && log_debug "mknod $dir/dir1/testdir1/${file}-$i.txt c $((i+20)) $((i+20))"
		setfattr -x user.myattribute $dir/dir1/testdir2 && log_debug "setfattr -x user.myattribute $dir/dir1/testdir2"
        #创建文件后removexattr同一文件
		log_info "创建文件后removexattr同一文件"
        mknod $dir/dir1/testdir2/${file}-$i.txt c $((i+30)) $((i+30)) && log_debug "mknod $dir/dir1/testdir2/${file}-$i.txt c $((i+30)) $((i+30))"
		setfattr -x user.myattribute $dir/dir1/testdir2/${file}-$i.txt && log_debug "setfattr -x user.myattribute $dir/dir1/testdir2/${file}-$i.txt"
        #创建文件后removexattr同一目录下文件
		log_info "创建文件后removexattr同一目录下文件"
        mknod $dir/dir2/testdir2/${file}-$i.txt c $((i+40)) $((i+40)) && log_debug "mknod $dir/dir2/testdir2/${file}-$i.txt c $((i+40)) $((i+40))"
		setfattr -x user.myattribute $dir/dir2/testdir2/testfile2.txt && log_debug "setfattr -x user.myattribute $dir/dir2/testdir2/testfile2.txt"
        #创建文件后removexattr其他目录下文件
		log_info "创建文件后removexattr其他目录下文件"
        mknod $dir/dir1/testdir3/${file}-$i.txt c $((i+50)) $((i+50)) && log_debug "mknod $dir/dir1/testdir3/${file}-$i.txt c $((i+50)) $((i+50))"
		setfattr -x user.myattribute $dir/dir1/testdir4/testfile4.txt && log_debug "setfattr -x user.myattribute $dir/dir1/testdir4/testfile4.txt"

        #查看目录列表
		log_info "$dir目录的内容：" && ls -l $dir
        log_info "$dir/dir1目录的内容：" && ls -l $dir/dir1
        log_info "$dir/dir2目录的内容：" && ls -l $dir/dir2
		#查看扩展属性设置结果
		#echo -n "$dir/dir1/testdir1扩展属性:" && echo `getfattr -d $dir/dir1/testdir1`
        #echo -n "$dir/dir2/testdir1扩展属性:" && echo `getfattr -d $dir/dir2/testdir1`
        #echo -n "$dir/dir1/testdir2扩展属性:" && echo `getfattr -d $dir/dir1/testdir2`
        #echo -n "$dir/dir1/testdir2/${file}-$i.txt扩展属性:" && echo `getfattr -d $dir/dir1/testdir2/${file}-$i.txt`
        #echo -n "$dir/dir2/testdir2扩展属性:" && echo `getfattr -d $dir/dir2/testdir2/testfile2.txt`
        #echo -n "$dir/dir4/testdir4扩展属性:" && echo `getfattr -d $dir/dir1/testdir4/testfile4.txt`
		for ((k=1; k<=5; k++))
		do
			log_info "$dir/dir1/testdir${k}扩展属性:" && echo `getfattr -d $dir/dir1/testdir${k}`
			log_info"$dir/dir1/testdir${k}/testfile${k}.txt扩展属性:" && echo `getfattr -d $dir/dir1/testdir${k}/testfile${k}.txt`
			log_info "$dir/dir2/testdir${k}扩展属性:" && echo `getfattr -d $dir/dir2/testdir${k}`
			log_info "$dir/dir2/testdir${k}/testfile${k}.txt扩展属性:" && echo `getfattr -d $dir/dir2/testdir${k}/testfile${k}.txt`
			
		done

        #清空本次循环所产生目录
		log_info "清空本次循环所产生目录"
        rm -rf $dir/* 
		
}

#根据输入开始单线程/多线程测试
#如果输入不正确，则输出usage内容
if [ $# -ne 3 ];then
        usage
        exit
fi
#单线程，则直接执行operation，拷机预设的count次
if [ $1 -eq 1 ];then
       for i in `seq 1 $count`
       do
               log_info "--- 第$i次循环 ---"
			   operation
       done
#多线程
elif [ $1 -gt 1 ];then
{
        # read -p "请输入并发线程数（只能输入数字）：" thread
        thread=$1
        [ -e /tmp/fd1 ] || mkfifo /tmp/fd1
                exec 3<>/tmp/fd1
                rm -rf /tmp/fd1

        for i in `seq 1 $thread`
        do
        {
                echo >&3
                echo a=$i
        }
        done

        for j in `seq 1 $count`
        do
				log_info "--- $thread多线程第$j次循环 ---"
                read -u3
                {
                operation
                echo $j
                echo >&3
                }&
        done
        wait
        exec 3<&-
        exec 3>&-

}
else
        usage
fi
