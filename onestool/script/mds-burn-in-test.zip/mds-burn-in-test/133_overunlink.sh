#!/bin/bash

# 创建2000个文件
mkdir -p /mnt/fpns01/test01/b/c  # 确保目录存在
cd /mnt/fpns01/test01/b/c
for ((i=1; i<=2000; i++)); do
    touch file$i.txt
done

# 复制文件到另一个目录
cp /mnt/fpn01/test01/b/c/* /mnt/fpns01/test01/b/d

# 并发移动文件
cd /mnt/fpns01/test01/b/c
ls | xargs -I{} -P 10 mv -f {} /mnt/fpns01/test01/b/d
