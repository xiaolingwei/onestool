This version of libvdbench.dylib supports x86. 
I need a volunteer to do a small C compile and link for PPC.
Email me at Henk.Vandenbergh@oracle.com
