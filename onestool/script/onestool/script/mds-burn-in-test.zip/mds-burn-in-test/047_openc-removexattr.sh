#!/bin/bash
#################################################################
# TestCase ID:  mknod-mkdir OP组合
# Description:  单/多线程实现mknod设备文件的同时创建目录
# Author:    y33111
# Revision:    1.0.0
#################################################################
source ./log.sh

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
    脚本接受三个参数：
    <thread>: 表示线程数，1表示单线程
    <dir>: 挂载目录
    <count>: 脚本执行轮数"
}


thread=$1
log_info "并发线程数:$thread"

dir=$2
log_info "拷机目录:$dir"

count=$3
log_info "脚本循环次数$count"

#定义创建的文件名前缀为主机名
file=`hostname`
#进入拷机目录，目录不存在则创建，存在则提示已存在


if [ ! -d $dir ]; then
        mkdir $dir
else
        echo "$dir exits,no need to create"
fi

back_data(){

        log_info "dir下创建两个备用目录,目录下预埋文件"
        mkdir $dir/dir1
        mkdir $dir/dir2
        for ((n=1; n<=5;n++))
        do
                touch "$dir/dir1/file${n}.txt"
                echo "this is the content of $dir/dir1/file${n}.txt" > "$dir/dir1/file${n}.txt"
                mkdir "$dir/dir1/testdir${n}"
                echo "this is a file in testdir${n}" > $dir/dir1/testdir${n}/testfile${n}.txt
        done
        for ((m=1; m<=5;m++))
        do
                touch "$dir/dir2/file${m}.txt"
                echo "this is the content of $dir/dir2/file${m}.txt" > "$dir/dir2/file${m}.txt"
                mkdir "$dir/dir2/testdir${m}"
                echo "this is a file in testdir${m}" > $dir/dir2/testdir${m}/testfile${m}.txt
        done
		log_info "设置扩展属性"
		setfattr -n user.myattribute -v "testdir1's value in dir1" $dir/dir1/testdir1
		setfattr -n user.myattribute -v "testdir1's value in dir2" $dir/dir2/testdir1
		setfattr -n user.myattribute -v "testdir2's value in dir1" $dir/dir1/testdir2
		
		setfattr -n user.myattribute -v "testfile2.txt's value in dir2/testdir2" $dir/dir2/testdir2/testfile2.txt
		setfattr -n user.myattribute -v "testfile4.txt's value in dir1/testdir4" $dir/dir1/testdir4/testfile4.txt
		log_info "检查设置结果"
		echo `getfattr -d $dir/dir1/testdir1`
        echo `getfattr -d $dir/dir2/testdir1`
        echo `getfattr -d $dir/dir1/testdir2`
        
        echo `getfattr -d $dir/dir2/testdir2/testfile2.txt`
        echo `getfattr -d $dir/dir1/testdir4/testfile4.txt`
}
operation(){
       
        log_info "创建文件后removexattr同级目录"
        touch $dir/dir1/${file}-$i.txt && setfattr -x user.myattribute $dir/dir1/testdir1
        log_info "创建文件后removexattr父目录"
        touch $dir/dir2/testdir1/${file}-$i.txt && setfattr -x user.myattribute $dir/dir2/testdir1
        log_info "创建文件后removexattr非父目录"
        touch $dir/dir1/testdir1/${file}-$i.txt && setfattr -x user.myattribute $dir/dir1/testdir2
        log_info "创建文件后removexattr同一文件"
        touch $dir/dir1/testdir2/${file}-$i.txt && setfattr -x user.myattribute $dir/dir1/testdir2/${file}-$i.txt
        log_info "创建文件后removexattr同一目录下文件"
        touch $dir/dir2/testdir2/${file}-$i.txt && setfattr -x user.myattribute $dir/dir2/testdir2/testfile2.txt
        log_info "创建文件后removexattr其他目录下文件"
        touch $dir/dir1/testdir3/${file}-$i.txt && setfattr -x user.myattribute $dir/dir1/testdir4/testfile4.txt

        log_info "查看目录列表"
	echo "$dir目录的内容：" && ls -l $dir
        echo "$dir/dir1目录的内容：" && ls -l $dir/dir1
        echo "$dir/dir2目录的内容：" && ls -l $dir/dir2
	log_info "查看扩展属性设置结果"
	echo -n "$dir/dir1/testdir1扩展属性:" && echo `getfattr -d $dir/dir1/testdir1`
        echo -n "$dir/dir2/testdir1扩展属性:" && echo `getfattr -d $dir/dir2/testdir1`
        echo -n "$dir/dir1/testdir2扩展属性:" && echo `getfattr -d $dir/dir1/testdir2`
        echo -n "$dir/dir1/testdir2/${file}-$i.txt扩展属性:" && echo `getfattr -d $dir/dir1/testdir2/${file}-$i.txt`
        echo -n "$dir/dir2/testdir2扩展属性:" && echo `getfattr -d $dir/dir2/testdir2/testfile2.txt`
        echo -n "$dir/dir4/testdir4扩展属性:" && echo `getfattr -d $dir/dir1/testdir4/testfile4.txt`


        log_info "清空本次循环所产生目录"
        rm -rf $dir/* 
		

}
#根据输入开始单线程/多线程测试
#如果输入不正确，则输出usage内容
if [ $# -ne 3 ];then
        usage
        exit
fi
#单线程，则直接执行operation，拷机预设的count次
if [ $1 -eq 1 ];then
        for i in `seq 1 $count`
        do
                back_data
                operation
                echo "--- 第$i次循环 ---"
        done
#多线程
elif [ $1 -gt 1 ];then
{
        
        [ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
                exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
                rm -rf /tmp/fd1 #删除管道文件

        for i in `seq 1 $thread`  #实现多线程并发
        do
        {
                echo >&3 #向文件描述符为3的命名管道中写入空行
                echo a=$i
        }
        done
        #并发进行操作
        for j in `seq 1 $count`
        do
                read -u3
                {
                back_data
                operation
                echo $j
                echo >&3
                }&
        done
        wait
        exec 3<&-
        exec 3>&-

}
else
        usage
fi
