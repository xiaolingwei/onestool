#! /bin/bash
#单/多线程实现mkdir文件的同时setxattr
#################################################################
# TestCase ID:  mkdir-setxattr OP组合
# Description:  单/多线程实现mkdir文件的同时setxattr
# Author:    hys46897
# Revision:    1.0.0

#################################################################
source ./log.sh
#脚本用法
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}
#参数校验
validate_parms(){

	#根据输入开始单线程/多线程测试
	#如果输入不正确，则输出usage内容
	if [ $# -ne 3 ];then
			usage
			exit
	fi
	#单线程，则直接执行operation，拷机预设的count次
	if [ $1 -eq 1 ];then
			for i in `seq 1 $count`
			do
					back_data
					operation
					echo "--- 第$i次循环 ---"
			done
	#多线程
	elif [ $1 -gt 1 ];then
	{
			back_data
			# read -p "请输入并发线程数（只能输入数字）：" thread
			thread=$1
			[ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
					exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
					rm -rf /tmp/fd1 #删除管道文件

			for i in `seq 1 $thread`  #实现多线程并发
			do
			{
					echo >&3 #向文件描述符为3的命名管道中写入空行
					echo a=$i
			}
			done
			#并发进行操作
			for j in `seq 1 $count`
			do
					read -u3
					{
					operation
					echo $j
					echo >&3
					}&
			done
			wait
			exec 3<&-
			exec 3>&-

	}
	else
			usage
	fi
}

back_data(){
#			#dir下创建备用目录,目录下预埋文件
#			for ((k=1; k<=5; k++))
#			do
#				mkdir $dir/dir$k
#				mkdir $dir/dir$k/dir_test && echo "hello" > $dir/dir$k/dir_test/file.txt
#				touch $dir/dir$k/test.txt
#			done

    for ((k=1; k<=5; k++))
    do
        current_dir="$dir/dir$k"
        mkdir -p "$current_dir/dir_test" && echo "hello" > "$current_dir/dir_test/file.txt"
        touch "$current_dir/test.txt"
    done
}
operation(){
       
         
		#创建目录的同时setxattr同级文件
		log_info "创建$dir/dir1/testdir1"
    mkdir $dir/dir1/testdir1
    log_info "创建$dir/dir1/testdir1/file1.txt，并写入hello"
    echo "hello" > $dir/dir1/testdir1/file1.txt && echo "mkdir $dir/dir1/testdir1"
    log_info "setfattr test.txt's value in dir1"
		setfattr -n user.myattribute -v "test.txt's value in dir1" $dir/dir1/test.txt && echo setxattr user $dir/dir1/test.txt
        #创建目录后setxattr其他目录下文件
    log_info "创建$dir/dir1/testdir1-1"
    mkdir $dir/dir1/testdir1-1
    log_info "创建$dir/dir1/testdir1-1/file1.txt，并写入hello"
    echo "hello" > $dir/dir1/testdir1-1/file1.txt && echo "mkdir $dir/dir1/testdir1-1"
    log_info "setfattr test.txt's value in dir2"
		setfattr -n user.myattribute -v "test.txt's value in dir2" $dir/dir2/test.txt && echo setxattr user $dir/dir2/test.txt
		#创建目录的同时setxattr父目录
		log_info "创建$dir/dir3/dir_test/testdir1"
    mkdir $dir/dir3/dir_test/testdir1
    log_info "创建$dir/dir3/dir_test/testdir1/file1.txt，并写入hello"
    echo "hello" > $dir/dir3/dir_test/testdir1/file1.txt && echo "mkdir $dir/dir3/dir_test/testdir1"
    log_info "setfattr dir_test's value in dir3"
		setfattr -n user.myattribute -v "dir_test's value in dir3" $dir/dir3/dir_test && echo setxattr user $dir/dir3/dir_test
        #创建目录后setxattr同级目录
    log_info "创建$dir/dir4/testdir1"
    mkdir $dir/dir4/testdir1
    log_info "创建$dir/dir4/testdir1/file1.txt，并写入hello"
    echo "hello" > $dir/dir4/testdir1/file1.txt && echo "mkdir $dir/dir4/testdir1"
    log_info "setfattr dir_test's value in dir4"
		setfattr -n user.myattribute -v "dir_test's value in dir4" $dir/dir4/dir_test && echo setxattr user $dir/dir4/dir_test
        #创建目录后setxattr其他目录
    log_info "创建$dir/dir2/testdir1"
    mkdir $dir/dir2/testdir1
    log_info "创建$dir/dir2/testdir1/file1.txt，并写入hello"
    echo "hello" > $dir/dir2/testdir1/file1.txt && echo "mkdir $dir/dir2/testdir1"
    log_info "setfattr dir_test's value in dir5"
		setfattr -n user.myattribute -v "dir_test's value in dir5" $dir/dir5/dir_test && echo setxattr user $dir/dir5/dir_test
		#创建目录后setxattr同一目录
		log_info "创建$dir/dir5/testdir1"
		mkdir $dir/dir5/testdir1
		log_info "创建$dir/dir5/testdir1/file1.txt，并写入hello"
		echo "hello" > $dir/dir5/testdir1/file1.txt && echo "mkdir $dir/dir5/testdir1"
		log_info "setfattr testdir1's value in dir5"
		setfattr -n user.myattribute -v "testdir1's value in dir5" $dir/dir5/testdir1 && echo setxattr user $dir/dir5/testdir1
        
		
        #查看目录列表
        
		for ((k=1; k<=5; k++))
		do
			echo "$dir/dir$k目录下内容：" && ls -l $dir/dir$k
		done
		#查看扩展属性
		for ((k=1; k<=5; k++))
		do
				getfattr -d $dir/dir$k
				getfattr -d $dir/dir$k/dir_test
				getfattr -d $dir/dir$k/dir_test/file.txt
				getfattr -d $dir/dir$k/test.txt
		done
		getfattr -d $dir/dir5/testdir1
        #清空本次循环所产生目录
        rm -rf $dir/*

}

main(){

	#定义创建的文件名前缀为主机名
	file=`hostname`
	#进入拷机目录，目录不存在则创建，存在则提示已存在
	# read -p "请输入目录路径：" dir
	dir=$2

	if [ ! -d $dir ]; then
			mkdir $dir
	else
			echo "$dir exits,no need to create"
	fi
	#输入脚本循环次数
	# read -p "请输入循环次数：" count
	count=$3
	validate_parms "$@"
}
main "$@"