#! /bin/bash
#单/多线程实现openc文件的同时setxattr
source ./log.sh

#!/bin/bash
######################################################################################################################
# TestCase ID(单客户端单线程):  T90_P17241 T90_P17242 T90_P17243 T90_P17244 T90_P17245 T90_P17246 T90_P17247 T90_P17248
# TestCase ID(单客户端多线程):  T90_P15003 T90_P15004 T90_P15005 T90_P15006 T90_P15007 T90_P15008 T90_P15009 T90_P15010
# TestCase ID(多客户端单线程):  T90_P15674 T90_P15675 T90_P15676 T90_P15677 T90_P15678 T90_P15679 T90_P15680 T90_P15681
# TestCase ID(多客户端多线程):  T90_P16038 T90_P16039 T90_P16040 T90_P16041 T90_P16042 T90_P16043 T90_P16044 T90_P16045
# Description:  open-setxattr OP组合
# Author:       songyunfan
# Revision:     1.0.0
######################################################################################################################

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

#定义创建的文件名前缀为主机名
file=`hostname`
#进入拷机目录，目录不存在则创建，存在则提示已存在
# read -p "请输入目录路径：" dir
dir=$2

if [ ! -d $dir ]; then
        mkdir $dir
else
        echo "$dir exits,no need to create"
fi
#输入脚本循环次数
# read -p "请输入循环次数：" count
count=$3
back_data(){

        #dir下创建两个备用目录,目录下预埋文件
        mkdir $dir/dir1
        mkdir $dir/dir2
        for ((n=1; n<=5;n++))
        do
                touch "$dir/dir1/file${n}.txt"
                echo "this is the content of $dir/dir1/file${n}.txt" > "$dir/dir1/file${n}.txt"
                mkdir "$dir/dir1/testdir${n}"
                echo "this is a file in testdir${n}" > $dir/dir1/testdir${n}/testfile${n}.txt
        done
        for ((m=1; m<=5;m++))
        do
                touch "$dir/dir2/file${m}.txt"
                echo "this is the content of $dir/dir2/file${m}.txt" > "$dir/dir2/file${m}.txt"
                mkdir "$dir/dir2/testdir${m}"
                echo "this is a file in testdir${m}" > $dir/dir2/testdir${m}/testfile${m}.txt
        done
}
operation(){
       
        #创建文件后setxattr同级目录
		log_info "创建文件后setxattr同级目录"
        touch $dir/dir1/${file}-$i.txt && echo "dddd" > $dir/dir1/${file}-$i.txt && echo "dddd" > $dir/dir1/${file}-$i.txt && setfattr -n user.myattribute -v "testdir1's value in dir1" $dir/dir1/testdir1 && log_debug "touch $dir/dir1/${file}-$i.txt"
        #创建文件后setxattr父目录
        log_info "创建文件后setxattr父目录"
		touch $dir/dir2/testdir1/${file}-$i.txt && echo "dddd" > $dir/dir2/testdir1/${file}-$i.txt && echo "dddd" > $dir/dir2/testdir1/${file}-$i.txt && setfattr -n user.myattribute -v "testdir1's value in dir2" $dir/dir2/testdir1 && log_debug "touch $dir/dir2/testdir1/${file}-$i.txt"
        #创建文件后setxattr非父目录
        log_info "创建文件后setxattr非父目录"
		touch $dir/dir1/testdir1/${file}-$i.txt && echo "dddd" > $dir/dir1/testdir1/${file}-$i.txt && echo "dddd" > $dir/dir1/testdir1/${file}-$i.txt && setfattr -n user.myattribute -v "testdir2's value in dir1" $dir/dir1/testdir2 && log_debug "touch $dir/dir1/testdir1/${file}-$i.txt"
        #创建文件后setxattr同一文件
		log_info "创建文件后setxattr同一文件"
        touch $dir/dir1/testdir2/${file}-$i.txt && echo "dddd" > $dir/dir1/testdir2/${file}-$i.txt && echo "dddd" > $dir/dir1/testdir2/${file}-$i.txt && setfattr -n user.myattribute -v "${file}-$i.txt's value in dir1/testdir2" $dir/dir1/testdir2/${file}-$i.txt && log_debug "touch $dir/dir1/testdir2/${file}-$i.txt"
        #创建文件后setxattr同一目录下文件
		log_info "创建文件后setxattr同一目录下文件"
        touch $dir/dir2/testdir2/${file}-$i.txt && echo "dddd" > $dir/dir2/testdir2/${file}-$i.txt && echo "dddd" > $dir/dir2/testdir2/${file}-$i.txt && setfattr -n user.myattribute -v "testfile2.txt's value in dir2/testdir2" $dir/dir2/testdir2/testfile2.txt && log_debug "touch $dir/dir2/testdir2/${file}-$i.txt"
        #创建文件后setxattr其他目录下文件
		log_info "创建文件后setxattr其他目录下文件"
        touch $dir/dir1/testdir3/${file}-$i.txt && echo "dddd" > $dir/dir1/testdir3/${file}-$i.txt && echo "dddd" > $dir/dir1/testdir3/${file}-$i.txt && setfattr -n user.myattribute -v "testfile4.txt's value in dir1/testdir4" $dir/dir1/testdir4/testfile4.txt && log_debug "touch $dir/dir1/testdir3/${file}-$i.txt"

        #查看目录列表
		echo "$dir目录的内容：" && ls -l $dir
        echo "$dir/dir1目录的内容：" && ls -l $dir/dir1
        echo "$dir/dir2目录的内容：" && ls -l $dir/dir2
		#查看扩展属性设置结果
		getfattr -d $dir/dir1/testdir1
		getfattr -d $dir/dir2/testdir1
		getfattr -d $dir/dir1/testdir2
		getfattr -d $dir/dir1/testdir2/${file}-$i.txt
		getfattr -d $dir/dir2/testdir2/testfile2.txt
		getfattr -d $dir/dir1/testdir4/testfile4.txt

        #清空本次循环所产生目录
        #rm -rf $dir/* 
		

}

teardown() {

    # 检查目录是否存在
    if [ -d "${dir}" ]; then
        log_info "开始清空本次循环所产生的目录文件"
        # 递归删除指定目录中的所有文件和子目录
		rm -rf $dir/*
        #rm -rf $dir/dir1
		#rm -rf $dir/dir2
        log_info "删除完成本次循环所产生的目录文件"
    else
        # 目录不存在时输出错误信息
        log_err "Directory does not exist: $dir"
    fi


        #清空本次循环所产生目录
        rm -rf $dir/*

}

#根据输入开始单线程/多线程测试
#如果输入不正确，则输出usage内容
if [ $# -ne 3 ];then
        usage
        exit
fi
#单线程，则直接执行operation，拷机预设的count次
if [ $1 -eq 1 ];then
        for i in `seq 1 $count`
        do
                back_data
                operation
				teardown
                echo "--- 第$i次循环 ---"
        done
#多线程
elif [ $1 -gt 1 ];then
{
        #back_data
        # read -p "请输入并发线程数（只能输入数字）：" thread
        thread=$1
        [ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
                exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
                rm -rf /tmp/fd1 #删除管道文件

        for i in `seq 1 $thread`  #实现多线程并发
        do
        {
                echo >&3 #向文件描述符为3的命名管道中写入空行
                echo a=$i
        }
        done
        #并发进行操作
        for j in `seq 1 $count`
        do
                read -u3
                {
                back_data
				operation
				teardown
                echo $j
                echo >&3
                }&
        done
        wait
        exec 3<&-
        exec 3>&-

}
else
        usage
fi
