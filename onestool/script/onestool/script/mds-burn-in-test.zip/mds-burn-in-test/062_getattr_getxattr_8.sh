#!/bin/bash
#单/多线程实现
#################################################################
# TestCase ID:  etattr_getxattr OP组合
# Description:  单/多线程实现getattr_getxattr
# Author:    hys46897
# Revision:    1.0.0

#################################################################
source ./log.sh
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

#参数校验
validate_parms(){

	#根据输入开始单线程/多线程测试
	#如果输入不正确，则输出usage内容
	if [ $# -ne 3 ];then
			usage
			exit
	fi
	#单线程，则直接执行operation，拷机预设的count次
	if [ $1 -eq 1 ];then
			for i in `seq 1 $count`
			do
					operation
					echo "--- 第$i次循环 ---"
			done
	#多线程
	elif [ $1 -gt 1 ];then
	{
			# read -p "请输入并发线程数（只能输入数字）：" thread
			thread=$1
			[ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
					exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
					rm -rf /tmp/fd1 #删除管道文件

			for i in `seq 1 $thread`  #实现多线程并发
			do
			{
					echo >&3 #向文件描述符为3的命名管道中写入空行
					echo a=$i
			}
			done
			#并发进行操作
			for j in `seq 1 $count`
			do
					read -u3
					{
					operation
					echo $j
					echo >&3
					}&
			done
			wait
			exec 3<&-
			exec 3>&-

	}
	else
			usage
	fi
}


operation(){
	
    log_info "查询文件hello的属性和扩展属性"
    echo 查询文件hello的属性和扩展属性
    log_info "创建dir1和dir2"
    mkdir $dir/dir1
    mkdir $dir/dir2
    log_info "创建hello和hi"
    echo hello > $dir/dir1/hello
    echo hi > $dir/dir2/hi
    log_info "stat hello"
    stat $dir/dir1/hello
    log_info "设置 hello文件的扩展属性 value"
    setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
    log_info "设置 hello文件的扩展属性 label"
    setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
    log_info "使用 chattr 命令给hello设置属性"
    chattr +i $dir/dir1/hello && echo chattr $dir/dir1/hello
    log_info "查询hello的扩展属性"
    getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
    log_info "列出hello的属性"
    lsattr $dir/dir1/hello && echo lsattr $dir/dir1/hello
    log_info "stat hello"
    stat $dir/dir1/hello

  #  setfattr -x * $dir/dir1/hello && echo removexattr $dir/dir1/hello
    log_info "使用 chattr 命令移除hello属性"
    chattr -i $dir/dir1/hello && echo removechattr $dir/dir1/hello
    log_info "删除dir1与dir2以及目录下内容"
    rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
    rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

    rm -rf $dir/dir1
    rm -rf $dir/dir2
    log_info "查询目录dir1的属性和扩展属性"
    echo 查询目录dir1的属性和扩展属性
    log_info "创建dir1和dir2"
    mkdir $dir/dir1
    mkdir $dir/dir2
    log_info "创建hello和hi"
    echo hello > $dir/dir1/hello
    echo hi > $dir/dir2/hi
    log_info "stat dir1"
    stat  $dir/dir1
    log_info "设置 dir1的扩展属性 value"
    setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
    log_info "查询dir1的扩展属性"
    getfattr -d $dir/dir1 && echo getxattr $dir/dir1
    stat $dir/dir1
    log_info "删除dir1与dir2以及目录下内容"
  #  setfattr -x * $dir/dir1 && echo removexattr $dir/dir1
    rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
    rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

    rm -rf $dir/dir1
    rm -rf $dir/dir2
    log_info "查询父目录的扩展属性，查询文件hello的属性"
    echo 查询父目录的扩展属性,查询文件hello的属性
    log_info "创建dir1和dir2"
    mkdir $dir/dir1
    mkdir $dir/dir2
    echo hello > $dir/dir1/hello
    echo hi > $dir/dir2/hi
    log_info "stat dir1"
    stat  $dir/dir1
    log_info "stat hello"
    stat $dir/dir1/hello
    log_info "设置 dir1的扩展属性 value"
    setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
    log_info "查询hello的扩展属性"
    getfattr -d $dir/dir1 && echo getxattr $dir/dir1
    log_info "stat hello"
    stat $dir/dir1/hello

  #  setfattr -x * $dir/dir1 && echo removexattr $dir/dir1
    log_info "删除dir1与dir2以及目录下内容"
    rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
    rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

    rm -rf $dir/dir1
    rm -rf $dir/dir2
    log_info "查询文件hello的扩展属性，查询其父目录的属性"
    echo 查询文件hello的扩展属性,查询其父目录的属性
    log_info "创建dir1和dir2"
    mkdir $dir/dir1
    mkdir $dir/dir2
    log_info "创建hello和hi"
    echo hello > $dir/dir1/hello
    echo hi > $dir/dir2/hi
    log_info "stat dir1"
    stat  $dir/dir1
    log_info "stat hello"
    stat $dir/dir1/hello
    log_info "设置 hello文件的扩展属性 value"
    setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
    log_info "设置 hello文件的扩展属性 label"
    setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
    log_info "使用 chattr 命令给hello设置属性"
    chattr +i $dir/dir1/hello && echo chattr $dir/dir1/hello
    log_info "查询hello的扩展属性"
    getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
    log_info "列出hello的属性"
    lsattr $dir/dir1/hello && echo lsattr $dir/dir1/hello
    log_info "stat hello"
    stat  $dir/dir1
    log_info "使用 chattr 命令移除hello属性"
  #  setfattr -x * $dir/dir1/hello && echo removexattr $dir/dir1/hello
    chattr -i $dir/dir1/hello && echo removechattr $dir/dir1/hello
    log_info "删除dir1与dir2以及目录下内容"
    rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
    rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

    rm -rf $dir/dir1
    rm -rf $dir/dir2

    log_info "查询文件hi的扩展属性，查询文件hello的属性"
    echo 查询文件hi的扩展属性,查询文件hello的属性
    log_info "创建dir1和dir2"
    mkdir $dir/dir1
    mkdir $dir/dir2
    log_info "创建hello和hi"
    echo hello > $dir/dir1/hello
    echo hi > $dir/dir2/hi
    log_info "stat hi"
    stat  $dir/dir2/hi
    log_info "stat hello"
    stat $dir/dir1/hello
    log_info "设置 hi文件的扩展属性 value"
    setfattr -n user.myattribute -v "value" $dir/dir2/hi && echo setxattr user $dir/dir2/hi
    log_info "查询hi的扩展属性"
    getfattr -d $dir/dir2/hi && echo getxattr $dir/dir2/hi
    log_info "stat hello"
    stat $dir/dir1/hello

  #  setfattr -x * $dir/dir1/hello && echo removexattr $dir/dir1/hello
  #  setfattr -x * $dir/dir1/hi && echo removexattr $dir/dir1/hi
    log_info "删除dir1与dir2以及目录下内容"
    rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
    rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

    rm -rf $dir/dir1
    rm -rf $dir/dir2
    log_info "查询目录dir1的扩展属性，查询目录dir2的属性"
    echo 查询目录dir1的扩展属性,查询目录dir2的属性
    log_info "创建dir1和dir2"
    mkdir $dir/dir1
    mkdir $dir/dir2
    log_info "创建hello和hi"
    echo hello > $dir/dir1/hello
    echo hi > $dir/dir2/hi
    log_info "stat dir1"
    stat $dir/dir1
    log_info "stat dir2"
    stat $dir/dir2
    log_info "设置 dir1的扩展属性 value"
    setfattr -n user.myattribute -v "value" $dir/dir1 && echo setxattr user $dir/dir1
    log_info "查询dir1的扩展属性"
    getfattr -d $dir/dir1 && echo getxattr $dir/dir1
    log_info "stat dir2"
    stat $dir/dir2
    log_info "删除dir1与dir2以及目录下内容"
    rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
    rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

    rm -rf $dir/dir1
    rm -rf $dir/dir2
    log_info "查询目录dir2的扩展属性，查询文件hello的属性"
    echo 查询目录dir2的扩展属性,查询文件hello的属性
    log_info "创建dir1和dir2"
    mkdir $dir/dir1
    mkdir $dir/dir2
    log_info "创建hello和hi"
    echo hello > $dir/dir1/hello
    echo hi > $dir/dir2/hi
    log_info "stat dir2"
    stat $dir/dir2
    log_info "stat hello"
    stat $dir/dir1/hello
    log_info "设置 dir2的扩展属性 value"
    setfattr -n user.myattribute -v "value" $dir/dir2 && echo setxattr user $dir/dir2
    log_info "查询dir2的扩展属性"
    getfattr -d $dir/dir2 && echo getxattr $dir/dir2
    log_info "stat hello"
    stat $dir/dir1/hello
    log_info "删除dir1与dir2以及目录下内容"
  #  setfattr -x * $dir/dir2 && echo removexattr $dir/dir2
    rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
    rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

    rm -rf $dir/dir1
    rm -rf $dir/dir2
    log_info "查询文件hello的扩展属性，查询目录dir2的属性"
    echo 查询文件hello的扩展属性,查询目录dir2的属性
    log_info "创建dir1和dir2"
    mkdir $dir/dir1
    mkdir $dir/dir2
    log_info "创建hello和hi"
    echo hello > $dir/dir1/hello
    echo hi > $dir/dir2/hi
    log_info "stat dir2"
    stat $dir/dir2
    log_info "stat hello"
    stat $dir/dir1/hello
    log_info "设置 hello文件的扩展属性 value"
    setfattr -n user.myattribute -v "value" $dir/dir1/hello && echo setxattr user $dir/dir1/hello
    log_info "设置 hello文件的扩展属性 label"
    setfattr -n security.selinux -v "label" $dir/dir1/hello && echo setxattr security $dir/dir1/hello
    log_info "使用 chattr 命令给hello设置属性"
    chattr +i $dir/dir1/hello && echo chattr $dir/dir1/hello
    log_info "查询hello的扩展属性"
    getfattr -d $dir/dir1/hello && echo getxattr $dir/dir1/hello
    log_info "列出hello的属性"
    lsattr $dir/dir1/hello && echo lsattr $dir/dir1/hello

    stat  $dir/dir2

  #  setfattr -x * $dir/dir1/hello && echo removexattr $dir/dir1/hello
    log_info "使用 chattr 命令移除hello属性"
    chattr -i $dir/dir1/hello && echo removechattr $dir/dir1/hello
    log_info "删除dir1与dir2以及目录下内容"
    rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
    rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi

    rm -rf $dir/dir1
    rm -rf $dir/dir2
 
}

main(){

	#定义创建的文件名前缀为主机名
	file=`hostname`
	#进入拷机目录，目录不存在则创建，存在则提示已存在
	# read -p "请输入目录路径：" dir
	dir=$2

	if [ ! -d $dir ]; then
			mkdir $dir
	else
			echo "$dir exits,no need to create"
	fi
	#输入脚本循环次数
	# read -p "请输入循环次数：" count
	count=$3
	validate_parms "$@"
}
main "$@"