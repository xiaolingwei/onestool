#!/bin/bash
#################################################################
# TestCase ID:  T90_P17223
# Description:  rename-setattr OP组合
# Author:       wys45223
# Revision:     1.0.0
# Example of using the logging interface:
#
# source ./log.sh
# log_debug "this is debug log..."
# log_info "this is info log..."
# log_warn "this is warn log..."
# log_err "this is error log..."
# log "this is always log.."
#################################################################
#日志级别 debug-1, info-2, warn-3, error-4, log-5
LOG_LEVEL=1
#日志文件
DATETIME=$(date '+%Y%m%d%H%M%S')
FILENAME=$(basename "$0")
NAME=${FILENAME%.*}
LOG_FILE=./${NAME}_${DATETIME}.log
#调试日志
function log_debug()
{
  content="[DEBUG] $(date '+%Y-%m-%d %H:%M:%S') $@"
  [ $LOG_LEVEL -le 1  ] && echo $content >> $LOG_FILE && echo -e "\033[32m"  ${content}  "\033[0m"
}
#信息日志
function log_info()
{
  content="[INFO] $(date '+%Y-%m-%d %H:%M:%S') $@"
  [ $LOG_LEVEL -le 2  ] && echo $content >> $LOG_FILE && echo -e "\033[32m"  ${content} "\033[0m"
}
#警告日志
function log_warn()
{
  content="[WARN] $(date '+%Y-%m-%d %H:%M:%S') $@"
  [ $LOG_LEVEL -le 3  ] && echo $content >> $LOG_FILE && echo -e "\033[33m" ${content} "\033[0m"
}
#错误日志
function log_err()
{
  content="[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $@"
  [ $LOG_LEVEL -le 4  ] && echo $content >> $LOG_FILE && echo -e "\033[31m" ${content} "\033[0m"
}
#日志
function log()
{
   content="[LOG] $(date '+%Y-%m-%d %H:%M:%S') $@"
   [ $LOG_LEVEL -le 5  ] && echo $content >> $LOG_FILE && echo -e  "\033[32m" ${content} "\033[0m"
}

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

hostname=`hostname`
# read -p "请输入要跑脚本的目录全路径（eg:/mnt/note3/dir）：" dir
dir=$2

if [ ! -d $dir ];then
	mkdir $dir
else
	echo "$dir exits,no need to create"
fi

# read -p "请输入脚本要循环的次数（只能输入数字）：" count
count=$3

operation()
{
	# 创建用户和用户组
  	log_info "创建用户和用户组"
	useradd user
	groupadd group
	# 重命名文件hello并设置文件hello的属性	
    log_info "重命名文件hello并设置文件hello的属性"
    log"创建目录dir1/dir2和文件hello/hi"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
    log"获取文件hello的属性"
	stat $dir/dir1/hello
  
    log"重命名文件hello"
 	mv $dir/dir1/hello $dir/dir2/hello_$hostname && echo mv $dir/dir1/hello
	mv $dir/dir2/hello_$hostname $dir/dir1/hello && echo mv $dir/dir2/hello_$hostname
  
    log"设置文件hello的属性"
	chmod 777 $dir/dir1/hello && echo chmod $dir/dir1/hello
	chown user:group $dir/dir1/hello && echo chown $dir/dir1/hello
  	touch -a -t 202210311200.00 $dir/dir1/hello && echo touch -a -t $dir/dir1/hello 
  
    log"获取文件hello的属性"
  	stat $dir/dir1/hello
  
    log"删除创建的文件及目录"
  	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
 	rm -rf $dir/dir1
	rm -rf $dir/dir2

	# 重命名目录dir1并设置目录dir1的属性
    log_info "重命名目录dir1并设置目录dir1的属性"
    log"创建目录dir1/dir2和文件hello/hi"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
    log"获取目录dir1和文件hello的属性"
  	stat  $dir/dir1
  	stat $dir/dir1/hello
  
    log"重命名目录dir1"
  	mv $dir/dir1 $dir/dir1_$hostname && echo mv $dir/dir1
	mv $dir/dir1_$hostname $dir/dir1 && echo mv $dir/dir1_$hostname  
  
    log"设置目录dir1的属性"
	chmod 755 $dir/dir1 && echo chmod $dir/dir1
	chown user:group $dir/dir1 && echo chown $dir/dir1
	touch -a -t 202203132100 $dir/dir1 && echo touch -a -t $dir/dir1

    log"获取目录dir1的属性"
	stat  $dir/dir1

    log"删除创建的文件及目录"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	rm -rf $dir/dir1
	rm -rf $dir/dir2

	# 重命名目录dir1，设置文件hello属性
    log_info "重命名目录dir1，设置文件hello属性"
    log"创建目录dir1/dir2和文件hello/hi"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
    log"获取目录dir1和文件hello的属性"
  	stat  $dir/dir1
  	stat $dir/dir1/hello
  
    log"重命名目录dir1"
  	mv $dir/dir1 $dir/dir1_$hostname && echo mv $dir/dir1
	mv $dir/dir1_$hostname $dir/dir1 && echo mv $dir/dir1_$hostname  
   
    log"设置文件hello的属性"
	chmod 777 $dir/dir1/hello && echo chmod $dir/dir1/hello
	chown user:group $dir/dir1/hello && echo chown $dir/dir1/hello
  	touch -a -t 202210311200.00 $dir/dir1/hello && echo touch -a -t $dir/dir1/hello 
    
    log"获取目录dir1和文件hello的属性"
  	stat  $dir/dir1
  	stat $dir/dir1/hello 

    log"删除创建的文件及目录"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  	rm -rf $dir/dir1
	rm -rf $dir/dir2
 
	# 重命名文件hello并设置目录dir1的属性	
    log_info "重命名文件hello并设置目录dir1的属性"
    log"创建目录dir1/dir2和文件hello/hi"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
    log"获取文件hello的属性"
	stat $dir/dir1/hello
  
    log"重命名文件hello"
 	mv $dir/dir1/hello $dir/dir2/hello_$hostname && echo mv $dir/dir1/hello
	mv $dir/dir2/hello_$hostname $dir/dir1/hello && echo mv $dir/dir2/hello_$hostname
  
    log"设置目录dir1的属性"
	chmod 755 $dir/dir1 && echo chmod $dir/dir1
	chown user:group $dir/dir1 && echo chown $dir/dir1
	touch -a -t 202203132100 $dir/dir1 && echo touch -a -t $dir/dir1
	
    log"获取文件hello的属性"
  	stat $dir/dir1/hello  
  
    log"删除创建的文件及目录"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
 	rm -rf $dir/dir1
	rm -rf $dir/dir2
    
	# 重命名文件hi，设置文件hello的属性
    log_info "重命名文件hi，设置文件hello的属性"
    log"创建目录dir1/dir2和文件hello/hi"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
    log"获取文件hello和hi的属性"
	stat  $dir/dir1/hi
	stat $dir/dir1/hello
  
    log"重命名文件hi"
 	mv $dir/dir2/hi $dir/dir1/hi_$hostname && echo mv $dir/dir2/hi
	mv $dir/dir1/hi_$hostname $dir/dir2/hi && echo mv $dir/dir1/hi_$hostname
  
    log"设置文件hi的属性"
	chmod 777 $dir/dir2/hi && echo chmod $dir/dir2/hi
	chown user:group $dir/dir2/hi && echo chown $dir/dir2/hi
  	touch -a -t 202210311200.00 $dir/dir2/hi && echo touch -a -t $dir/dir2/hi
     
    log"获取文件hi/hello的属性"
	stat  $dir/dir2/hi
	stat $dir/dir1/hello 
  
    log"删除创建的文件及目录"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	rm -rf $dir/dir1
	rm -rf $dir/dir2
 
	# 重命名目录dir1，设置目录dir2属性 
    log_info "重命名目录dir1，设置目录dir2属性"
    log"创建目录dir1/dir2和文件hello/hi"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
    log"获取目录dir1和dir2的属性"
	stat  $dir/dir1
	stat $dir/dir2
	
    log"重命名目录dir1"
  	mv $dir/dir1 $dir/dir1_$hostname && echo mv $dir/dir1
	mv $dir/dir1_$hostname $dir/dir1 && echo mv $dir/dir1_$hostname  
 
    log"设置目录dir2的属性"
	chmod 755 $dir/dir2 && echo chmod $dir/dir2
	chown user:group $dir/dir2 && echo chown $dir/dir2
	touch -a -t 202203132100 $dir/dir2 && echo touch -a -t $dir/dir2
		
    log"获取目录dir1和dir2的属性"
	stat  $dir/dir1
	stat $dir/dir2

    log"删除创建的文件及目录"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
 	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	rm -rf $dir/dir1
	rm -rf $dir/dir2
 
	# 重命名目录dir2，设置文件hello属性
    log_info "重命名目录dir2，设置文件hello属性"
    log"创建目录dir1/dir2和文件hello/hi"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
    log"获取目录dir2和文件hello的属性"
	stat  $dir/dir2
	stat $dir/dir1/hello
	
    log"重命名目录dir2"
	mv $dir/dir2 $dir/dir2_$hostname && echo mv $dir/dir2
	mv $dir/dir2_$hostname $dir/dir2 && echo mv $dir/dir2_$hostname  
  
    log"设置文件hello的属性"
	chmod 777 $dir/dir1/hello && echo chmod $dir/dir1/hello
	chown user:group $dir/dir1/hello && echo chown $dir/dir1/hello
	touch -a -t 202210311200.00 $dir/dir1/hello && echo touch -a -t $dir/dir1/hello 
		
    log"获取目录dir2和文件hello的属性"
	stat  $dir/dir2
	stat $dir/dir1/hello 

    log"删除创建的文件及目录"
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	rm -rf $dir/dir1
	rm -rf $dir/dir2
 
	# 重命名文件hello并设置目录dir2的属性
    log_info "重命名文件hello并设置目录dir2的属性"	
    log"创建目录dir1/dir2和文件hello/hi"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
    log"获取文件hello的属性"
	stat $dir/dir1/hello
  
    log"重命名文件hello"
 	mv $dir/dir1/hello $dir/dir2/hello_$hostname && echo mv $dir/dir1/hello
	mv $dir/dir2/hello_$hostname $dir/dir1/hello && echo mv $dir/dir2/hello_$hostname
  
    log"设置目录dir2的属性"
	chmod 755 $dir/dir2 && echo chmod $dir/dir2
	chown user:group $dir/dir2 && echo chown $dir/dir2
	touch -a -t 202203132100 $dir/dir2 && echo touch -a -t $dir/dir2
	
    log"获取文件hello的属性"
	stat $dir/dir1/hello
	
    log"删除创建的文件及目录"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
 	rm -rf $dir/dir1
	rm -rf $dir/dir2

    log"删除用户和用户组"
	userdel user
	groupdel group
}

if [ $# -ne 3 ]; then
        usage
        exit
fi

if [ $1 -eq 1 ]; then
{	
	for i in `seq 1 $count`
	do
        {
	operation
        echo $i
        }
	done
}

elif [ $1 -gt 1 ]; then
{
	# read -p "请输入要并发的线程数（只能输入数字）：" thread
	thread=$1
	[ -e /tmp/fd1 ] || mkfifo /tmp/fd1
        exec 3<>/tmp/fd1
        rm -rf /tmp/fd1
	
	for i in `seq 1 $thread`
	do
        {
	echo >&3
        echo a=$i
	}
	done

        for j in `seq 1 $count`
        do
        read -u3
        {
        operation
        echo $j
        echo >&3
        }&
	done
	wait
	exec 3<&-
	exec 3>&-

}
else
	usage
fi
