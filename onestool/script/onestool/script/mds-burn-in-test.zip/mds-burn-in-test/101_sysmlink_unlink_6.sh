#! /bin/bash
#单/多线程实现sysmlink文件的同时unlink
source ./log.sh

#!/bin/bash
###########################################################################
# TestCase ID(单客户端单线程):  T90_P17336 T90_P17337 T90_P17338 T90_P17339
# TestCase ID(单客户端多线程):  T90_P15164 T90_P15165 T90_P15166 T90_P15168
# TestCase ID(多客户端单线程):  T90_P15725 T90_P15726 T90_P15727 T90_P16595
# TestCase ID(多客户端多线程):  T90_P16195 T90_P16196 T90_P16197 T90_P16198
# Description:  sysmlink-unlink OP组合
# Author:       songyunfan
# Revision:     1.0.0
###########################################################################

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

hostname=`hostname`
# read -p "请输入要跑脚本的目录全路径（eg:/mnt/note3/dir）：" dir
dir=$2

if [ ! -d $dir ];then
	mkdir $dir
else
	echo "$dir exits,no need to create"
fi

# read -p "请输入脚本要循环的次数（只能输入数字）：" count
count=$3

operation(){

	log_info "创建文件hello的软链接并删除文件hello"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
	stat $dir/dir1/hello && log_debug "stat $dir/dir1/hello"
	log_info "ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i"
	ln -s $dir/dir1/hello $dir/dir1/hello_$hostname_$i && echo ln -s $dir/dir1/hello
	stat $dir/dir1/hello && log_debug "stat $dir/dir1/hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello && log_debug "rm -rf $dir/dir1/hello"
	log_info "rm -rf $dir/dir1/hello_$hostname_$i"
	rm -rf $dir/dir1/hello_$hostname_$i && echo rm -rf $dir/dir1/hello_$hostname_$i
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi && log_debug "rm -rf $dir/dir2/hi"
	rm -rf $dir/dir1 && log_debug "rm -rf $dir/dir1"
	rm -rf $dir/dir2 && log_debug "rm -rf $dir/dir2"
	
	log_info "创建目录dir1的软链接并删除目录dir1"
	mkdir $dir/dir1 && log_debug "mkdir $dir/dir1"
	mkdir $dir/dir2 && log_debug "mkdir $dir/dir2"
	echo hello > $dir/dir1/hello && log_debug "echo hello > $dir/dir1/hello"
	echo hi > $dir/dir2/hi && log_debug "echo hi > $dir/dir2/hi"
	stat  $dir/dir1 && log_debug "stat  $dir/dir1"
	ln -s $dir/dir1 $dir/dir1_$hostname_$i && echo ln -s $dir/dir1 && log_debug"ln -s $dir/dir1 $dir/dir1_$hostname_$i"
	stat  $dir/dir1 && log_debug "stat  $dir/dir1"
  
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello && log_debug "rm -rf $dir/dir1/hello"
	rm -rf $dir/dir1 && log_debug "rm -rf $dir/dir1"
 
	rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i && log_debug "rm -rf $dir/dir1_$hostname_$i"
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi && log_debug "rm -rf $dir/dir2/hi"
	rm -rf $dir/dir2 && log_debug "rm -rf $dir/dir2"
    

	log_info "创建父目录的软链接，删除文件hello"
	mkdir $dir/dir1 && log_debug "mkdir $dir/dir1"
	mkdir $dir/dir2 && log_debug "mkdir $dir/dir2"
	echo hello > $dir/dir1/hello log_debug "echo hello > $dir/dir1/hello"
	echo hi > $dir/dir2/hi && log_debug "echo hi > $dir/dir2/hi"
 
	stat  $dir/dir1 && log_debug "stat  $dir/dir1"
	stat $dir/dir1/hello && log_debug "stat $dir/dir1/hello" 
  
	ln -s $dir/dir1 $dir/dir1_$hostname_$i && echo ln -s $dir/dir1 && log_debug "ln -s $dir/dir1 $dir/dir1_$hostname_$i"
   
	stat  $dir/dir1 && log_debug "stat  $dir/dir1"
	stat $dir/dir1/hello && log_debug "stat $dir/dir1/hello"
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello && log_debug "rm -rf $dir/dir1/hello"

	rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i && log_debug "rm -rf $dir/dir1_$hostname_$i" 
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi && log_debug "rm -rf $dir/dir2/hi"
	rm -rf $dir/dir1 && log_debug "rm -rf $dir/dir1"
	rm -rf $dir/dir2 && log_debug "rm -rf $dir/dir2"
    
	log_info "创建文件hi的软链接，删除文件hello"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
	stat  $dir/dir2/hi && log_debug "stat  $dir/dir2/hi"
	stat $dir/dir1/hello && log_debug "stat $dir/dir1/hello"
  
	ln -s $dir/dir2/hi $dir/dir2/hi_$hostname_$i && echo ln -s $dir/dir2/hi && log_debug "ln -s $dir/dir2/hi $dir/dir2/hi_$hostname_$i"
  
	stat  $dir/dir2/hi && log_debug "stat  $dir/dir2/hi"
	stat $dir/dir1/hello && log_debug "stat $dir/dir1/hello"
  
	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  
	rm -rf $dir/dir2/hi_$hostname_$i && echo rm -rf $dir/dir2/hi_$hostname_$i
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	rm -rf $dir/dir1
	rm -rf $dir/dir2
 
	log_info "设置目录dir1的属性，删除目录dir2"
 	mkdir $dir/dir1
	mkdir $dir/dir2  
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
	stat  $dir/dir1 && log_debug "stat  $dir/dir1"
	stat $dir/dir2 && log_debug "stat $dir/dir2"
  
	ln -s $dir/dir1/hello $dir/dir1_$hostname_$i && echo ln -s $dir/dir1
 
	stat  $dir/dir1 && log_debug "stat  $dir/dir1"
	stat $dir/dir2  && log_debug "stat $dir/dir2"

	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	rm -rf $dir/dir2 && log_debug "rm -rf $dir/dir2"
  
	rm -rf $dir/dir1_$hostname_$i && echo rm -rf $dir/dir1_$hostname_$i
 	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	rm -rf $dir/dir1 && log_debug "rm -rf $dir/dir1"
 
	log_info "创建目录dir2的软链接，删除文件hello"
 	mkdir $dir/dir1
	mkdir $dir/dir2  
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
	stat  $dir/dir2
	stat $dir/dir1/hello
  
	ln -s $dir/dir2 $dir/dir2_$hostname_$i && echo ln -s $dir/dir2 && log_debug "ln -s $dir/dir2 $dir/dir2_$hostname_$i"
   
	stat  $dir/dir2
	stat $dir/dir1/hello 

	rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello && log_debug "rm -rf $dir/dir1/hello"

	rm -rf $dir/dir2_$hostname_$i && echo rm -rf $dir/dir2_$hostname_$i  
	rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hicd 
	rm -rf $dir/dir1
	rm -rf $dir/dir2
}

if [ $# -ne 3 ]; then
        usage
        exit
fi

if [ $1 -eq 1 ]; then
{	
	for i in `seq 1 $count`
	do
        {
	operation
        echo $i
        }
	done
}

elif [ $1 -gt 1 ]; then
{
	# read -p "请输入要并发的线程数（只能输入数字）：" thread
  thread=$1
	[ -e /tmp/fd1 ] || mkfifo /tmp/fd1
        exec 3<>/tmp/fd1
        rm -rf /tmp/fd1
	
	for i in `seq 1 $thread`
	do
        {
	echo >&3
        echo a=$i
	}
	done

        for j in `seq 1 $count`
        do
        read -u3
        {
        operation
        echo $j
        echo >&3
        }&
	done
	wait
	exec 3<&-
	exec 3>&-

}
else
	usage
fi
