#! /bin/bash
#单/多线程实现open文件/目录的同时setattr
#######################################################################################################################
# TestCase ID(单客户端单线程):  T90_P17543 T90_P17544 T90_P17545 T90_P17546 T90_P17547 T90_P17238 T90_P17240 T90_P17239
# TestCase ID(单客户端多线程):  T90_P14995 T90_P14996 T90_P14997 T90_P14998 T90_P14999 T90_P15000 T90_P15001 T90_P15002
# TestCase ID(多客户端单线程):  T90_P15665 T90_P15667 T90_P15668 T90_P15669 T90_P15670 T90_P15671 T90_P15672 T90_P15673
# TestCase ID(多客户端多线程):  T90_P16030 T90_P16031 T90_P16032 T90_P16033 T90_P16034 T90_P16035 T90_P16036 T90_P16037

# Description:  open-setattr OP组合
# Author:       liumengyang
# Revision:     1.0.0
#######################################################################################################################
source ./log.sh


usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

#定义创建的文件名前缀为主机名
#file=`hostname`
#进入拷机目录，目录不存在则创建，存在则提示已存在
# read -p "请输入目录路径：" dir
dir=$2
log_info "拷机目录:$dir"
if [ ! -d $dir ]; then
        mkdir $dir
else
        log_debug "$dir exits,no need to create"
fi
#输入脚本循环次数
# read -p "请输入循环次数：" count
count=$3
log_info "脚本循环次数$count"
back_data(){

        log_info "dir下创建两个备用目录,目录下预埋文件"
        mkdir $dir/dir1 && echo "mkdir $dir/dir1"
        mkdir $dir/dir2 && echo "mkdir $dir/dir2"
        for ((n=1; n<=5;n++))
        do
                touch "$dir/dir1/file${n}.txt" && echo "touch $dir/dir1/file${n}.txt"
                echo "this is the content of $dir/dir1/file${n}.txt" > "$dir/dir1/file${n}.txt"
                mkdir "$dir/dir1/testdir${n}" && echo "mkdir $dir/dir1/testdir${n}"
                echo "this is a file in testdir${n}" > $dir/dir1/testdir${n}/testfile${n}.txt
        done
        for ((m=1; m<=5;m++))
        do
                touch "$dir/dir2/file${m}.txt" && echo "touch $dir/dir2/file${m}.txt"
                echo "this is the content of $dir/dir2/file${m}.txt" > "$dir/dir2/file${m}.txt"
                mkdir "$dir/dir2/testdir${m}" && echo "mkdir $dir/dir2/testdir${m}"
                echo "this is a file in testdir${m}" > $dir/dir2/testdir${m}/testfile${m}.txt
        done
}
operation(){
        log_info "打开目录的同时setattr同一目录"
        cd $dir/dir1/testdir1 && chmod 777 $dir/dir1/testdir1
        log_info "打开目录后setattr其他目录"
        cd $dir/dir2/testdir1 && chmod 777 $dir/dir2/testdir2
        log_info "打开文件后setattr同级目录"
        echo 11 >> $dir/dir1/file1.txt && chmod 777 $dir/dir1/testdir2
        log_info "打开文件后setattr父目录"
        echo 11 >> $dir/dir2/testdir2/testfile2.txt && chmod 777 $dir/dir2/testdir1
        log_info "打开文件后setattr非父目录"
        echo 11 >> $dir/dir1/testdir3/testfile3.txt && chmod 777 $dir/dir1/testdir4
        log_info "打开目录后setattr目录下的子目录"
        cd $dir/dir2 && chmod 777 $dir/dir2/testdir4
        log_info "打开文件后setattr同一文件"
        echo 11 >> $dir/dir1/file1.txt && chmod 777 $dir/dir1/file1.txt
        log_info "打开文件后setattr同一目录下文件"
        echo 11 >> $dir/dir2/file1.txt && chmod 777 $dir/dir2/file2.txt
        log_info "打开文件后setattr其他目录下文件"
        echo 11 >> $dir/dir2/file1.txt && chmod 777 $dir/dir1/file2.txt
        log_info "打开目录后setattr目录下文件"
        cd $dir/dir1 && chmod 777 $dir/dir1/file3.txt
        log_info "打开目录后setattr其他目录下文件"
        cd $dir/dir1 && chmod 777 $dir/dir2/file1.txt

        log_info "查看目录列表"
        echo "$dir/dir1目录的内容：" && ls -l $dir/dir1
        echo "$dir/dir2目录的内容：" && ls -l $dir/dir2

}
teardown() {
    # 检查目录是否存在
    if [ -d "${dir}" ]; then
        log_info "开始清空本次循环所产生的目录文件"
        # 递归删除指定目录中的所有文件和子目录
        rm -rf "${dir}"/*
        log_info "删除完成本次循环所产生的目录文件"
    else
        # 目录不存在时输出错误信息
        log_err "Directory does not exist: ${dir}"
    fi
}

#根据输入开始单线程/多线程测试
#如果输入不正确，则输出usage内容
if [ $# -ne 3 ];then
        usage
        exit
fi
#单线程，则直接执行operation，拷机预设的count次
if [ $1 -eq 1 ];then
        for i in `seq 1 $count`
        do
                back_data
                operation
		sleep 3
		teardown
                log_info "--- 第$i次循环 ---"
        done
#多线程
elif [ $1 -gt 1 ];then
{
        #back_data
        # read -p "请输入并发线程数（只能输入数字）：" thread
        thread=$1
	log_info "并发线程数:$thread"
        [ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
                exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
                rm -rf /tmp/fd1 #删除管道文件

        for i in `seq 1 $thread`  #实现多线程并发
        do
        {
                echo >&3 #向文件描述符为3的命名管道中写入空行
                echo a=$i
        }
        done
        #并发进行操作
        for j in `seq 1 $count`
        do
                read -u3
                {
        	back_data
                operation
		sleep 3
		teardown
                echo $j
                echo >&3
                }&
        done
        wait
        exec 3<&-
        exec 3>&-

}
else
        usage
fi
