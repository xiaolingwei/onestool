#! /bin/bash
#单/多线程实现mkdir文件的同时symlink
#################################################################
# TestCase ID:  T90_P17421~T90_P17425,T90_P15345~T90_P15349
# Description:  makedir-symlink OP组合
# Author:       zhuxiaohong
# Revision:     1.0.0
#################################################################
source ./log.sh
#脚本用法
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}
#定义创建的文件名前缀为主机名
file=`hostname`
#进入拷机目录，目录不存在则创建，存在则提示已存在
# read -p "请输入目录路径：" dir
dir=$2

if [ ! -d $dir ]; then
        mkdir $dir
else
        log_info "$dir exits,no need to create"
fi
#输入脚本循环次数
# read -p "请输入循环次数：" count
count=$3

back_data(){
		#dir下创建两个备用目录,目录下预埋文件
	    log_info "dir下创建两个备用目录,目录下预埋文件"
        mkdir $dir/dir1 && log_debug "mkdir $dir/dir1"
        mkdir $dir/dir2 && log_debug "mkdir $dir/dir2"
        mkdir $dir/dir1/dir_test && log_debug "mkdir $dir/dir1/dir_test"
        touch $dir/dir1/test.txt && echo "111" > $dir/dir1/test.txt && log_debug "touch $dir/dir1/test.txt && echo 111 > $dir/dir1/test.txt"
		mkdir $dir/dir2/dir_test && log_debug "mkdir $dir/dir2/dir_test"
        touch $dir/dir2/test.txt && echo "111" > $dir/dir2/test.txt && log_debug "touch $dir/dir2/test.txt && echo 111 > $dir/dir2/test.txt"
}
operation(){
		
		
        #mkdir创建一个目录后，立即对该目录父目录下其他文件symlink创建软链接
		log_info "mkdir创建一个目录后，立即对该目录父目录下其他文件symlink创建软链接"
        mkdir $dir/dir1/testdir1 && echo "hello" > $dir/dir1/testdir1/file1.txt && log_debug "mkdir $dir/dir1/testdir1 && echo hello > $dir/dir1/testdir1/file1.txt"
		ln -s $dir/dir1/test.txt $dir/dir1/test-1.txt && log_debug "ln -s $dir/dir1/test.txt $dir/dir1/test-1.txt"
		
        #mkdir创建一个目录后对其他目录中的文件symlink创建软连接
		log_debug "mkdir创建一个目录后对其他目录中的文件symlink创建软连接"
        mkdir $dir/dir1/testdir1-1 && echo "hello" > $dir/dir1/testdir1-1/file1.txt && log_debug "mkdir $dir/dir1/testdir1-1 && echo hello > $dir/dir1/testdir1-1/file1.txt" 
		ln -s $dir/dir2/test.txt $dir/dir2/test-1.txt && log_debug "ln -s $dir/dir2/test.txt $dir/dir2/test-1.txt"
		
		#mkdir创建一个目录后对该目录父目录symlink创建软连接
		log_debug "mkdir创建一个目录后对该目录父目录symlink创建软连接"
        mkdir $dir/dir2/dir_test/testdir1 && echo "hello" > $dir/dir2/dir_test/testdir1/file1.txt && log_debug "mkdir $dir/dir2/dir_test/testdir1 && echo hello > $dir/dir2/dir_test/testdir1/file1.txt"
		ln -s $dir/dir2/dir_test $dir/dir2/dir_test-1 && log_debug "ln -s $dir/dir2/dir_test $dir/dir2/dir_test-1"
		
        #mkdir创建一个目录后，立即对该目录父目录下其他文件symlink创建软链接
		log_info "mkdir创建一个目录后，立即对该目录父目录下其他文件symlink创建软链接"
        mkdir $dir/dir2/testdir1 && echo "hello" > $dir/dir2/testdir1/file1.txt && log_debug "mkdir $dir/dir2/testdir1 && echo hello > $dir/dir2/testdir1/file1.txt"
		ln -s $dir/dir2/dir_test $dir/dir2/dir_test-2 && log_debug "ln -s $dir/dir2/dir_test $dir/dir2/dir_test-2"
		
        #mkdir创建一个目录后对其他目录symlink创建软连接
		log_info "mkdir创建一个目录后对其他目录symlink创建软连接"
        mkdir $dir/dir1/testdir1-2 && echo "hello" > $dir/dir1/testdir1-2/file1.txt && log_debug "mkdir $dir/dir1/testdir1-2 && echo hello > $dir/dir1/testdir1-2/file1.txt" 
		ln -s $dir/dir2/dir_test $dir/dir2/dir_test-3 && log_debug "ln -s $dir/dir2/dir_test $dir/dir2/dir_test-3"
		
		#mkdir创建一个目录后，立即对同一目录symlink创建软链接
		log_info "mkdir创建一个目录后，立即对同一目录symlink创建软链接"
		mkdir $dir/dir2/testdir1-1 && echo "hello" > $dir/dir2/testdir1-1/file1.txt && log_debug "mkdir $dir/dir2/testdir1-1 && echo hello > $dir/dir2/testdir1-1/file1.txt" 
		ln -s $dir/dir2/testdir1-1 $dir/dir2/testdir1-2 && log_debug "ln -s $dir/dir2/testdir1-1 $dir/dir2/testdir1-2"
        
        
        #查看目录列表
		log_info "ls -l查看目录$dir/dir1和$dir/dir2列表"
        echo "$dir/dir1目录下内容：" && ls -l $dir/dir1
        echo "$dir/dir2目录下内容：" && ls -l $dir/dir2


        #清空本次循环所产生目录
		log_info "清空本次循环所产生目录"
        rm -rf $dir/*

}

#根据输入开始单线程/多线程测试
#如果输入不正确，则输出usage内容
if [ $# -ne 3 ];then
        usage
        exit
fi
#单线程，则直接执行operation，拷机预设的count次
if [ $1 -eq 1 ];then
       for i in `seq 1 $count`
       do
               log_info "--- 第$i次循环 ---"
			   back_data
			   operation
               
       done
#多线程
elif [ $1 -ne 1 ];then
{
		#back_data
        # read -p "请输入并发线程数（只能输入数字）：" thread
        thread=$1
        [ -e /tmp/fd1 ] || mkfifo /tmp/fd1
                exec 3<>/tmp/fd1
                rm -rf /tmp/fd1

        for i in `seq 1 $thread`
        do
        {
                echo >&3
                echo a=$i
        }
        done

        for j in `seq 1 $count`
        do
                log_info "--- $thread多线程第$j次循环 ---"
				back_data
				read -u3
                {
                operation
                echo $j
                echo >&3
                }&
        done
        wait
        exec 3<&-
        exec 3>&-

}
else
        usage
fi