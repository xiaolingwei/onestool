#!/bin/bash

# 指定要列出目录的路径
target_path="/mnt/fp8k/"

# 获取目录下所有子目录的列表
dir_list=$(find "${target_path}" -type d)

# 定义并发执行ls的函数
execute_ls() {
  dir=$1
  ls "${dir}"
  echo "Finished listing ${dir}"
}

# 设置初始线程计数为0
THREAD_COUNT=0

# 设置最大并发线程数
MAX_THREADS=128

# 遍历目录列表，并在后台启动线程执行ls命令
for dir in ${dir_list}; do
  # 如果当前线程数达到最大并发数，等待其中一个线程完成
  if [ ${THREAD_COUNT} -ge ${MAX_THREADS} ]; then
    wait -n
    (( THREAD_COUNT-- ))
  fi

  # 执行ls命令的函数作为后台线程执行
  execute_ls "${dir}" &

  # 增加当前线程计数
  (( THREAD_COUNT++ ))
done

# 等待剩余线程执行完毕
wait

echo "All threads have finished executing."
