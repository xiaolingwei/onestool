#! /bin/bash
#单/多线程实现getxattr

#脚本用法
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}
#参数校验
validate_parms(){

	#根据输入开始单线程/多线程测试
	#如果输入不正确，则输出usage内容
	if [ $# -ne 3 ];then
			usage
			exit
	fi
	#单线程，则直接执行operation，拷机预设的count次
	if [ $1 -eq 1 ];then
			for i in `seq 1 $count`
			do
					back_data
					operation
					echo "--- 第$i次循环 ---"
			done
	#多线程
	elif [ $1 -gt 1 ];then
	{
			back_data
			# read -p "请输入并发线程数（只能输入数字）：" thread
			thread=$1
			[ -e /tmp/fd1 ] || mkfifo /tmp/fd1  #mkfifo创建命名通道，用于进程间通信
					exec 3<>/tmp/fd1 #使用文件描述符3实现向管道中写入或读取数据
					rm -rf /tmp/fd1 #删除管道文件

			for i in `seq 1 $thread`  #实现多线程并发
			do
			{
					echo >&3 #向文件描述符为3的命名管道中写入空行
					echo a=$i
			}
			done
			#并发进行操作
			for j in `seq 1 $count`
			do
					read -u3
					{
					operation
					echo $j
					echo >&3
					}&
			done
			wait
			exec 3<&-
			exec 3>&-

	}
	else
			usage
	fi
}

back_data(){

        #dir下创建目录,目录下预埋文件
        for ((n=1; n<=5;n++))
		do
			mkdir $dir/dir$n
			setfattr -n user.myattribute -v "$dir/dir$n" $dir/dir$n
			for ((a=1; a<=10; a++))
			do 
				touch $dir/dir$n/file$a.txt
				setfattr -n user.myattribute -v "$dir/dir$n/file$a.txt" $dir/dir$n/file$a.txt
			done
			
			for ((m=1; m<=5; m++))
			do 
				mkdir $dir/dir$n/dir$m
				setfattr -n user.myattribute -v "$dir/dir$n/dir$m" $dir/dir$n/dir$m
				for ((b=1; b<=10; b++))
				do 
					touch $dir/dir$n/dir$m/file$b.txt
					setfattr -n user.myattribute -v "$dir/dir$n/dir$m/file$b.txt" $dir/dir$n/dir$m/file$b.txt
				done
				
				for ((k=1; k<=5; k++))
				do 
					mkdir $dir/dir$n/dir$m/dir$k
					setfattr -n user.myattribute -v "$dir/dir$n/dir$m/dir$k" $dir/dir$n/dir$m/dir$k
					for ((c=1; c<=10; c++))
					do 
						touch $dir/dir$n/dir$m/dir$k/file$c.txt
						setfattr -n user.myattribute -v "$dir/dir$n/dir$m/dir$k/file$c.txt" $dir/dir$n/dir$m/dir$k/file$c.txt
					done
					
					for ((l=1; l<=5; l++))
					do 
						mkdir $dir/dir$n/dir$m/dir$k/dir$l
						setfattr -n user.myattribute -v "$dir/dir$n/dir$m/dir$k/dir$l" $dir/dir$n/dir$m/dir$k/dir$l
						for ((d=1; d<=10; d++))
						do 
							touch $dir/dir$n/dir$m/dir$k/dir$l/file$d.txt
							setfattr -n user.myattribute -v "$dir/dir$n/dir$m/dir$k/dir$l/file$d.txt" $dir/dir$n/dir$m/dir$k/dir$l/file$d.txt
						done
						for ((o=1; o<=5; o++))
						do 
							mkdir $dir/dir$n/dir$m/dir$k/dir$l/dir$o
							setfattr -n user.myattribute -v "$dir/dir$n/dir$m/dir$k/dir$l/dir$o" $dir/dir$n/dir$m/dir$k/dir$l/dir$o
							for ((e=1; e<=10; e++))
							do 
								touch $dir/dir$n/dir$m/dir$k/dir$l/dir$o/file$e.txt
								setfattr -n user.myattribute -v "$dir/dir$n/dir$m/dir$k/dir$l/dir$o/file$e.txt" $dir/dir$n/dir$m/dir$k/dir$l/dir$o/file$e.txt
							done
						done
					done
				done
			done
		done
		mkdir $dir/dir-cyc
		setfattr -n user.myattribute -v "$dir/dir-cyc" $dir/dir-cyc
		touch $dir/testfile.txt
		setfattr -n user.myattribute -v "$dir/testfile.txt" $dir/testfile.txt
		
}
operation(){
       #遍历目录setattr文件/目录
	   for ((n=1; n<=5;n++))
		do
			getfattr -d $dir/dir$n
			for ((a=1; a<=10; a++))
			do 
				getfattr -d $dir/dir$n/file$a.txt
			done
			
			for ((m=1; m<=5; m++))
			do 
				getfattr -d $dir/dir$n/dir$m
				for ((b=1; b<=10; b++))
				do 
					getfattr -d $dir/dir$n/dir$m/file$b.txt
				done
				
				for ((k=1; k<=5; k++))
				do 
					getfattr -d $dir/dir$n/dir$m/dir$k
					for ((c=1; c<=10; c++))
					do 
						getfattr -d $dir/dir$n/dir$m/dir$k/file$c.txt
					done
					
					for ((l=1; l<=5; l++))
					do 
						getfattr -d $dir/dir$n/dir$m/dir$k/dir$l
						for ((d=1; d<=10; d++))
						do 
							getfattr -d $dir/dir$n/dir$m/dir$k/dir$l/file$d.txt
						done
						for ((o=1; o<=5; o++))
						do 
							getfattr -d $dir/dir$n/dir$m/dir$k/dir$l/dir$o
							for ((e=1; e<=10; e++))
							do 
								getfattr -d $dir/dir$n/dir$m/dir$k/dir$l/dir$o/file$e.txt
							done
						done
					done
				done
			done
		done
        #循环setattr同一个文件
		getfattr -d $dir/testfile.txt
		#循环symlink同一个目录
		getfattr -d $dir/dir-cyc
        
		#清空本次循环所产生目录
        rm -rf $dir/*

}

main(){

	#定义创建的文件名前缀为主机名
	file=`hostname`
	#进入拷机目录，目录不存在则创建，存在则提示已存在
	# read -p "请输入目录路径：" dir
	dir=$2

	if [ ! -d $dir ]; then
			mkdir $dir
	else
			echo "$dir exits,no need to create"
	fi
	#输入脚本循环次数
	# read -p "请输入循环次数：" count
	count=$3
	validate_parms "$@"
}
main "$@"