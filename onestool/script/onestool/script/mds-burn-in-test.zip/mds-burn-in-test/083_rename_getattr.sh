#!/bin/bash
######################################################################################
# TestCase ID:：rename-getattr OP组合
# Description:  单/多线程实现rename文件/目录的同时获取文件/目录属性
# Author:       liumengyang
# Revision:     1.0.0
######################################################################################
source ./log.sh

usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}

hostname=`hostname`
# read -p "请输入要跑脚本的目录全路径（eg:/mnt/note3/dir）：" dir
dir=$2
log_info "拷机目录:$dir"
if [ ! -d $dir ];then
	mkdir $dir
else
	log_debug "$dir exits,no need to create"
fi

# read -p "请输入脚本要循环的次数（只能输入数字）：" count
count=$3
log_info "脚本循环次数$count"
operation(){

	log_info "并重命名文件hello获取文件hello属性"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
	stat $dir/dir1/hello
    
 	mv $dir/dir1/hello $dir/dir2/hello_$hostname && echo mv $dir/dir1/hello
	mv $dir/dir2/hello_$hostname $dir/dir1/hello && echo mv $dir/dir2/hello_$hostname
  
  	stat $dir/dir1/hello

	teardown
	sleep 2
  	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello  
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi  
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2
  
	log_info "重命名目录dir1并获取目录dir1属性"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir1
 
  	mv $dir/dir1 $dir/dir1_$hostname && echo mv $dir/dir1
	mv $dir/dir1_$hostname $dir/dir1 && echo mv $dir/dir1_$hostname  
    
  	stat  $dir/dir1
 	teardown
        sleep 2
  	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello  
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi  
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2
    
	log_info "重命名文件hello,获取其父目录属性"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir1
  	stat $dir/dir1/hello
  
  	mv $dir/dir1/hello $dir/dir2/hello_$hostname && echo mv $dir/dir1/hello
	mv $dir/dir2/hello_$hostname $dir/dir1/hello && echo mv $dir/dir2/hello_$hostname
   
  	stat  $dir/dir1
  	stat $dir/dir1/hello 
	
	teardown
        sleep 2
  	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello  
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi  
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2
 
	log_info "重命名目录dir1并获取文件hello属性"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
	stat $dir/dir1/hello
  
  	mv $dir/dir1 $dir/dir1_$hostname && echo mv $dir/dir1
	mv $dir/dir1_$hostname $dir/dir1 && echo mv $dir/dir1_$hostname  
  
  	stat $dir/dir1/hello
	
	teardown
        sleep 2
  	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello   
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi  
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2
  
    
	log_info "获取文件hi属性,重命名文件hello"
 	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir2/hi
  	stat $dir/dir1/hello
    
  	mv $dir/dir1/hello $dir/dir2/hello_$hostname && echo mv $dir/dir1/hello
	mv $dir/dir2/hello_$hostname $dir/dir1/hello && echo mv $dir/dir2/hello_$hostname
  
  	stat  $dir/dir2/hi
  	stat $dir/dir1/hello 
  	
	teardown
        sleep 2
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi 
	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  	#rm -rf $dir/dir1
	#rm -rf $dir/dir2
 
	log_info "获取目录dir1属性，重命名目录dir2"
 	mkdir $dir/dir1
	mkdir $dir/dir2  
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir1
  	stat $dir/dir2

  	mv $dir/dir2 $dir/dir2_$hostname && echo mv $dir/dir2
	mv $dir/dir2_$hostname $dir/dir2 && echo mv $dir/dir2_$hostname  
 
  	stat  $dir/dir1
  	stat $dir/dir2 
  
 	teardown
        sleep 2
	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
  	#rm -rf $dir/dir1  
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
	#rm -rf $dir/dir2
 
	log_info "获取目录dir2属性，重命名文件hello"
 	mkdir $dir/dir1
	mkdir $dir/dir2  
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
  	stat  $dir/dir2
  	stat $dir/dir1/hello
  
  	mv $dir/dir1/hello $dir/dir2/hello_$hostname && echo mv $dir/dir1/hello
	mv $dir/dir2/hello_$hostname $dir/dir1/hello && echo mv $dir/dir2/hello_$hostname
   
  	stat  $dir/dir2
  	stat $dir/dir1/hello 
 	
	teardown
        sleep 2
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi
  	#rm -rf $dir/dir2 
  	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello
	#rm -rf $dir/dir1
 
	log_info "获取文件hello属性，重命名目录dir2"
	mkdir $dir/dir1
	mkdir $dir/dir2
	echo hello > $dir/dir1/hello
	echo hi > $dir/dir2/hi
 
	stat $dir/dir1/hello
  
  	mv $dir/dir2 $dir/dir2_$hostname && echo mv $dir/dir2
	mv $dir/dir2_$hostname $dir/dir2 && echo mv $dir/dir2_$hostname 
  
  	stat $dir/dir1/hello
  	stat $dir/dir2
	teardown
        sleep 2
  	#rm -rf $dir/dir1/hello && echo rm -rf $dir/dir1/hello   
  	#rm -rf $dir/dir2/hi && echo rm -rf $dir/dir2/hi  
	#rm -rf $dir/dir1
	#rm -rf $dir/dir2 
}
teardown() {
    # 检查目录是否存在
    if [ -d "${dir}" ]; then
        log_info "开始清空本次循环所产生的目录文件"
        # 递归删除指定目录中的所有文件和子目录
        rm -rf "${dir}"/*
        log_info "删除完成本次循环所产生的目录文件"
    else
        # 目录不存在时输出错误信息
        log_err "Directory does not exist: ${dir}"
    fi
}

if [ $# -ne 3 ]; then
        usage
        exit
fi

if [ $1 -eq 1 ]; then
{	
	for i in `seq 1 $count`
	do
        {
		operation
        	log_info "------------第$i次循环-----------"
        }
	done
}

elif [ $1 -gt 1 ]; then
{
	# read -p "请输入要并发的线程数（只能输入数字）：" thread
	thread=$1
	log_info "并发线程数：$thread"
	[ -e /tmp/fd1 ] || mkfifo /tmp/fd1
        exec 3<>/tmp/fd1
        rm -rf /tmp/fd1
	
	for i in `seq 1 $thread`
	do
        {
	echo >&3
        echo a=$i
	}
	done

        for j in `seq 1 $count`
        do
        read -u3
        {
        operation
        log_info "---------第$j次循环---------"
        echo >&3
        }&
	done
	wait
	exec 3<&-
	exec 3>&-

}
else
	usage
fi
