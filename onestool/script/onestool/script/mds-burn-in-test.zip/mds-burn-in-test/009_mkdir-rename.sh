#! /bin/bash
#单/多线程实现mkdir文件的同时rename
#################################################################
# TestCase ID:  T90_P17414-T90_P17418,T90_P15338-T90_P15342
# Description:  makedir-rename OP组合
# Author:       yuki
# Revision:     1.0.0
#################################################################
source ./log.sh
#脚本用法
usage() {
    echo "
    usage: ${0} <thread> <dir> <count>
           脚本接受三个参数：
           <thread>: 表示线程数，1表示单线程
           <dir>: 挂载目录
           <count>: 脚本执行轮数"
}
#定义创建的文件名前缀为主机名
file=`hostname`
#进入拷机目录，目录不存在则创建，存在则提示已存在
# read -p "请输入目录路径：" dir
dir=$2

if [ ! -d $dir ]; then
        mkdir $dir
else
        log_info "$dir exits,no need to create"
fi
#输入脚本循环次数
# read -p "请输入循环次数：" count
count=$3

operation(){
		#dir下创建两个备用目录,目录下预埋文件
		log_info "dir下创建两个备用目录,目录下预埋文件"
        mkdir $dir/dir1 && log_debug "mkdir $dir/dir1"
        mkdir $dir/dir2 && log_debug "mkdir $dir/dir2"
        mkdir $dir/dir1/dir_test && log_debug "mkdir $dir/dir1/dir_test"
        touch $dir/dir1/test.txt && echo "111" > $dir/dir1/test.txt && log_debug "touch $dir/dir1/test.txt && echo 111 > $dir/dir1/test.txt"
		mkdir $dir/dir2/dir_test && log_debug "mkdir $dir/dir2/dir_test"
        touch $dir/dir2/test.txt && echo "111" > $dir/dir2/test.txt && log_debug "touch $dir/dir2/test.txt && echo 111 > $dir/dir2/test.txt"
       
        #mkdir创建一个目录后rename重命名同一目录
		log_info "mkdir创建一个目录后rename重命名同一目录"
        mkdir $dir/dir1/testdir1 && rename $dir/dir1/testdir1 $dir/dir1/testdir1-1 $dir/dir1/testdir1 && log_debug "mkdir $dir/dir1/testdir1 && rename $dir/dir1/testdir1 $dir/dir1/testdir1-1 $dir/dir1/testdir1"
		
        #创建目录后rename同级目录
		log_info "创建目录后rename同级目录"
        mkdir $dir/dir2/testdir1 && echo "hello" > $dir/dir2/testdir1/file1.txt && log_debug "mkdir $dir/dir2/testdir1 && echo hello > $dir/dir2/testdir1/file1.txt"
		rename $dir/dir2/dir_test $dir/dir2/dir_test-1 $dir/dir2/dir_test && log_debug "rename $dir/dir2/dir_test $dir/dir2/dir_test-1"
		
        #mkdir创建一个目录后rename重命名其父目录
		log_info "mkdir创建一个目录后rename重命名其父目录"
        mkdir $dir/dir1/dir_test/testdir1 && echo "hello" > $dir/dir1/dir_test/testdir1/file1.txt && log_debug "mkdir $dir/dir1/dir_test/testdir1 && echo hello > $dir/dir1/dir_test/testdir1/file1.txt"
		rename $dir/dir1/dir_test $dir/dir1/dir_test-1 $dir/dir1/dir_test && log_debug "rename $dir/dir1/dir_test $dir/dir1/dir_test-1 $dir/dir1/dir_test"
		
		#mkdir创建一个目录后rename重命名其他目录
		log_info "mkdir创建一个目录后rename重命名其他目录"
		mkdir $dir/dir2/testdir2 && echo "hello" > $dir/dir2/testdir2/file1.txt && log_debug "mkdir $dir/dir2/testdir2 && echo hello > $dir/dir2/testdir2/file1.txt"
		rename $dir/dir1/testdir1-1 $dir/dir1/testdir1-2 $dir/dir1/testdir1-1 && log_debug "rename $dir/dir1/testdir1-1 $dir/dir1/testdir1-2 $dir/dir1/testdir1-1"
		
        #mkdir创建一个目录后rename重命名其他目录中文件
		log_info "mkdir创建一个目录后rename重命名其他目录中文件"
        mkdir $dir/dir1/testdir2 && echo "hello" > $dir/dir1/testdir2/file1.txt && log_debug "mkdir $dir/dir1/testdir2 && echo hello > $dir/dir1/testdir2/file1.txt"
		rename $dir/dir2/test.txt $dir/dir2/test-1.txt $dir/dir2/test.txt && log_debug "rename $dir/dir2/test.txt $dir/dir2/test-1.txt $dir/dir2/test.txt"
		
        #mkdir创建一个目录后rename重命名同一目录中文件
		log_info "mkdir创建一个目录后rename重命名同一目录中文件"
        mkdir $dir/dir1/testdir3 && echo "hello" > $dir/dir1/testdir3/file1.txt && log_debug "mkdir $dir/dir1/testdir3 && echo hello > $dir/dir1/testdir3/file1.txt"
		rename $dir/dir1/test.txt $dir/dir1/test-1.txt $dir/dir1/test.txt && log_debug "rename $dir/dir1/test.txt $dir/dir1/test-1.txt $dir/dir1/test.txt"
        

        #查看目录列表
		log_info "ls -l 查看目录$dir列表"
        echo "$dir/dir1目录rename后的内容：" && ls -l $dir/dir1
        echo "$dir/dir2目录rename后的内容：" && ls -l $dir/dir2

        #清空本次循环所产生目录
		log_info "清空本次循环所产生目录$dir/*"
        rm -rf $dir/*

}

#根据输入开始单线程/多线程测试
#如果输入不正确，则输出usage内容
if [ $# -ne 3 ];then
        usage
        exit
fi
#单线程，则直接执行operation，拷机预设的count次
if [ $1 -eq 1 ];then
       for i in `seq 1 $count`
       do
               log_info "--- 第$i次循环 ---"
			   operation
               
       done
#多线程
elif [ $1 -ne 1 ];then
{
        # read -p "请输入并发线程数（只能输入数字）：" thread
        thread=$1
        [ -e /tmp/fd1 ] || mkfifo /tmp/fd1
                exec 3<>/tmp/fd1
                rm -rf /tmp/fd1

        for i in `seq 1 $thread`
        do
        {
                echo >&3
                echo a=$i
        }
        done

        for j in `seq 1 $count`
        do
                log_info "--- $thread多线程第$j次循环 ---"
				read -u3
                {
                operation
                echo $j
                echo >&3
                }&
        done
        wait
        exec 3<&-
        exec 3>&-

}
else
        usage
fi